<?php
function autixir_social_share_func() {
	global $post;
	?>
	<?php if ( is_single() ) { ?>
		<ul class="social-links pull-right clearfix">
			<li><a onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;" href="https://www.facebook.com/sharer/sharer.php?u=<?php echo esc_url( get_permalink($post) ); ?>"><i class="fab fa-facebook-f"></i></a></li>
			<li><a onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;" href="https://twitter.com/home?status=<?php echo urlencode( get_the_title() ); ?>-<?php echo esc_url( get_permalink($post) ); ?>"><i class="fab fa-twitter"></i></a></li>
			<li><a onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;" href="https://www.linkedin.com/shareArticle?mini=true&amp;url=<?php echo esc_url( get_permalink($post) ); ?>"><i class="fab fa-linkedin-in"></i></a></li>
			<li><a onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;"  href="https://www.pinterest.com/pin/find/?url=<?php echo get_the_permalink( $post ); ?>"><i class="fab fa-pinterest-p"></i></a></li>
		</ul>

	<?php }else{ ?>
		<ul class="social-links clearfix">
			<li><a onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;" href="https://www.facebook.com/sharer/sharer.php?u=<?php echo esc_url( get_permalink($post) ); ?>"><i class="fab fa-facebook-f"></i></a></li>
			<li><a onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;" href="https://twitter.com/home?status=<?php echo urlencode( get_the_title() ); ?>-<?php echo esc_url( get_permalink($post) ); ?>"><i class="fab fa-twitter"></i></a></li>
			<li><a onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;" href="https://www.linkedin.com/shareArticle?mini=true&amp;url=<?php echo esc_url( get_permalink($post) ); ?>"><i class="fab fa-linkedin-in"></i></a></li>
			<li><a onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;"  href="https://www.pinterest.com/pin/find/?url=<?php echo get_the_permalink( $post ); ?>"><i class="fab fa-pinterest-p"></i></a></li>
		</ul>
	<?php } ?>

	<?php
}
add_action( 'autixir_social_share', 'autixir_social_share_func' );
