(function($) {

    "use strict";
    

    


    var autixir_faq_js = function($scope, $) {
    

    }


    //Elementor JS Hooks
    $(window).on('elementor/frontend/init', function() {
         elementorFrontend.hooks.addAction('frontend/element_ready/autixir_faq.default', autixir_faq_js);

    });

})(window.jQuery);