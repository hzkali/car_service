<?php
/*
  Plugin Name: Autixir Core
  Plugin URI: https://themepuller.com
  Description: Helping for the Autixir theme.
  Author: ThemePuller Team
  Version: 1.0.0
  Author URI: https://themepuller.com
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/share/share-function.php';
require_once __DIR__ . '/meta-box/config-meta-box.php';
require_once __DIR__ . '/elementor-addons/autixir-elementor.php';
require_once __DIR__ . '/includes/Posttype/Services.php';
require_once __DIR__ . '/includes/Posttype/Portfolios.php';
require_once __DIR__ . '/includes/Posttype/Teams.php';
require_once __DIR__ . '/includes/Widgets/autixir-recent-posts.php';
require_once __DIR__ . '/includes/Widgets/autixir-sidebar-menu.php';

/**
 * Register custom widgets.
 *
 * @since   1.0.0
 */
function autixir_register_widgets() {

	// Widgets
	$widgets = 'author-info, banner, news-feed, social-media';
	$widgets = array_map( 'trim', explode( ',', $widgets ) );
	foreach ( $widgets as $widget ) {

		$file_path = __DIR__ . '/widgets/' . $widget . '.php';
		if ( file_exists( $file_path ) ){
			include( $file_path );
			$generate_name = str_replace('-','_', $widget );
			register_widget( 'autixir_Widget_'.$generate_name );
		}

	}
}
add_action( 'widgets_init', 'autixir_register_widgets' );

function autixir_shcial_share_func(){ ?>
  <div class="ltn__social-media text-right col-lg-4">
  <h4><?php echo esc_html__( 'Social Share', 'autixir' ); ?></h4>
  <ul>
      <li><a href="https://www.facebook.com/sharer/sharer.php?u=<?php the_permalink(); ?>" title="<?php esc_attr__( 'Facebook', 'autixir' ); ?>"><i class="fab fa-facebook-f"></i></a></li>
      <li><a href="https://twitter.com/share?<?php esc_url( the_permalink() );?>&amp;text=<?php the_title(); ?>" title="<?php esc_attr__( 'Twitter', 'autixir' ); ?>"><i class="fab fa-twitter"></i></a></li>
      <li><a href="http://www.linkedin.com/shareArticle?url=<?php esc_url( the_permalink() );?>&amp;title=<?php the_title(); ?>" title="<?php esc_attr__( 'Linkedin', 'autixir' ); ?>"><i class="fab fa-linkedin"></i></a></li>
      <li><a href="https://www.pinterest.com/pin/create/button/?url=<?php esc_url( the_permalink() );?>&amp;description=<?php the_title(); ?>'&amp;media=<?php echo esc_url( wp_get_attachment_url( get_post_thumbnail_id( get_the_id() ) ) ); ?>" title="<?php esc_attr__( 'Youtube', 'autixir' ); ?>"><i class="fab fa-pinterest"></i></a></li>
  </ul>
</div>
<?php
}

add_action('autixir_shcial_share','autixir_shcial_share_func');


/**
 * { autixir_get_post_views } Post View Counter
 *
 * @param <int>  $postID  The post id
 *
 * @return string 
 */
function autixir_get_post_views( $postID ){
  $count_key = 'autixir_post_views_count';
  $count = get_post_meta($postID, $count_key, true);
  if($count==''){
      delete_post_meta($postID, $count_key);
      add_post_meta($postID, $count_key, '0');
      return "0 ".esc_html__( 'View', 'autixir' );
  }
  return $count.' '.esc_html__( 'Views', 'autixir' );
}

/**
* { autixir_set_post_views }
*
* @param <int>  $postID  The post id
*/
function autixir_set_post_views( $postID ) {
  $count_key = 'autixir_post_views_count';
  $count = get_post_meta( $postID, $count_key, true );
  if($count==''){
      $count = 0;
      delete_post_meta( $postID, $count_key );
      add_post_meta( $postID, $count_key, '0' );
  }else{
      $count++;
      update_post_meta( $postID, $count_key, $count );
  }
}