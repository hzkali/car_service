<?php
/**
 * Banner widget.
 *
 * @since   1.0.0
 * @package autixir
 */
class autixir_Widget_Banner extends WP_Widget {

	function __construct() {
		$widget_ops  = array(
			'description' => esc_html__( 'Show off adds banner', 'autixir' )
		);
		$control_ops = array(
			'width'  => 'auto',
			'height' => 'auto'
		);
		parent::__construct( 'autixir_banner', esc_html__( 'Autixir - Banner', 'autixir' ), $widget_ops, $control_ops );
	}

	function widget( $args, $instance ) {
		extract( $args );
		$title   = apply_filters( 'widget_title', empty( $instance['title'] ) ? '' : $instance['title'], $instance, $this->id_base );

		$banner_url = empty( $instance['banner_url'] ) ? '' : $instance['banner_url'];
		$banner_img = empty( $instance['banner_img'] ) ? '' : $instance['banner_img'];

		echo wp_kses_post( $before_widget );

		if ( ! empty( $title ) ) {
			echo wp_kses_post( $before_title . $title . $after_title );
		}
		
		$output = '<div class="ltn__banner-widget">';

            if( !empty( $banner_img ) && !empty( $banner_url ) ){
            	$output .= '<a href="'.esc_url( $banner_url ).'"><img src="'.esc_url( $banner_img ).'" alt="'.esc_attr( $title ).'"></a>';
            }else{
            	if( !empty( $banner_img ) ){
	            	$output .= '<img src="'.esc_url( $banner_img ).'" alt="'.esc_attr( $title ).'">';
	            }
            }

		$output .= '</div>';

		echo wp_kses_post( $output . $after_widget );
	}

	function update( $new_instance, $old_instance ) {
		$instance          = $old_instance;
		$instance['title'] = strip_tags( $new_instance['title'] );
		$instance['banner_url']  = $new_instance['banner_url'];
		$instance['banner_img']  = $new_instance['banner_img'];

		return $instance;
	}

	function form( $instance ) {
		$instance  	= wp_parse_args( ( array ) $instance, array( 'banner_img' => '', 'title' => '', 'banner_url' => '' ) );
		$title     	= strip_tags( $instance['title'] );
		$banner_url = isset( $instance['banner_url'] ) ? $instance['banner_url'] : '';
		$banner_img = isset( $instance['banner_img'] ) ? $instance['banner_img'] : '';

		$image_output = ( $banner_img != '' ) ? '<div class="autixir_seleted_image"><img width="100" height="100" src="'.esc_url( $banner_img ).'" alt="'.esc_attr( $title ).'" /></div>' : '';
	?>

		<p>
	        <label for="<?php echo esc_attr( $this->get_field_id( 'banner_img' ) ); ?>"><?php echo esc_html__( 'Banner Image :', 'autixir' ); ?></label>
	        <div class="autixir_display"><?php echo wp_kses_post( $image_output ); ?></div>

	        <input class="widefat autixir-url" id="<?php echo esc_attr( $this->get_field_id( 'banner_img' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'banner_img' ) ); ?>" type="hidden" value="<?php echo esc_attr( $banner_img ); ?>" />

	        <input type="button" class="button autixir-browse" value="<?php echo esc_attr( 'Upload' ); ?>" />
	        <input type="button" class="button autixir-remove" value="<?php echo esc_attr( 'Remove' ); ?>" />
		</p>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php echo esc_html__( 'Title :', 'autixir' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
		</p>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'banner_url' ) ); ?>"><?php echo esc_html__( 'Banner URL :', 'autixir' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'banner_url' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'banner_url' ) ); ?>" type="text" value="<?php echo esc_attr( $banner_url ); ?>" />
		</p>

	<?php
	}
}