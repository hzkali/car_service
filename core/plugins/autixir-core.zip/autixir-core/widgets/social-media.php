<?php
/**
 * Author Info widget.
 *
 * @since   1.0.0
 * @package autixir
 */
class autixir_Widget_Social_Media extends WP_Widget {

	function __construct() {
		$widget_ops  = array(
			'description' => esc_html__( 'Show off social media link', 'autixir' )
		);
		$control_ops = array(
			'width'  => 'auto',
			'height' => 'auto'
		);
		parent::__construct( 'autixir_social_media', esc_html__( 'Autixir - Social Media', 'autixir' ), $widget_ops, $control_ops );
	}

	function widget( $args, $instance ) {
		extract( $args );
		$title   = apply_filters( 'widget_title', empty( $instance['title'] ) ? '' : $instance['title'], $instance, $this->id_base );

		$facebook  		= empty( $instance['facebook'] ) ? '' : $instance['facebook'];
		$twitter  		= empty( $instance['twitter'] ) ? '' : $instance['twitter'];
		$linkedin  		= empty( $instance['linkedin'] ) ? '' : $instance['linkedin'];
		$behance  		= empty( $instance['behance'] ) ? '' : $instance['behance'];
		$youtube  		= empty( $instance['youtube'] ) ? '' : $instance['youtube'];
		$instagram  		= empty( $instance['instagram'] ) ? '' : $instance['instagram'];

		echo wp_kses_post( $before_widget );

		if ( ! empty( $title ) ) {
			echo wp_kses_post( $before_title . $title . $after_title );
		}
		
		$output = '<div class="ltn__social-media-2">';

            if( !empty( $facebook ) || !empty( $twitter ) || !empty( $linkedin ) || !empty( $behance ) || !empty( $youtube ) || !empty( $instagram ) ){
	            $output .= '<ul>';

            		if( !empty( $facebook ) ){
	                    $output .= '<li><a href="'.esc_url( $facebook ).'" title="'.esc_attr( 'Facebook' ).'"><i class="fab fa-facebook-f"></i></a></li>';
	                }
            
            		if( !empty( $twitter ) ){
	                    $output .= '<li><a href="'.esc_url( $twitter ).'" title="'.esc_attr( 'Twitter' ).'"><i class="fab fa-twitter"></i></a></li>';
	                }
            
            		if( !empty( $linkedin ) ){
	                    $output .= '<li><a href="'.esc_url( $linkedin ).'" title="'.esc_attr( 'Linkedin' ).'"><i class="fab fa-linkedin"></i></a></li>';
	                }
            
            		if( !empty( $behance ) ){
	                    $output .= '<li><a href="'.esc_url( $behance ).'" title="'.esc_attr( 'Behance' ).'"><i class="fab fa-behance"></i></a></li>';
	                }
            
            		if( !empty( $youtube ) ){
	                    $output .= '<li><a href="'.esc_url( $youtube ).'" title="'.esc_attr( 'YouTube' ).'"><i class="fab fa-youtube"></i></a></li>';
	                }
            
            		if( !empty( $instagram ) ){
	                    $output .= '<li><a href="'.esc_url( $instagram ).'" title="'.esc_attr( 'Instagram' ).'"><i class="fab fa-instagram"></i></a></li>';
	                }

	            $output .= '</ul>';
	        }

		$output .= '</div>';

		echo wp_kses_post( $output . $after_widget );
	}

	function update( $new_instance, $old_instance ) {
		$instance          = $old_instance;
		$instance['title'] = strip_tags( $new_instance['title'] );

		$instance['facebook'] 	= $new_instance['facebook'];
		$instance['twitter'] 	= $new_instance['twitter'];
		$instance['linkedin'] 	= $new_instance['linkedin'];
		$instance['behance'] 	= $new_instance['behance'];
		$instance['youtube'] 	= $new_instance['youtube'];
		$instance['instagram'] 	= $new_instance['instagram'];

		return $instance;
	}

	function form( $instance ) {
		$instance  	= wp_parse_args( ( array ) $instance, array( 'title' => '' ) );
		$title     	= strip_tags( $instance['title'] );

		$facebook 	= isset( $instance['facebook'] ) ? $instance['facebook'] : '';
		$twitter 	= isset( $instance['twitter'] ) ? $instance['twitter'] : '';
		$linkedin 	= isset( $instance['linkedin'] ) ? $instance['linkedin'] : '';
		$behance 	= isset( $instance['behance'] ) ? $instance['behance'] : '';
		$youtube 	= isset( $instance['youtube'] ) ? $instance['youtube'] : '';
		$instagram 	= isset( $instance['instagram'] ) ? $instance['instagram'] : '';

	?>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php echo esc_html__( 'Title :', 'autixir' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
		</p>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'facebook' ) ); ?>"><?php echo esc_html__( 'Facebook link:', 'autixir' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'facebook' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'facebook' ) ); ?>" type="text" value="<?php echo esc_attr( $facebook ); ?>" />
		</p>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'twitter' ) ); ?>"><?php echo esc_html__( 'Twitter link:', 'autixir' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'twitter' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'twitter' ) ); ?>" type="text" value="<?php echo esc_attr( $twitter ); ?>" />
		</p>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'linkedin' ) ); ?>"><?php echo esc_html__( 'Linkedin link:', 'autixir' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'linkedin' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'linkedin' ) ); ?>" type="text" value="<?php echo esc_attr( $linkedin ); ?>" />
		</p>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'behance' ) ); ?>"><?php echo esc_html__( 'Behance link:', 'autixir' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'behance' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'behance' ) ); ?>" type="text" value="<?php echo esc_attr( $behance ); ?>" />
		</p>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'youtube' ) ); ?>"><?php echo esc_html__( 'YouTube link:', 'autixir' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'youtube' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'youtube' ) ); ?>" type="text" value="<?php echo esc_attr( $youtube ); ?>" />
		</p>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'instagram' ) ); ?>"><?php echo esc_html__( 'Instagram link:', 'autixir' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'instagram' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'instagram' ) ); ?>" type="text" value="<?php echo esc_attr( $instagram ); ?>" />
		</p>

	<?php
	}
}