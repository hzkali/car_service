<?php
/**
 * News Feed widget.
 *
 * @since   1.0.0
 * @package autixir
 */
class autixir_Widget_News_Feed extends WP_Widget {

	function __construct() {
		$widget_ops  = array(
			'description' => esc_html__( 'Show off blog post', 'autixir' )
		);
		$control_ops = array(
			'width'  => 'auto',
			'height' => 'auto'
		);
		parent::__construct( 'autixir_news_feed', esc_html__( 'Autixir - News Feed', 'autixir' ), $widget_ops, $control_ops );
	}

	function widget( $args, $instance ) {
		extract( $args );
		$title   = apply_filters( 'widget_title', empty( $instance['title'] ) ? '' : $instance['title'], $instance, $this->id_base );

		$limit 		= empty( $instance['limit'] ) ? 4 : $instance['limit'];
		$titlelimit = empty( $instance['titlelimit'] ) ? 10 : $instance['titlelimit'];

		echo wp_kses_post( $before_widget );

		if ( ! empty( $title ) ) {
			echo wp_kses_post( $before_title . $title . $after_title );
		}

		// Query Argument
        $args = array(
            'post_type'             => 'post',
            'post_status'           => 'publish',
            'ignore_sticky_posts'   => 1,
            'posts_per_page'        => $limit,
        );
        $news_feed = new WP_Query( $args );

        if( $news_feed->have_posts() ){

        	$output = '<div class="ltn__popular-post-widget"><ul>';

        		while( $news_feed->have_posts() ): $news_feed->the_post();
	    			ob_start();

	    			$archive_year  = get_the_time( 'Y' ); 
					$archive_month = get_the_time( 'm' ); 
					$archive_day   = get_the_time( 'd' );

	    			?>
	    				<li>
                            <div class="popular-post-widget-item clearfix">
                            	<?php if( has_post_thumbnail() ): ?>
	                                <div class="popular-post-widget-img">
	                                    <a href="<?php the_permalink(); ?>">
	                                    	<?php the_post_thumbnail( 'autixir-blog-sidebar' ); ?>
	                                    </a>
	                                </div>
	                            <?php endif ?>
                                <div class="popular-post-widget-brief">
                                    <h6><a href="<?php the_permalink(); ?>"><?php echo autixir_text_shorter( get_the_title(), $titlelimit ); ?></a></h6>
                                    <div class="ltn__blog-meta">
                                        <ul>
                                            <li class="ltn__blog-date">
                                                <a href="<?php echo esc_url( get_day_link( $archive_year, $archive_month, $archive_day ) ); ?>"><i class="far fa-calendar-alt"></i><?php the_time( 'F j, Y' ); ?></a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </li>
	    			<?php

	    			$output .= ob_get_clean();
        		endwhile; wp_reset_query(); wp_reset_postdata();

			$output .= '</ul></div>';

        }

		echo wp_kses_post( $output . $after_widget );
	}

	function update( $new_instance, $old_instance ) {
		$instance          = $old_instance;
		$instance['title'] = strip_tags( $new_instance['title'] );
		$instance['limit']  = $new_instance['limit'];
		$instance['titlelimit']  = $new_instance['titlelimit'];

		return $instance;
	}

	function form( $instance ) {
		$instance  	= wp_parse_args( ( array ) $instance, array( 'title' => '', 'limit' => 4, 'titlelimit'=>10 ) );
		$title     	= strip_tags( $instance['title'] );
		$limit 		= isset( $instance['limit'] ) ? $instance['limit'] : '';
		$titlelimit = isset( $instance['titlelimit'] ) ? $instance['titlelimit'] : '';
	?>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php echo esc_html__( 'Title :', 'autixir' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
		</p>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'limit' ) ); ?>"><?php echo esc_html__( 'Limit :', 'autixir' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'limit' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'limit' ) ); ?>" type="number" value="<?php echo esc_attr( $limit ); ?>" />
		</p>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'titlelimit' ) ); ?>"><?php echo esc_html__( 'News title limit :', 'autixir' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'titlelimit' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'titlelimit' ) ); ?>" type="number" value="<?php echo esc_attr( $titlelimit ); ?>" />
		</p>

	<?php
	}
}