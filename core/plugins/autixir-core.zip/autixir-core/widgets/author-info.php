<?php
/**
 * Author Info widget.
 *
 * @since   1.0.0
 * @package autixir
 */
class autixir_Widget_Author_Info extends WP_Widget {

	function __construct() {
		$widget_ops  = array(
			'description' => esc_html__( 'Show off Athor information', 'autixir' )
		);
		$control_ops = array(
			'width'  => 'auto',
			'height' => 'auto'
		);
		parent::__construct( 'autixir_author_info', esc_html__( 'Autixir - Author Info', 'autixir' ), $widget_ops, $control_ops );
	}

	function widget( $args, $instance ) {
		extract( $args );
		$title   = apply_filters( 'widget_title', empty( $instance['title'] ) ? '' : $instance['title'], $instance, $this->id_base );

		$name  		= empty( $instance['name'] ) ? '' : $instance['name'];
		$bio   		= empty( $instance['bio'] ) ? '' : $instance['bio'];
		$author_img = empty( $instance['author_img'] ) ? '' : $instance['author_img'];

		$facebook  		= empty( $instance['facebook'] ) ? '' : $instance['facebook'];
		$twitter  		= empty( $instance['twitter'] ) ? '' : $instance['twitter'];
		$linkedin  		= empty( $instance['linkedin'] ) ? '' : $instance['linkedin'];
		$behance  		= empty( $instance['behance'] ) ? '' : $instance['behance'];
		$youtube  		= empty( $instance['youtube'] ) ? '' : $instance['youtube'];

		echo wp_kses_post( $before_widget );

		if ( ! empty( $title ) ) {
			echo wp_kses_post( $before_title . $title . $after_title );
		}
		
		$output = '<div class="ltn__author-widget-inner text-center">';

            if( !empty( $author_img ) ){
            	$output .= '<img src="'.esc_url( $author_img ).'" alt="'.esc_attr( $name ).'">';
            }

            if( !empty( $name ) ){
            	$output .= '<h5>'.esc_html__( $name, 'autixir' ).'</h5>';
            }

            if( !empty( $bio ) ){
            	$output .= wpautop( $bio );
            }

            if( !empty( $facebook ) || !empty( $twitter ) || !empty( $linkedin ) || !empty( $behance ) || !empty( $youtube ) ){
	            $output .= '<div class="ltn__social-media"><ul>';

            		if( !empty( $facebook ) ){
	                    $output .= '<li><a href="'.esc_url( $facebook ).'" title="'.esc_attr( 'Facebook' ).'"><i class="fab fa-facebook-f"></i></a></li>';
	                }
            
            		if( !empty( $twitter ) ){
	                    $output .= '<li><a href="'.esc_url( $twitter ).'" title="'.esc_attr( 'Twitter' ).'"><i class="fab fa-twitter"></i></a></li>';
	                }
            
            		if( !empty( $linkedin ) ){
	                    $output .= '<li><a href="'.esc_url( $linkedin ).'" title="'.esc_attr( 'Linkedin' ).'"><i class="fab fa-linkedin"></i></a></li>';
	                }
            
            		if( !empty( $behance ) ){
	                    $output .= '<li><a href="'.esc_url( $behance ).'" title="'.esc_attr( 'Behance' ).'"><i class="fab fa-behance"></i></a></li>';
	                }
            
            		if( !empty( $youtube ) ){
	                    $output .= '<li><a href="'.esc_url( $youtube ).'" title="'.esc_attr( 'YouTube' ).'"><i class="fab fa-youtube"></i></a></li>';
	                }

	            $output .= '</ul></div>';
	        }

		$output .= '</div>';

		echo wp_kses_post( $output . $after_widget );
	}

	function update( $new_instance, $old_instance ) {
		$instance          = $old_instance;
		$instance['title'] = strip_tags( $new_instance['title'] );
		$instance['name']  = $new_instance['name'];
		$instance['bio']   = $new_instance['bio'];
		$instance['author_img'] = $new_instance['author_img'];

		$instance['facebook'] 	= $new_instance['facebook'];
		$instance['twitter'] 	= $new_instance['twitter'];
		$instance['linkedin'] 	= $new_instance['linkedin'];
		$instance['behance'] 	= $new_instance['behance'];
		$instance['youtube'] 	= $new_instance['youtube'];

		return $instance;
	}

	function form( $instance ) {
		$instance  	= wp_parse_args( ( array ) $instance, array( 'title' => '', 'name' => '', 'bio' => '', 'author_img' => '' ) );
		$title     	= strip_tags( $instance['title'] );
		$name      	= isset( $instance['name'] ) ? $instance['name'] : '';
		$bio       	= isset( $instance['bio'] ) ? $instance['bio'] : '';
		$author_img = isset( $instance['author_img'] ) ? $instance['author_img'] : '';

		$facebook 	= isset( $instance['facebook'] ) ? $instance['facebook'] : '';
		$twitter 	= isset( $instance['twitter'] ) ? $instance['twitter'] : '';
		$linkedin 	= isset( $instance['linkedin'] ) ? $instance['linkedin'] : '';
		$behance 	= isset( $instance['behance'] ) ? $instance['behance'] : '';
		$youtube 	= isset( $instance['youtube'] ) ? $instance['youtube'] : '';

		$image_output = ( $author_img != '' ) ? '<div class="autixir_seleted_image"><img width="100" height="100" src="'.esc_url( $author_img ).'" alt="'.esc_attr( $name ).'" /></div>' : '';
	?>

		<p>
	        <label for="<?php echo esc_attr( $this->get_field_id( 'author_img' ) ); ?>"><?php echo esc_html__( 'Author Image :', 'autixir' ); ?></label>
	        <div class="autixir_display"><?php echo wp_kses_post( $image_output ); ?></div>
	        <input class="widefat autixir-url" id="<?php echo esc_attr( $this->get_field_id( 'author_img' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'author_img' ) ); ?>" type="hidden" value="<?php echo esc_attr( $author_img ); ?>" />
	        <input type="button" class="button autixir-browse" value="<?php echo esc_attr( 'Upload' ); ?>" />
	        <input type="button" class="button autixir-remove" value="<?php echo esc_attr( 'Remove' ); ?>" />
		</p>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php echo esc_html__( 'Title :', 'autixir' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
		</p>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'name' ) ); ?>"><?php echo esc_html__( 'Author Name :', 'autixir' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'name' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'name' ) ); ?>" type="text" value="<?php echo esc_attr( $name ); ?>" />
		</p>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'bio' ) ); ?>"><?php echo esc_html__( 'Bio :' ,'autixir' ) ?></label>
			<textarea  id="<?php echo esc_attr( $this->get_field_id( 'bio' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'bio' ) ); ?>" rows="7" class="widefat" ><?php echo esc_textarea( $bio ); ?></textarea>
		</p>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'facebook' ) ); ?>"><?php echo esc_html__( 'Facebook profile link:', 'autixir' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'facebook' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'facebook' ) ); ?>" type="text" value="<?php echo esc_attr( $facebook ); ?>" />
		</p>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'twitter' ) ); ?>"><?php echo esc_html__( 'Twitter profile link:', 'autixir' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'twitter' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'twitter' ) ); ?>" type="text" value="<?php echo esc_attr( $twitter ); ?>" />
		</p>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'linkedin' ) ); ?>"><?php echo esc_html__( 'Linkedin profile link:', 'autixir' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'linkedin' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'linkedin' ) ); ?>" type="text" value="<?php echo esc_attr( $linkedin ); ?>" />
		</p>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'behance' ) ); ?>"><?php echo esc_html__( 'Behance profile link:', 'autixir' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'behance' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'behance' ) ); ?>" type="text" value="<?php echo esc_attr( $behance ); ?>" />
		</p>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'youtube' ) ); ?>"><?php echo esc_html__( 'YouTube channel link:', 'autixir' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'youtube' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'youtube' ) ); ?>" type="text" value="<?php echo esc_attr( $youtube ); ?>" />
		</p>

	<?php
	}
}