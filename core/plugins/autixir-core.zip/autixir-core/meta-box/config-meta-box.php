<?php
add_filter( 'rwmb_meta_boxes', 'autixir_meta_box' );

/**
 * Register meta boxes
 *
 * Remember to change "your_prefix" to actual prefix in your project
 *
 * @return void
 */
function autixir_meta_box( $meta_boxes ) {

	$prefix = 'autixir_meta';

	$posts_page = get_option( 'page_for_posts' );
	if ( ! isset( $_GET['post'] ) || intval( $_GET['post'] ) != $posts_page ) {
		$meta_boxes[] = array(
			'id'       => $prefix . '_page_meta_box',
			'title'    => esc_html__( 'Page Design Settings', 'autixir-core' ),
			'pages'    => array(
				'page',
			),
			'context'  => 'normal',
			'priority' => 'core',
			'fields'   => array(
				array(
					'id'      => "{$prefix}_show_breadcrumb",
					'name'    => esc_html__( 'Show Breadcrumb', 'autixir-core' ),
					'desc'    => '',
					'type'    => 'radio',
					'std'     => 'on',
					'options' => array(
						'on'  => 'Yes',
						'off' => 'No',
					),
				),
				array(
					'name'            => 'Header Style',
					'id'              => $prefix . '_header_style',
					'type'            => 'select_advanced',
					'options'         => array(
						'1' => 'Style 1',
						'2' => 'Style 2',
					),
				),
				array(
					'name'            => 'Breadcrumb Subtitle',
					'id'              => $prefix . '_breadcrumb_subtitle',
					'type'            => 'text',
				),
				array(
					'name'            => 'Footer Style',
					'id'              => $prefix . '_footer_style_select',
					'type'            => 'select_advanced',
					'options'         => array(
						'1' => 'Style 1',
						'2' => 'Style 2',
					),
				),
			),
		);

		$meta_boxes[] = array(
			'id'       => $prefix . '_team_meta_box',
			'title'    => esc_html__( 'Design Settings', 'autixir-core' ),
			'pages'    => array(
				'teams',
			),
			'context'  => 'normal',
			'priority' => 'core',
			'fields'   => array(
				array(
					'name'            => 'Designation',
					'id'              => $prefix . '_designation',
					'type'            => 'text',
				),
				array(
					'name'            => 'Facebook URL',
					'id'              => $prefix . '_fb_url',
					'type'            => 'text',
				),
				array(
					'name'            => 'Twitter URL',
					'id'              => $prefix . '_tw_url',
					'type'            => 'text',
				),
				array(
					'name'            => 'Linkedin URL',
					'id'              => $prefix . '_lnk_url',
					'type'            => 'text',
				),
			),
		);
	
	}
	return $meta_boxes;
}
