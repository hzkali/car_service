<?php
use Elementor\Utils;
use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use Elementor\Plugin;
use Elementor\Repeater;

class Autixir_Features_Two extends Widget_Base {

  public function get_name() {
    return 'Autixir_Features_two';
  }

  public function get_title() {
    return esc_html__( 'Autixir Features Two', 'autixir-core' );
  }

  public function get_icon() {
    return '';
  }

   public function get_categories() {
    return [ 'autixir' ];
  }
  
    protected function register_controls() {

      $this->start_controls_section(
         'content',
         [
           'label' => __( 'Content', 'autixir-core' ),
         ]
      );
      $this->add_control(
        'sub_heading',
        [
          'label' => __( 'Sub Heading', 'autixir-core' ),
          'type' => Controls_Manager::TEXT,
          'default' => __( '// Service', 'autixir-core' ),
        ]
      );
      $this->add_control(
        'heading',
        [
          'label' => __( 'Heading', 'autixir-core' ),
          'type' => Controls_Manager::TEXT,
          'default' => __( 'What We Do', 'autixir-core' ),
        ]
      );
          $repeater = new Repeater();
          $repeater->add_control(
            'title',
            [
              'label' => __( 'Title', 'autixir-core' ),
              'type' => Controls_Manager::TEXT,
              'default' => __( 'Reasonable Price', 'autixir-core' ),
            ]
          );
          $repeater->add_control(
            'content',
            [
              'label' => __( 'Content', 'autixir-core' ),
              'type' => Controls_Manager::TEXTAREA,
              'default' => __( 'Lorem ipsum dolor sit amet, consect etur adipisicing elit, sed do eiusmod tempor incididunt ut labore.', 'autixir-core' ),
            ]
          );
          $repeater->add_control(
            'icon',
            [
              'label' => __( 'Icon', 'autixir-core' ),
              'type' => Controls_Manager::ICONS,
            ]
          );
          $repeater->add_control(
            'btn_text',
            [
              'label' => __( 'Button Text', 'autixir-core' ),
              'type' => Controls_Manager::TEXT,
              'default' => __( 'Learn More', 'autixir-core' ),
            ]
          );
          $repeater->add_control(
            'btn_url',
            [
              'label' => __( 'Button URL', 'autixir-core' ),
              'type' => Controls_Manager::URL,
            ]
          );
      $this->add_control(
        'items1',
        [
          'label' => __( 'Repeater List', 'autixir-core' ),
          'type' => Controls_Manager::REPEATER,
          'fields' => $repeater->get_controls(),
          'default' => [
            [
              'list_title' => __( 'Title #1', 'autixir-core' ),
              'list_content' => __( 'Item content. Click the edit button to change this text.', 'autixir-core' ),
            ],
          ],
        ]
      );
      $this->add_control(
        'extra_class',
        [
          'label' => __( 'Extra Class', 'autixir-core' ),
          'type' => Controls_Manager::TEXT,
          'default' => __( '', 'autixir-core' ),
        ]
      );
      $this->end_controls_section();
  
    }    
    protected function render() {
      $settings =  $this->get_settings_for_display(); 
      $sub_heading = $settings["sub_heading"]; 
      $heading = $settings["heading"]; 
      $extra_class = $settings["extra_class"];
?>
      <div class="ltn__feature-area pb-90">
        <div class="container">
          <div class="row">
              <div class="col-lg-12">
                  <div class="section-title-area ltn__section-title-2 text-center">
                      <h6 class="section-subtitle ltn__secondary-color"><?php echo $sub_heading;?></h6>
                      <h1 class="section-title"><?php echo $heading;?><span>.</span></h1>
                  </div>
              </div>
          </div>
         <div class="row ltn__custom-gutter">
            <?php 
          foreach($settings["items1"] as $item){ 
            $title = $item["title"]; 
            $content = $item["content"]; 
            $btn_text = $item["btn_text"]; 
            $btn_url = $item["btn_url"]['url']; 
            $icon = $item["icon"]['value']; 
            ?>
                <div class="col-lg-3 col-sm-6 col-12">
                    <div class="ltn__feature-item ltn__feature-item-6">
                        <div class="ltn__feature-icon">
                            <span><i class="<?php echo $icon;?>"></i></span>
                        </div>
                        <div class="ltn__feature-info">
                            <h3><a href="<?php echo $btn_url;?>"><?php echo $title;?></a></h3>
                            <p><?php echo $content;?></p>
                            <a class="ltn__service-btn" href="<?php echo $btn_url;?>"><?php echo $btn_text;?></a>
                        </div>
                    </div>
                </div>
                <?php } ?> 
            </div>
        </div>
    </div>
 <?php 
    }
}

Plugin::instance()->widgets_manager->register_widget_type( new \Autixir_Features_Two() );