<?php
use Elementor\Utils;
use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use Elementor\Plugin;
use Elementor\Repeater;

class Autixir_ServiceTab_Item extends Widget_Base {

  public function get_name() {
    return 'Autixir_ServiceTab_Item';
  }

  public function get_title() {
    return esc_html__( 'Autixir Service Tab Item', 'autixir-core' );
  }

  public function get_icon() {
    return '';
  }

   public function get_categories() {
    return [ 'autixir' ];
  }
  
    protected function register_controls() {

            $this->start_controls_section(
              'content',
              [
                'label' => __( 'Content', 'autixir-core' ),
              ]
            );
            $this->add_control(
              'title',
              [
                'label' => __( 'Title', 'autixir-core' ),
                'type' => Controls_Manager::TEXT,
                'default' => __( 'PC Laptop Repair', 'autixir-core' ),
              ]
            );
            $this->add_control(
              'description',
              [
                'label' => __( 'Description', 'autixir-core' ),
                'type' => Controls_Manager::TEXTAREA,
              ]
            );
            $this->add_control(
              'content_list',
              [
                'label' => __( 'Content List', 'autixir-core' ),
                'type' => Controls_Manager::TEXTAREA,
              ]
            );
            $this->add_control(
              'btn_text',
              [
                'label' => __( 'Button Text', 'autixir-core' ),
                'type' => Controls_Manager::TEXT,
                'default' => __( 'Reed More', 'autixir-core' ),
              ]
            );
            $this->add_control(
              'btn_link',
              [
                'label' => __( 'Button Link', 'autixir-core' ),
                'type' => Controls_Manager::URL,
              ]
            );
            $this->add_control(
              'image',
              [
                'label' => __( 'Image', 'autixir-core' ),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                          'url' => Utils::get_placeholder_image_src(),
                      ],
                
              ]
            );
            $this->add_control(
              'title_class',
              [
                'label' => __( 'Title Class', 'autixir-core' ),
                'type' => Controls_Manager::TEXT,
                'default' => __( 'text-dark', 'autixir-core' ),
              ]
            );
 

      $this->end_controls_section();

  
    }    
    protected function render() {
      $settings =  $this->get_settings_for_display(); 
      $title = $settings["title"];
      $description = $settings["description"];
      $content_list = $settings["content_list"];
      $btn_text = $settings["btn_text"];
      $btn_link = $settings["btn_link"]['url'];
      $title_class = $settings["title_class"]; 
      $image = wp_get_attachment_image_url( $settings["image"]["id"],'full');
      
?>


<div class="service-item">
    <div class="row">
        <div class="col-md-12">
            <h2 class="h1 <?php echo $title_class;?> mb-25"><?php echo esc_html($title);?></h2>
        </div>
        <div class="col-md-7 order-1 order-md-0">
            <p class="text-gray"><?php echo wp_kses_post($description);?></p>
            <ul class="check-list mt-30 text-gray">
              <?php echo $content_list;?>
            </ul>
            <a href="<?php echo esc_url($btn_link);?>" class="btn btn-primary mt-35"><?php echo esc_html($btn_text);?></a>
        </div>
        <div class="col-md-5 col-sm-8 order-0 order-md-1 my-1 mb-4 my-md-0">
            <img class="img-fluid" src="<?php echo $image;?>" alt="">
        </div>
    </div>
</div>


 <?php 
    }
  
    protected function _content_template() {
      
    }
  }

Plugin::instance()->widgets_manager->register_widget_type( new \Autixir_ServiceTab_Item() );