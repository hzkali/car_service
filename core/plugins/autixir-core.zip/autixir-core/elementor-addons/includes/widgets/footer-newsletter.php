<?php
use Elementor\Utils;
use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use Elementor\Repeater;
use Elementor\Plugin;

class Autixir_Footer_Newsletter extends Widget_Base {

  public function get_name() {
    return 'autixir_footer_newsletter';
  }

  public function get_title() {
    return esc_html__( 'Autixir Footer Newsletter', 'autixir-core' );
  }

  public function get_icon() {
    return '';
  }

   public function get_categories() {
    return [ 'autixir' ];
  }
  
    protected function register_controls() {

      $this->start_controls_section(
         'content',
         [
           'label' => __( 'Content', 'autixir-core' ),
         ]
      );
      $this->add_control(
        'title',
        [
        'label' => __( 'Title', 'autixir-core' ),
        'type' => Controls_Manager::TEXT,
        'default' => __( 'Newsletter', 'autixir-core' ),
        ]
      );
        $this->add_control(
            'subtitle',
            [
            'label' => __( 'Subtitle', 'autixir-core' ),
            'type' => Controls_Manager::TEXTAREA,
            'default' => __( 'Subscribe to our weekly Newsletter and receive updates via email.', 'autixir-core' ),
            ]
        );
        $this->add_control(
          'form_shortcode',
          [
          'label' => __( 'Form Shortcode', 'autixir-core' ),
          'type' => Controls_Manager::TEXT,
          ]
        );
        $this->add_control(
          'payment_title',
          [
          'label' => __( 'Payment Method', 'autixir-core' ),
          'type' => Controls_Manager::TEXT,
          'default' => __( 'We Accept', 'autixir-core' ),
          ]
        );
        $this->add_control(
          'image',
          [
            'label' => __( 'Image', 'autixir-core' ),
            'type' => Controls_Manager::MEDIA,
            'default' => [
                      'url' => Utils::get_placeholder_image_src(),
                  ],
          ]
        );
      $this->end_controls_section();
    
    }    
    protected function render() {
      $settings =  $this->get_settings_for_display();
      $title = $settings["title"]; 
      $subtitle = $settings["subtitle"]; 
      $form_shortcode = $settings["form_shortcode"]; 
      $payment_title = $settings["payment_title"]; 
      $image = wp_get_attachment_image( $settings["image"]["id"],'full');
    ?>
        <div class="footer-widget footer-newsletter-widget">
            <h4 class="footer-title"><?php echo $title;?></h4>
            <p><?php echo $subtitle;?></p>
            <div class="footer-newsletter">
                <?php echo do_shortcode($form_shortcode);?>
            </div>
            <h5 class="mt-30"><?php echo $payment_title;?></h5>
            <?php echo $image;?>
        </div>
      <?php
    } 
}
Plugin::instance()->widgets_manager->register_widget_type( new \Autixir_Footer_Newsletter() );