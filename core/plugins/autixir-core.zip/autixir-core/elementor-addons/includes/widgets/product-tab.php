<?php
use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Utils;
use Elementor\Widget_Base;

class Autixir_Product_Tab extends Widget_Base {



	public function get_name() {
		return 'Autixir_Product_Tab';
	}

	public function get_title() {
		return esc_html__( 'Product Tab', 'autixir-core' );
	}

	public function get_icon() {
		return '';
	}

	public function get_categories() {
		return array( 'autixir' );
	}

	private function grid_get_all_post_type_categories() {
		$options  = array();
		$taxonomy = 'product_cat';
		if ( ! empty( $taxonomy ) ) {
			$terms = get_terms(
				array(
					'taxonomy'   => $taxonomy,
					'hide_empty' => false,
				)
			);
			if ( ! empty( $terms ) ) {
				foreach ( $terms as $term ) {
					if ( isset( $term ) ) {
						if ( isset( $term->slug ) && isset( $term->name ) ) {
							$options[ $term->slug ] = $term->name;
						}
					}
				}
			}
		}

		return $options;
	}

	protected function register_controls() {

		$this->start_controls_section(
			'general_setting',
			array(
				'label' => esc_html__( 'General Settings', 'autixir-core' ),
			)
		);

		$this->add_control(
			'title',
			array(
				'label'   => esc_html__( 'Title', 'autixir' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( 'Our Recent Products', 'autixir' ),
			)
		);

		$this->add_control(
			'subtitle',
			array(
				'label'   => esc_html__( 'Sub Title', 'autixir' ),
				'type'    => Controls_Manager::TEXTAREA,
				'default' => __( 'Do commanded an shameless we disposing do. Indulgence ten remarkably nor are impression out.', 'autixir' ),
			)
		);


		$this->add_control(
			'product_style',
			array(
				'label'   => esc_html__( 'Select Product Style', 'autixir-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'grid',
				'options' => array(
					'grid'   => esc_html__( 'Grid', 'autixir-core' ),
					'slider' => esc_html__( 'Slider', 'autixir-core' ),
				),
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'content_settings',
			array(
				'label' => esc_html__( 'Content Settings', 'autixir-core' ),
			)
		);

		$this->add_control(
			'product_per_page',
			array(
				'label'   => esc_html__( 'Number of Products', 'autixir-core' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => esc_html__( 8, 'autixir-core' ),
			)
		);

		$this->add_control(
			'product_order_by',
			array(
				'label'   => esc_html__( 'Order By', 'autixir-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'date',
				'options' => array(
					'date'          => esc_html__( 'Date', 'autixir-core' ),
					'ID'            => esc_html__( 'ID', 'autixir-core' ),
					'author'        => esc_html__( 'Author', 'autixir-core' ),
					'title'         => esc_html__( 'Title', 'autixir-core' ),
					'modified'      => esc_html__( 'Modified', 'autixir-core' ),
					'rand'          => esc_html__( 'Random', 'autixir-core' ),
					'comment_count' => esc_html__( 'Comment count', 'autixir-core' ),
					'menu_order'    => esc_html__( 'Menu order', 'autixir-core' ),
				),
			)
		);

		$this->add_control(
			'product_order',
			array(
				'label'   => esc_html__( 'Product Order', 'autixir-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'DESC',
				'options' => array(
					'DESC' => esc_html__( 'DESC', 'autixir-core' ),
					'ASC'  => esc_html__( 'ASC', 'autixir-core' ),
				),
			)
		);

		$this->add_control(
			'extra_class',
			array(
				'label' => esc_html__( 'Extra Class', 'autixir-core' ),
				'type'  => Controls_Manager::TEXT,
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_additional_options',
			array(
				'label' => esc_html__( 'Slider Settings', 'autixir-core' ),
			)
		);

		$this->add_control(
			'dots',
			array(
				'label'   => esc_html__( 'Enable Dots', 'autixir-core' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'no',
			)
		);

		$this->add_control(
			'arrows',
			array(
				'label'   => esc_html__( 'Enable Arrows', 'autixir-core' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			)
		);
		$this->add_control(
			'infinite',
			array(
				'label'   => esc_html__( 'Enable Infinite', 'autixir-core' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			)
		);

		$this->add_control(
			'speed',
			array(
				'label'              => esc_html__( 'Speed', 'autixir-core' ),
				'type'               => Controls_Manager::NUMBER,
				'default'            => 300,
				'frontend_available' => true,
			)
		);

		$this->add_control(
			'slidesToShow',
			array(
				'label'              => esc_html__( 'Slides To Show', 'autixir-core' ),
				'type'               => Controls_Manager::NUMBER,
				'default'            => 4,
				'frontend_available' => true,
			)
		);

		$this->add_control(
			'slidesToScroll',
			array(
				'label'              => esc_html__( 'Slides To Scroll', 'autixir-core' ),
				'type'               => Controls_Manager::NUMBER,
				'default'            => 4,
				'frontend_available' => true,
			)
		);
		$this->end_controls_section();
	}

	protected function render() {
		$settings          = $this->get_settings();
		$product_style     = $settings['product_style'];
		$subtitle           = $settings['subtitle'];
		$title             = $settings['title'];
		$extra_class             = $settings['extra_class'];
		$product_per_page  = $settings['product_per_page'];
		
		$product_order_by  = $settings['product_order_by'];
		$product_order     = $settings['product_order'];

		if ( $settings['dots'] == 'yes' ) {
			$dots = true;
		} else {
			$dots = false;
		}
		if ( $settings['arrows'] == 'yes' ) {
			$arrows = true;
		} else {
			$arrows = false;
		}
		if ( $settings['infinite'] == 'yes' ) {
			$infinite = true;
		} else {
			$infinite = false;
		}

		$atts = array(
			'dots'           => $dots,
			'arrows'         => $arrows,
			'infinite'       => $infinite,
			'speed'          => $settings['speed'],
			'slidesToShow'   => ! empty( $settings['slidesToShow'] ) ? $settings['slidesToShow'] : 4,
			'slidesToScroll' => ! empty( $settings['slidesToScroll'] ) ? $settings['slidesToScroll'] : 4,
		);
		?>
<?php if($product_style == 'grid'){?>
<section class="section bg-light-gray <?php echo esc_attr( $extra_class ); ?>">
    <div class="container">
		<div class="row justify-content-center">
			<div class="col-lg-6 col-md-8 text-center">
				<h2 class="section-heading h1 text-dark mb-30"><?php echo $title; ?></h2>
				<p class="mb-40"><?php echo $subtitle; ?>.</p>
			</div>
		</div>
		<?php 
		$taxonomy = 'product_cat';
		if ( ! empty( $taxonomy ) ) {
			$terms = get_terms(
				array(
					'taxonomy'   => $taxonomy,
					'hide_empty' => false,
				)
			);
		?>
		<div class="row justify-content-center">
			<div class="col-xl-9 text-center mb-10">
				<div class="btn-group product-filter-buttons-2">
					<button class="btn active" data-filter="*">All items</button>
					<?php
					if ( ! empty( $terms ) ) {
						foreach ( $terms as $key => $term ) {
							if ( isset( $term ) ) {
								if ( isset( $term->slug ) && isset( $term->name ) ) {
									if($term->name != 'Uncategorized'){
									?>
									<button class="btn" data-filter=".<?php echo $term->slug;?>"><?php echo $term->name;?></button>
									<?php
									}
								}
							}
						}
					}
					?>
				</div>
			</div>
		</div>
		<?php } ?>
			<?php
			$args = array(
				'post_type'      => 'product',
				'posts_per_page' => $product_per_page,
				'orderby'        => $product_order_by,
				'order'          => $product_order,
			);

			$loop = new \WP_Query( $args );

			if ( $loop->have_posts() ) {
				?>
			<div class="row jsFilter">
				<?php
				while ( $loop->have_posts() ) :
					$loop->the_post();
					if ( class_exists( 'WooCommerce' ) ) {
						global $product;
						$cats =  wp_get_post_terms($product->get_id(), 'product_cat',  array("fields" => "names"));
						$cats = strtolower(implode(" ",$cats));
						?>
						<div class="col-lg-4 col-md-6 <?php echo $cats; ?>">
						<?php
						wc_get_template_part( 'tabcontent', 'product' );
						?>
						</div>
						<?php
					} else {
						echo __( '<p class="text-center">WooCommerce Not Active.</p>', 'autixir-core' );
					}
				endwhile;
				?>
			</div>
				<?php
			} else {
				echo __( '<p class="text-center">No products found.</p>', 'autixir-core' );
			}
			wp_reset_query();
			?>
	</div>
</section>
<?php }elseif($product_style == 'slider'){?>
	<section class="section bg-light-gray <?php echo esc_attr( $extra_class ); ?>">
    <div class="container">
		<div class="row justify-content-center">
			<div class="col-lg-6 col-md-8 text-center">
				<h2 class="section-heading h1 text-dark mb-30"><?php echo $title; ?></h2>
				<p class="mb-40"><?php echo $subtitle; ?>.</p>
			</div>
		</div>
		<?php 
		$taxonomy = 'product_cat';
		if ( ! empty( $taxonomy ) ) {
			$terms = get_terms(
				array(
					'taxonomy'   => $taxonomy,
					'hide_empty' => false,
				)
			);
		?>
	</div>
	<div class="carousel-fluid">
		<div class="row no-gutters justify-content-center">
			<div class="col-xl-9 text-center mb-40">
				<div class="btn-group product-filter-buttons">
					<button type="button" class="btn active" data-owl-filter="*">All items</button>
					<?php
					if ( ! empty( $terms ) ) {
						foreach ( $terms as $key => $term ) {
							if ( isset( $term ) ) {
								if ( isset( $term->slug ) && isset( $term->name ) ) {
									if($term->name != 'Uncategorized'){
									?>
									<button type="button" class="btn" data-owl-filter=".<?php echo $term->slug;?>"><?php echo $term->name;?></button>
									<?php
									}
								}
							}
						}
					}
					?>
				</div>
			</div>
		<?php } ?>
			<?php
			$args = array(
				'post_type'      => 'product',
				'posts_per_page' => $product_per_page,
				'orderby'        => $product_order_by,
				'order'          => $product_order,
			);

			$loop = new \WP_Query( $args );

			if ( $loop->have_posts() ) {
				?>
			<div class="col-md-12">
			<div class="owl-carousel fluid-carousel">
				<?php
				while ( $loop->have_posts() ) :
					$loop->the_post();
					if ( class_exists( 'WooCommerce' ) ) {
						global $product;
						$cats =  wp_get_post_terms($product->get_id(), 'product_cat',  array("fields" => "names"));
						$cats = strtolower(implode(" ",$cats));
						?>
						<div class=" <?php echo $cats; ?>">
						<?php
						wc_get_template_part( 'tabcontent', 'product' );
						?>
						</div>
						<?php
					} else {
						echo __( '<p class="text-center">WooCommerce Not Active.</p>', 'autixir-core' );
					}
				endwhile;
				?>
			</div>
			</div>
				<?php
			} else {
				echo __( '<p class="text-center">No products found.</p>', 'autixir-core' );
			}
			wp_reset_query();
			?>
	</div>
</section>
		<?php
		}
	}

	protected function _content_template() {

	}

}
Plugin::instance()->widgets_manager->register_widget_type( new \Autixir_Product_Tab() );