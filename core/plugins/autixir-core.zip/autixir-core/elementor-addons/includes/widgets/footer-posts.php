<?php
if (!defined('ABSPATH')) {
    exit;
}

use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Utils;
use Elementor\Widget_Base;

class Autixir_Footer_Posts extends Widget_Base {

    public function get_name() {
        return 'autixir_footer_posts';
    }

    public function get_title() {
        return esc_html__('Autixir Footer Posts', 'autixir-core');
    }

    public function get_icon() {
        return 'eicon-post';
    }

    public function get_categories() {
        return ['autixir'];
    }

    private function get_blog_categories() {
        $options = array();
        $taxonomy = 'category';
        if (!empty($taxonomy)) {
            $terms = get_terms(
                    array(
                        'parent' => 0,
                        'taxonomy' => $taxonomy,
                        'hide_empty' => false,
                    )
            );
            if (!empty($terms)) {
                foreach ($terms as $term) {
                    if (isset($term)) {
                        $options[''] = 'Select';
                        if (isset($term->slug) && isset($term->name)) {
                            $options[$term->slug] = $term->name;
                        }
                    }
                }
            }
        }
        return $options;
    }

    protected function register_controls() {

        $this->start_controls_section(
            'section_blogs', [
                'label' => esc_html__('Posts', 'autixir-core'),
            ]
        );
        $this->add_control(
            'title', [
                'label' => esc_html__('Title', 'autixir-core'),
                'type' => Controls_Manager::TEXT,
                'default' => __('News Feeds','autixir-core'),
            ]
        );
        $this->add_control(
            'category_id', [
                'type' => Controls_Manager::SELECT,
                'label' => esc_html__('Category', 'autixir-core'),
                'options' => $this->get_blog_categories()
            ]
        );

        $this->add_control(
            'number', [
                'label' => esc_html__('Number of Post', 'autixir-core'),
                'type' => Controls_Manager::NUMBER,
                'default' => 3
            ]
        );

        $this->add_control(
            'order_by', [
                'label' => esc_html__('Order By', 'autixir-core'),
                'type' => Controls_Manager::SELECT,
                'default' => 'date',
                'options' => [
                    'date' => esc_html__('Date', 'autixir-core'),
                    'ID' => esc_html__('ID', 'autixir-core'),
                    'author' => esc_html__('Author', 'autixir-core'),
                    'title' => esc_html__('Title', 'autixir-core'),
                    'modified' => esc_html__('Modified', 'autixir-core'),
                    'rand' => esc_html__('Random', 'autixir-core'),
                    'comment_count' => esc_html__('Comment count', 'autixir-core'),
                    'menu_order' => esc_html__('Menu order', 'autixir-core')
                ]
            ]
        );

        $this->add_control(
            'order', [
                'label' => esc_html__('Order', 'autixir-core'),
                'type' => Controls_Manager::SELECT,
                'default' => 'desc',
                'options' => [
                    'desc' => esc_html__('DESC', 'autixir-core'),
                    'asc' => esc_html__('ASC', 'autixir-core')
                ]
            ]
        );

        $this->add_control(
            'extra_class', [
                'label' => esc_html__('Extra Class', 'autixir-core'),
                'type' => Controls_Manager::TEXT
            ]
        );
        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings();
        $title = $settings['title'];
        $extra_class = $settings['extra_class'];
        $posts_per_page = $settings['number'];
 
        $order_by = $settings['order_by'];
        $order = $settings['order'];
        $pg_num = get_query_var('paged') ? get_query_var('paged') : 1;
        $args = array(
            'post_type' => array('post'),
            'post_status' => array('publish'),
            'nopaging' => false,
            'paged' => $pg_num,
            'posts_per_page' => $posts_per_page,
            'category_name' => $settings['category_id'],
            'orderby' => $order_by,
            'order' => $order,
        );
        $query = new WP_Query($args);
        ?>
    <div class="footer-widget footer-blog-widget <?php echo $extra_class;?>">
        <h4 class="footer-title"><?php echo $title;?></h4>
        <?php
        if ($query->have_posts()) {
            while ($query->have_posts()) {
            $query->the_post();
        ?>  
        <div class="ltn__footer-blog-item">
            <div class="ltn__blog-meta">
                <ul>
                    <li class="ltn__blog-date"><i class="far fa-calendar-alt"></i> <?php echo get_the_date('M d, Y');?></li>
                </ul>
            </div>
            <h4 class="ltn__blog-title"><a href="<?php the_permalink(); ?>"><?php the_title();?></a></h4>
        </div>
        <?php
        }
        wp_reset_postdata();
        }
        ?>
    </div>
    <?php
    }
}

Plugin::instance()->widgets_manager->register_widget_type(new Autixir_Footer_Posts());
