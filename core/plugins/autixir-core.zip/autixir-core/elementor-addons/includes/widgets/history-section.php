<?php
use Elementor\Utils;
use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use Elementor\Repeater;
use Elementor\Plugin;

class Autixir_History extends Widget_Base {

  public function get_name() {
    return 'autixir_history';
  }

  public function get_title() {
    return esc_html__( 'Autixir History', 'autixir-core' );
  }

  public function get_icon() {
    return '';
  }

   public function get_categories() {
    return [ 'autixir' ];
  }
  
    protected function register_controls() {

      $this->start_controls_section(
         'content',
         [
           'label' => __( 'Content', 'autixir-core' ),
         ]
      );
  
          $this->add_control(
            'bg_image',
            [
              'label' => __( 'Background Image', 'autixir-core' ),
              'type' => Controls_Manager::MEDIA,
              'default' => [
                        'url' => Utils::get_placeholder_image_src(),
                    ],
            ]
          );

          $repeater = new Repeater();
          $repeater->add_control(
            'title',
            [
              'label' => __( 'Title', 'autixir-core' ),
              'type' => Controls_Manager::TEXT,
              'default' => __( 'Started Journey', 'autixir-core' ),
            ]
          );
          $repeater->add_control(
            'content',
            [
              'label' => __( 'Content', 'autixir-core' ),
              'type' => Controls_Manager::TEXT,
              'default' => __( 'Lorem ipsum dolor sit amet, consectetur ad ipisic ing elit, sed do eiusmod tempor.', 'autixir-core' ),
            ]
          );
          $repeater->add_control(
            'year',
            [
              'label' => __( 'Year', 'autixir-core' ),
              'type' => Controls_Manager::TEXT,
              'default' => __( '1900', 'autixir-core' ),
            ]
          );
          $repeater->add_control(
            'image',
            [
              'label' => __( 'Image', 'autixir-core' ),
              'type' => Controls_Manager::MEDIA,
              'default' => [
                        'url' => Utils::get_placeholder_image_src(),
                    ],
            ]
          );
      $this->add_control(
        'items1',
        [
          'label' => __( 'Repeater List', 'autixir-core' ),
          'type' => Controls_Manager::REPEATER,
          'fields' => $repeater->get_controls(),
          'default' => [
            [
              'list_title' => __( 'Title #1', 'autixir-core' ),
              'list_content' => __( 'Item content. Click the edit button to change this text.', 'autixir-core' ),
            ],
            [
              'list_title' => __( 'Title #2', 'autixir-core' ),
              'list_content' => __( 'Item content. Click the edit button to change this text.', 'autixir-core' ),
            ],
          ],
        ]
      );
  
      $this->end_controls_section();
    }    
    protected function render() {
      $settings =  $this->get_settings_for_display();
      $bg_image = wp_get_attachment_image_url( $settings["bg_image"]["id"],'full');
    ?>

    <div class="ltn__our-journey-area bg-image bg-overlay-theme-90 pt-280 pb-350 mb-35 plr--9" data-bs-bg="<?php echo $bg_image;?>">
        <div class="container-fluid">
            <div class="row"> 
                <div class="col-lg-12">
                    <div class="ltn__our-journey-wrap ">
                        <ul>
                        <?php
                          $i = 0;
                          foreach($settings["items1"] as $item){ 
                            $title = $item["title"]; 
                            $content = $item["content"];
                            $year = $item["year"];
                            $image = wp_get_attachment_image( $item["image"]["id"],'full');
                            $i++;
                            if($i == 2){
                              $active = 'class="active"';
                            }else{
                              $active = null;
                            }
                            ?>
                            <li <?php echo $active;?>><span class="ltn__journey-icon"><?php echo $year; ?></span>
                                <ul>
                                    <li>
                                        <div class="ltn__journey-history-item-info clearfix">
                                            <div class="ltn__journey-history-img">
                                                <?php echo $image;?>
                                            </div>
                                            <div class="ltn__journey-history-info">
                                                <h3><?php echo $title; ?></h3>
                                                <p><?php echo $content; ?></p>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </li>
                            <?php } ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

      <?php
    } 
}
Plugin::instance()->widgets_manager->register_widget_type( new \Autixir_History() );