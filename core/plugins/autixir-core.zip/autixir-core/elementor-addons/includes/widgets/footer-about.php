<?php
use Elementor\Utils;
use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use Elementor\Repeater;
use Elementor\Plugin;

class Autixir_Footer_About extends Widget_Base {

  public function get_name() {
    return 'autixir_footer_about';
  }

  public function get_title() {
    return esc_html__( 'Autixir Footer About', 'autixir-core' );
  }

  public function get_icon() {
    return '';
  }

   public function get_categories() {
    return [ 'autixir' ];
  }
  
    protected function register_controls() {

      $this->start_controls_section(
         'content',
         [
           'label' => __( 'Content', 'autixir-core' ),
         ]
      );
      $this->add_control(
        'image',
        [
          'label' => __( 'Logo Image', 'autixir-core' ),
          'type' => Controls_Manager::MEDIA,
          'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
        ]
      );
        $this->add_control(
            'subtitle',
            [
            'label' => __( 'Subtitle', 'autixir-core' ),
            'type' => Controls_Manager::TEXTAREA,
            'default' => __( 'Lorem Ipsum is simply dummy text of the and typesetting industry. Lorem Ipsum is dummy text of the printing.', 'autixir-core' ),
            ]
        );

          $repeater = new Repeater();
          $repeater->add_control(
            'icon',
            [
              'label' => __( 'Icon', 'autixir-core' ),
              'type' => Controls_Manager::ICONS,
            ]
          );
          $repeater->add_control(
            'text',
            [
              'label' => __( 'Text', 'autixir-core' ),
              'type' => Controls_Manager::TEXT,
              'default' => __( 'Brooklyn, New York, United States', 'autixir-core' ),
            ]
          );
      $this->add_control(
        'items1',
        [
          'label' => __( 'Repeater List', 'autixir-core' ),
          'type' => Controls_Manager::REPEATER,
          'fields' => $repeater->get_controls(),
          'default' => [
            [
              'list_title' => __( 'Title #1', 'autixir-core' ),
              'list_content' => __( 'Item content. Click the edit button to change this text.', 'autixir-core' ),
            ],
          ],
        ]
      );
      $this->end_controls_section();
      $this->start_controls_section(
        'social_media',
        [
          'label' => __( 'Social Media', 'autixir-core' ),
        ]
       );

       $repeater2 = new Repeater();
       $repeater2->add_control(
         'social_icon',
         [
           'label' => __( 'Icon', 'autixir-core' ),
           'type' => Controls_Manager::ICONS,
         ]
       );
       $repeater2->add_control(
         'social_url',
         [
           'label' => __( 'URL', 'autixir-core' ),
           'type' => Controls_Manager::URL,
         ]
       );
   $this->add_control(
     'items2',
     [
       'label' => __( 'Repeater List', 'autixir-core' ),
       'type' => Controls_Manager::REPEATER,
       'fields' => $repeater2->get_controls(),
       'default' => [
         [
           'list_title' => __( 'Title #1', 'autixir-core' ),
           'list_content' => __( 'Item content. Click the edit button to change this text.', 'autixir-core' ),
         ],
       ],
     ]
   );

      $this->end_controls_section();
    }    
    protected function render() {
      $settings =  $this->get_settings_for_display();
      $subtitle = $settings["subtitle"]; 
      $image = wp_get_attachment_image( $settings["image"]["id"],'full');
    ?>

        <div class="footer-widget footer-about-widget">
              <div class="footer-logo">
                  <div class="site-logo">
                      <?php echo $image;?>
                  </div>
              </div>
              <p><?php echo $subtitle;?></p>
              <div class="footer-address">
                  <ul>
                    <?php
                    foreach($settings["items1"] as $item){ 
                        $icon = $item["icon"]['value']; 
                        $text = $item["text"];
                    ?>
                     <li>
                          <div class="footer-address-icon">
                              <i class="<?php echo $icon;?>"></i>
                          </div>
                          <div class="footer-address-info">
                              <p><?php echo $text;?></p>
                          </div>
                      </li>
                    <?php } ?>
                  </ul>
              </div>
              <div class="ltn__social-media mt-20">
                  <ul>
                  <?php
                    foreach($settings["items2"] as $item){ 
                        $social_icon = $item["social_icon"]['value']; 
                        $social_url = $item["social_url"]['url'];
                    ?>
                      <li><a href="<?php echo esc_url($social_url); ?>"><i class="<?php echo $social_icon;?>"></i></a></li>
                    <?php } ?>
                  </ul>
              </div>
        </div>

      <?php
    } 
}
Plugin::instance()->widgets_manager->register_widget_type( new \Autixir_Footer_About() );