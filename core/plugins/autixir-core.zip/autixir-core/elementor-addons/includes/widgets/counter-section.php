<?php
use Elementor\Utils;
use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use Elementor\Plugin;
use Elementor\Repeater;

class Autixir_CounterUp extends Widget_Base {

  public function get_name() {
    return 'autixir_counterup';
  }

  public function get_title() {
    return esc_html__( 'Autixir Counterup', 'autixir-core' );
  }

  public function get_icon() {
    return '';
  }

   public function get_categories() {
    return [ 'autixir' ];
  }
  
    protected function register_controls() {

      $this->start_controls_section(
         'content',
         [
           'label' => __( 'Content', 'autixir-core' ),
         ]
      );
          $this->add_control(
            'sub_heading',
            [
              'label' => __( 'Sub Heading', 'autixir-core' ),
              'type' => Controls_Manager::TEXT,
              'default' => __( '// activity', 'autixir-core' ),
            ]
          );
          $this->add_control(
            'heading',
            [
              'label' => __( 'Heading', 'autixir-core' ),
              'type' => Controls_Manager::TEXT,
              'default' => __( 'It’s Our Journey', 'autixir-core' ),
            ]
          );
          $this->add_control(
            'background',
            [
              'label' => __( 'Background', 'autixir-core' ),
              'type' => Controls_Manager::MEDIA,
              'default' => [
                        'url' => Utils::get_placeholder_image_src(),
                    ],
            ]
          );  
          $repeater = new Repeater();
          $repeater->add_control(
            'title',
            [
              'label' => __( 'Title', 'autixir-core' ),
              'type' => Controls_Manager::TEXT,
              'default' => __( 'Active Clients', 'autixir-core' ),
            ]
          );
          $repeater->add_control(
            'count_number',
            [
              'label' => __( 'Count Number', 'autixir-core' ),
              'type' => Controls_Manager::TEXT,
              'default' => __( '733', 'autixir-core' ),
            ]
          );
          $repeater->add_control(
            'symble',
            [
              'label' => __( 'Symble', 'autixir-core' ),
              'type' => Controls_Manager::TEXT,
            ]
          );
      $this->add_control(
        'items1',
        [
          'label' => __( 'Repeater List', 'autixir-core' ),
          'type' => Controls_Manager::REPEATER,
          'fields' => $repeater->get_controls(),
          'default' => [
            [
              'list_title' => __( 'Title #1', 'autixir-core' ),
              'list_content' => __( 'Item content. Click the edit button to change this text.', 'autixir-core' ),
            ],
          ],
        ]
      );
      $this->add_control(
        'extra_class',
        [
          'label' => __( 'Extra Class', 'autixir-core' ),
          'type' => Controls_Manager::TEXT,
        ]
      );
      $this->end_controls_section();
  
    }    
    protected function render() {
      $settings =  $this->get_settings_for_display(); 
      $sub_heading = $settings["sub_heading"];
      $heading = $settings["heading"];
      $background = wp_get_attachment_image_url( $settings["background"] ["id"],'full');
      $extra_class = $settings["extra_class"];
?>
    <div class="ltn__counterup-area bg-image bg-overlay-theme-black-80 pt-115 pb-70" data-bs-bg="<?php echo $background;?>">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-12">
                    <div class="section-title-area ltn__section-title-2">
                        <h6 class="section-subtitle white-color"><?php echo $sub_heading;?></h6>
                        <h1 class="section-title white-color"><?php echo $heading;?><span>.</span></h1>
                    </div>
                </div>
                <?php 
                foreach($settings["items1"] as $item){ 
                  $title = $item["title"]; 
                  $count_number = $item["count_number"];
                  $symble = $item["symble"];
                  ?>
                <div class="col-lg-2 col-md-3 col-sm-6 align-self-center">
                    <div class="ltn__counterup-item-3 text-color-white">
                        <div class="counter-icon"> // </div>
                        <h1>
                        <span class="counter"><?php echo $count_number;?></span><?php if($symble){?><span class="counterUp-letter"><?php echo $symble;?></span><?php } ?><span class="counterUp-icon">+</span>
                        </h1>
                        <h6><?php echo $title;?></h6>
                    </div>
                </div>
                <?php } ?> 
            </div>
        </div>
    </div>
 <?php 
    }
}

Plugin::instance()->widgets_manager->register_widget_type( new \Autixir_CounterUp() );