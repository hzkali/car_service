<?php
use Elementor\Utils;
use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use Elementor\Plugin;
use Elementor\Repeater;

class Autixir_Features extends Widget_Base {

  public function get_name() {
    return 'Autixir_Features';
  }

  public function get_title() {
    return esc_html__( 'Autixir Features', 'autixir-core' );
  }

  public function get_icon() {
    return '';
  }

   public function get_categories() {
    return [ 'autixir' ];
  }
  
    protected function register_controls() {

      $this->start_controls_section(
         'content',
         [
           'label' => __( 'Content', 'autixir-core' ),
         ]
      );
          $repeater = new Repeater();
          $repeater->add_control(
            'title',
            [
              'label' => __( 'Title', 'autixir-core' ),
              'type' => Controls_Manager::TEXT,
              'default' => __( 'Reasonable Price', 'autixir-core' ),
            ]
          );
          $repeater->add_control(
            'content',
            [
              'label' => __( 'Content', 'autixir-core' ),
              'type' => Controls_Manager::TEXTAREA,
              'default' => __( 'Lorem ipsum dolor sit amet, consect etur adipisicing elit, sed do eiusmod tempor incididunt ut labore.', 'autixir-core' ),
            ]
          );
          $repeater->add_control(
            'icon',
            [
              'label' => __( 'Icon', 'autixir-core' ),
              'type' => Controls_Manager::ICONS,
            ]
          );
          $repeater->add_control(
            'btn_text',
            [
              'label' => __( 'Button Text', 'autixir-core' ),
              'type' => Controls_Manager::TEXT,
              'default' => __( 'Learn More', 'autixir-core' ),
            ]
          );
          $repeater->add_control(
            'btn_url',
            [
              'label' => __( 'Button URL', 'autixir-core' ),
              'type' => Controls_Manager::URL,
            ]
          );
          $repeater->add_control(
            'select_style',
            [
              'label' => __( 'Select Style', 'autixir-core' ),
              'type' => Controls_Manager::SELECT,
              'default' => 'style_1',
              'options' => array(
                'style_1' => __( 'Style 1', 'plugin-core' ),
                'style_2' => __( 'Style 2', 'plugin-core' ),
                'style_3' => __( 'Style 3', 'plugin-core' ),
              ),
            ]
          );
          $repeater->add_control(
            'bg_image',
            [
              'label' => __( 'BG Image', 'autixir-core' ),
              'type' => Controls_Manager::MEDIA,
              'condition' => array('select_style' => 'style_2'),
            ]
          );
      $this->add_control(
        'items1',
        [
          'label' => __( 'Repeater List', 'autixir-core' ),
          'type' => Controls_Manager::REPEATER,
          'fields' => $repeater->get_controls(),
          'default' => [
            [
              'list_title' => __( 'Title #1', 'autixir-core' ),
              'list_content' => __( 'Item content. Click the edit button to change this text.', 'autixir-core' ),
            ],
          ],
        ]
      );
      $this->add_control(
        'extra_class',
        [
          'label' => __( 'Extra Class', 'autixir-core' ),
          'type' => Controls_Manager::TEXT,
          'default' => __( '', 'autixir-core' ),
        ]
      );
      $this->end_controls_section();
  
    }    
    protected function render() {
      $settings =  $this->get_settings_for_display(); 
      $extra_class = $settings["extra_class"];
      
?>

      <div class="ltn__feature-area section-bg-1 pt-70 pb-90">
        <div class="container">
            <div class="row justify-content-center">
            <?php 
          foreach($settings["items1"] as $item){ 
            $select_style = $item["select_style"]; 
            $title = $item["title"]; 
            $content = $item["content"]; 
            $btn_text = $item["btn_text"]; 
            $btn_url = $item["btn_url"]['url']; 
            $icon = $item["icon"]['value']; 
            ?>
                <div class="col-lg-4 col-sm-6 col-12">
                <?php if( $select_style == 'style_1'){ ?>
                    <div class="ltn__feature-item ltn__feature-item-5 section-bg-2 text-center">
                        <div class="ltn__feature-icon">
                            <span><i class="<?php echo $icon;?>"></i></span>
                        </div>
                        <div class="ltn__feature-info">
                            <h2><a href="<?php echo $btn_url;?>"><?php echo $title;?></a></h2>
                            <p><?php echo $content;?></p>
                        </div>
                        <div class="btn-wrapper">
                            <a href="<?php echo $btn_url;?>" class="btn btn-white btn-effect-4 btn-full-width"><?php echo $btn_text;?></a>
                        </div>
                    </div>
                    <?php }elseif( $select_style == 'style_2'){
                      $bg_image = wp_get_attachment_image_url( $item["bg_image"]["id"],'full');
                      ?> 
                      <div class="ltn__feature-item ltn__feature-item-5 bg-overlay-theme-90 text-color-white text-center bg-image" data-bs-bg="<?php echo $bg_image;?>">
                        <div class="ltn__feature-icon">
                            <span><i class="<?php echo $icon;?>"></i></span>
                        </div>
                        <div class="ltn__feature-info">
                            <h2><a href="<?php echo $btn_url;?>" class="white-color-im"><?php echo $title;?></a></h2>
                            <p><?php echo $content;?></p>
                        </div>
                        <div class="btn-wrapper">
                            <a href="<?php echo $btn_url;?>" class="btn btn-white btn-effect-4 btn-full-width"><?php echo $btn_text;?></a>
                        </div>
                      </div>
                    <?php }elseif( $select_style == 'style_3'){ ?> 
                      <div class="ltn__feature-item ltn__feature-item-5 white-bg text-center">
                        <div class="ltn__feature-icon">
                            <span><i class="<?php echo $icon;?>"></i></span>
                        </div>
                        <div class="ltn__feature-info">
                            <h2><a href="<?php echo $btn_url;?>"><?php echo $title;?></a></h2>
                            <p><?php echo $content;?></p>
                        </div>
                        <div class="btn-wrapper">
                            <a href="<?php echo $btn_url;?>" class="btn btn-white btn-effect-4 btn-full-width"><?php echo $btn_text;?></a>
                        </div>
                      </div>
                    <?php } ?> 
                </div>
          <?php } ?> 
            </div>
        </div>
    </div>
 <?php 
    }
}

Plugin::instance()->widgets_manager->register_widget_type( new \Autixir_Features() );