<?php
use Elementor\Utils;
use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use Elementor\Repeater;
use Elementor\Plugin;

class Autixir_Skill extends Widget_Base {

  public function get_name() {
    return 'autixir_skill';
  }

  public function get_title() {
    return esc_html__( 'Autixir Skill', 'autixir-core' );
  }

  public function get_icon() {
    return '';
  }

   public function get_categories() {
    return [ 'autixir' ];
  }
  
    protected function register_controls() {

      $this->start_controls_section(
         'content',
         [
           'label' => __( 'Content', 'autixir-core' ),
         ]
      );
      $this->add_control(
        'style',
            array(
              'label'   => esc_html__( 'Style', 'autixir-core' ),
              'type'    => Controls_Manager::SELECT,
              'options' => array(
                '1' => esc_html__( 'One', 'autixir-core' ),
                '2' => esc_html__( 'Two', 'autixir-core' ),
              ),
              'default' => '1',
            )
      );
        $this->add_control(
          'sub_heading',
          [
            'label' => __( 'Sub Heading', 'autixir-core' ),
            'type' => Controls_Manager::TEXT,
            'default' => __('// skills', 'autixir-core' ),
          ]
        );
          $this->add_control(
            'heading',
            [
              'label' => __( 'Heading', 'autixir-core' ),
              'type' => Controls_Manager::TEXT,
              'default' => __('We Have A Skillest Team Eve', 'autixir-core' ),
            ]
          );
          $this->add_control(
            'quote_text',
            [
              'label' => __( 'Quote Text', 'autixir-core' ),
              'type' => Controls_Manager::TEXTAREA,
              'default' => __('Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore', 'autixir-core' ),
            ]
          );
          $this->add_control(
            'video_image',
            [
              'label' => __( 'Video Image', 'autixir-core' ),
              'type' => Controls_Manager::MEDIA,
              'default' => [
                        'url' => Utils::get_placeholder_image_src(),
                    ],
             'condition' => array('style' => '1'),
            ]
          );
          $this->add_control(
            'video_url',
            [
              'label' => __( 'Video URL', 'autixir-core' ),
              'type' => Controls_Manager::URL,
              'condition' => array('style' => '1'),
            ]
          );
          $this->add_control(
            'banner_image',
            [
              'label' => __( 'Image', 'autixir-core' ),
              'type' => Controls_Manager::MEDIA,
              'default' => [
                        'url' => Utils::get_placeholder_image_src(),
                    ],
             'condition' => array('style' => '2'),
            ]
          );
          $repeater = new Repeater();
          $repeater->add_control(
            'title',
            [
              'label' => __( 'Title', 'autixir-core' ),
              'type' => Controls_Manager::TEXT,
              'default' => __( 'Car Repair', 'autixir-core' ),
            ]
          );
          $repeater->add_control(
            'percentage',
            [
              'label' => __( 'Percentage', 'autixir-core' ),
              'type' => Controls_Manager::TEXT,
              'default' => __( '72', 'autixir-core' ),
            ]
          );
      $this->add_control(
        'items1',
        [
          'label' => __( 'Repeater List', 'autixir-core' ),
          'type' => Controls_Manager::REPEATER,
          'fields' => $repeater->get_controls(),
          'default' => [
            [
              'list_title' => __( 'Title #1', 'autixir-core' ),
              'list_content' => __( 'Item content. Click the edit button to change this text.', 'autixir-core' ),
            ],
            [
              'list_title' => __( 'Title #2', 'autixir-core' ),
              'list_content' => __( 'Item content. Click the edit button to change this text.', 'autixir-core' ),
            ],
          ],
        ]
      );
  
      $this->end_controls_section();
    }    
    protected function render() {
      $settings =  $this->get_settings_for_display();
      $style = $settings["style"];
      $sub_heading = $settings["sub_heading"];
      $heading = $settings["heading"];
      $quote_text = $settings["quote_text"];
    ?>
    <?php if($style == '1'){
            $video_image = wp_get_attachment_image_url( $settings["video_image"]["id"],'full');
            $video_url = $settings["video_url"]['url'];
      ?>
    <div class="ltn__progress-bar-area before-bg-right pt-115 pb-95">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="ltn__progress-bar-wrap">
                        <div class="section-title-area ltn__section-title-2">
                            <h6 class="section-subtitle ltn__secondary-color"><?php echo $sub_heading;?></h6>
                            <h1 class="section-title"><?php echo $heading;?><span>.</span></h1>
                            <p><?php echo $quote_text;?></p>
                        </div>
                        <div class="ltn__progress-bar-inner">
                        <?php
                          foreach($settings["items1"] as $item){ 
                            $title = $item["title"]; 
                            $percentage = $item["percentage"];
                            ?>
                            <div class="ltn__progress-bar-item">
                                <p><?php echo $title;?></p>
                                <div class="progress">
                                    <div class="progress-bar wow fadeInLeft" data-wow-duration="0.5s" data-wow-delay=".5s" role="progressbar" style="width: <?php echo $percentage;?>%">
                                        <span><?php echo $percentage;?>%</span>
                                    </div>
                                </div>
                            </div>
                            <?php } ?>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 align-self-center">
                    <div class="ltn__video-bg-img ltn__video-popup-height-500 bg-overlay-black-50-- bg-image ml-30" data-bs-bg="<?php echo $video_image;?>">
                        <a class="ltn__video-icon-2 ltn__video-icon-2-border---" href="<?php echo $video_url;?>" data-rel="lightcase:myCollection">
                            <i class="fa fa-play"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php }elseif($style == '2'){ 
            $banner_image = wp_get_attachment_image( $settings["banner_image"]["id"],'full');
      ?>
      <div class="ltn__progress-bar-area pt-85">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="ltn__progress-bar-wrap">
                        <div class="section-title-area ltn__section-title-2">
                            <h6 class="section-subtitle ltn__secondary-color"><?php echo $sub_heading;?></h6>
                            <h1 class="section-title"><?php echo $heading;?><span>.</span></h1>
                            <p><?php echo $quote_text;?></p>
                        </div>
                        <div class="ltn__progress-bar-inner">
                        <?php
                          foreach($settings["items1"] as $item){ 
                            $title = $item["title"]; 
                            $percentage = $item["percentage"];
                            ?>
                            <div class="ltn__progress-bar-item">
                                <p><?php echo $title;?></p>
                                <div class="progress">
                                    <div class="progress-bar wow fadeInLeft" data-wow-duration="0.5s" data-wow-delay=".5s" role="progressbar" style="width: <?php echo $percentage;?>%">
                                        <span><?php echo $percentage;?>%</span>
                                    </div>
                                </div>
                            </div>
                            <?php } ?>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 align-self-center">
                    <div class="about-img-right">
                      <?php echo $banner_image;?>
                    </div>
                </div>
            </div>
        </div>
    </div>
      <?php
      }
    } 
}
Plugin::instance()->widgets_manager->register_widget_type( new \Autixir_Skill() );