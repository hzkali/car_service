<?php
use Elementor\Utils;
use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use Elementor\Repeater;
use Elementor\Plugin;

class Autixir_Video extends Widget_Base {

  public function get_name() {
    return 'autixir_video';
  }

  public function get_title() {
    return esc_html__( 'Autixir Video', 'autixir-core' );
  }

  public function get_icon() {
    return '';
  }

   public function get_categories() {
    return [ 'autixir' ];
  }
  
    protected function register_controls() {

      $this->start_controls_section(
         'content',
         [
           'label' => __( 'Content', 'autixir-core' ),
         ]
      );
          $this->add_control(
            'video_image',
            [
              'label' => __( 'Video Image', 'autixir-core' ),
              'type' => Controls_Manager::MEDIA,
              'default' => [
                        'url' => Utils::get_placeholder_image_src(),
                    ],
            ]
          );
          $this->add_control(
            'video_url',
            [
              'label' => __( 'Video URL', 'autixir-core' ),
              'type' => Controls_Manager::URL,
            ]
          );
          $this->add_control(
            'extra_class',
            [
              'label' => __( 'Extra Class', 'autixir-core' ),
              'type' => Controls_Manager::TEXT,
            ]
          );
      $this->end_controls_section();
    }    
    protected function render() {
      $settings =  $this->get_settings_for_display();

      $video_image = wp_get_attachment_image_url( $settings["video_image"]["id"],'full');
      $video_url = $settings["video_url"]['url'];
      $extra_class = $settings["extra_class"];
    ?>
    <div class="ltn__video-popup-area <?php echo esc_attr($extra_class);?>">
        <div class="container">
            <div class="row">
                <div class="col-lg-10 offset-lg-1">
                    <div class="ltn__video-bg-img ltn__video-popup-height-600 bg-overlay-black-50--- bg-image" data-bs-bg="<?php echo $video_image;?>">
                        <a class="ltn__video-icon-2 ltn__video-icon-2-border---" href="<?php echo $video_url;?>" data-rel="lightcase:myCollection">
                            <i class="fa fa-play"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
      <?php
    } 
}
Plugin::instance()->widgets_manager->register_widget_type( new \Autixir_Video() );