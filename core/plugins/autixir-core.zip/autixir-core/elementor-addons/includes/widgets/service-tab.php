<?php
use Elementor\Utils;
use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use Elementor\Plugin;
use Elementor\Repeater;

class Autixir_ServiceTab extends Widget_Base {

  public function get_name() {
    return 'Autixir_ServiceTab';
  }

  public function get_title() {
    return esc_html__( 'Autixir Service Tab', 'autixir-core' );
  }

  public function get_icon() {
    return '';
  }

   public function get_categories() {
    return [ 'autixir' ];
  }
  
    protected function register_controls() {

      $this->start_controls_section(
         'content_section',
         [
           'label' => __( 'Content Section', 'autixir-core' ),
         ]
      );
            $this->add_control(
              'heading',
              [
                'label' => __( 'Heading', 'autixir-core' ),
                'type' => Controls_Manager::TEXT,
                'default' => __( '', 'autixir-core' ),
              ]
            );
            $this->add_control(
              'background',
              [
                'label' => __( 'Background', 'autixir-core' ),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                          'url' => Utils::get_placeholder_image_src(),
                      ],
                
              ]
            );
            $this->add_control(
              'extra_class',
              [
                'label' => __( 'Extra Class', 'autixir-core' ),
                'type' => Controls_Manager::TEXT,
                'default' => __( '', 'autixir-core' ),
              ]
            );
          $repeater = new Repeater();
          $repeater->add_control(
            'tabtitle',
            [
              'label' => __( 'Tab Title', 'autixir-core' ),
              'type' => Controls_Manager::TEXT,
              'default' => __( 'PC Laptop Repair', 'autixir-core' ),
            ]
          );
          $repeater->add_control(
            'content',
            [
              'label' => __( 'Content', 'autixir-core' ),
              'type' => Controls_Manager::SELECT,
              'options' => autixir_elementor_library(),
            ]
          );
 

      $this->end_controls_section();

      $this->start_controls_section(
        'service_list',
        [
          'label' => __( 'Service Tab List', 'autixir-core' ),
        ]
      );
      $this->add_control(
        'items1',
        [
          'label' => __( 'Repeater List', 'autixir-core' ),
          'type' => Controls_Manager::REPEATER,
          'fields' => $repeater->get_controls(),
          'default' => [
            [
              'list_title' => __( 'Title #1', 'autixir-core' ),
              'list_content' => __( 'Item content. Click the edit button to change this text.', 'autixir-core' ),
            ],
            [
              'list_title' => __( 'Title #2', 'autixir-core' ),
              'list_content' => __( 'Item content. Click the edit button to change this text.', 'autixir-core' ),
            ],
          ],
        ]
      );
  
      $this->end_controls_section();
  
    }    
    protected function render() {
      $settings =  $this->get_settings_for_display(); 
      $heading = $settings["heading"]; 
      $extra_class = $settings["extra_class"]; 
      $background = wp_get_attachment_image_url( $settings["background"]["id"],'full');
      $autixir_elementor_template = \Elementor\Plugin::instance();
?>


    <!-- start of services -->
    <?php if($background){ 
      ?>
      <section class="section cm-services bg-cover overlay-dark <?php echo esc_attr($extra_class);?>" style="background-image: url(<?php echo $background;?>);">
    <?php }else{ 
      ?>
      <section class="section cm-services cm-services-02 <?php echo esc_attr($extra_class);?>">
    <?php } ?>
    
        <div class="container">
            <div class="row">
                <div class="col-lg-3 mb-5 mb-lg-0">
                    <div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
                    <?php
                     $i = 0;
                    foreach($settings["items1"] as $item){ 
                      $tabtitle = $item["tabtitle"]; 
                      $i++;
                      if($i == 1){
                        $active = 'active';
                      }else{
                        $active = '';
                      }
                      ?>
                        <a class="nav-link rounded-0 text-white text-left <?php echo $active; ?>" data-toggle="pill" href="#service-tab<?php echo $i;?>" role="tab" aria-selected="true"><?php echo $tabtitle;?></a>
                      <?php } ?> 
                    </div>
                </div>
                <div class="col-lg-9">
                    <div class="tab-content" id="v-pills-tabContent">
                    <?php
                     $i = 0;
                    foreach($settings["items1"] as $item){  
                      $content = $item["content"]; 
                      $i++;
                      if($i == 1){
                        $active = 'show active';
                      }else{
                        $active = '';
                      }
                      ?>
                        <div class="tab-pane fade <?php echo $active; ?>" id="service-tab<?php echo $i;?>" role="tabpanel">
                          <?php echo $autixir_elementor_template->frontend->get_builder_content( $content ); ?>
                        </div>
                    <?php } ?> 
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- end of services -->


 <?php 
    }
  
    protected function _content_template() {
      
    }
  }

Plugin::instance()->widgets_manager->register_widget_type( new \Autixir_ServiceTab() );