<?php
use Elementor\Utils;
use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use Elementor\Plugin;
use Elementor\Repeater;

class Autixir_Service_Item extends Widget_Base {

  public function get_name() {
    return 'autixir_service_item';
  }

  public function get_title() {
    return esc_html__( 'Autixir Service Item', 'autixir-core' );
  }

  public function get_icon() {
    return '';
  }

   public function get_categories() {
    return [ 'autixir' ];
  }
  
    protected function register_controls() {

      $this->start_controls_section(
         'content',
         [
           'label' => __( 'Content', 'autixir-core' ),
         ]
      );
            $this->add_control(
              'sub_heading',
              [
                'label' => __( 'Sub Heading', 'autixir-core' ),
                'type' => Controls_Manager::TEXT,
                'default' => __( '// Service', 'autixir-core' ),
              ]
            );
            $this->add_control(
              'heading',
              [
                'label' => __( 'Heading', 'autixir-core' ),
                'type' => Controls_Manager::TEXT,
                'default' => __( 'What We Do', 'autixir-core' ),
              ]
            );
            $this->add_control(
              'extra_class',
              [
                'label' => __( 'Extra Class', 'autixir-core' ),
                'type' => Controls_Manager::TEXT,
              ]
            );
          $repeater = new Repeater();
          $repeater->add_control(
            'title',
            [
              'label' => __( 'Title', 'autixir-core' ),
              'type' => Controls_Manager::TEXT,
              'default' => __( 'There are many variations of passages of Lorem.', 'autixir-core' ),
            ]
          );
          $repeater->add_control(
            'content',
            [
              'label' => __( 'Content', 'autixir-core' ),
              'type' => Controls_Manager::TEXTAREA,
            ]
          );
          $repeater->add_control(
            'icon',
            [
              'label' => __( 'Icon', 'autixir-core' ),
              'type' => Controls_Manager::ICONS,
            ]
          );
          $repeater->add_control(
            'item_image',
            [
              'label' => __( 'Item Image', 'autixir-core' ),
              'type' => Controls_Manager::MEDIA,
              'default' => [
                        'url' => Utils::get_placeholder_image_src(),
                    ],
            ]
          );
          $repeater->add_control(
            'link',
            [
                'label' => __( 'Link', 'autixir-core' ),
                'type' => Controls_Manager::URL,
                'placeholder' => __( 'https://your-link.com', 'autixir-core' ),
                'show_external' => true,
                'default' => [
                  'url' => '',
                  'is_external' => true,
                  'nofollow' => true,
                ],
              ]
            );
      $this->add_control(
        'items1',
        [
          'label' => __( 'Repeater List', 'autixir-core' ),
          'type' => Controls_Manager::REPEATER,
          'fields' => $repeater->get_controls(),
          'default' => [
            [
              'list_title' => __( 'Title #1', 'autixir-core' ),
              'list_content' => __( 'Item content. Click the edit button to change this text.', 'autixir-core' ),
            ],
            [
              'list_title' => __( 'Title #2', 'autixir-core' ),
              'list_content' => __( 'Item content. Click the edit button to change this text.', 'autixir-core' ),
            ],
          ],
        ]
      );
  
      $this->end_controls_section();
  
    }    
    protected function render() {
      $settings =  $this->get_settings_for_display(); 
      $sub_heading = $settings["sub_heading"]; 
      $heading = $settings["heading"]; 
      $extra_class = $settings["extra_class"];
?>
    <div class="ltn__service-area ltn__primary-bg before-bg-1 pt-115 pb-70 <?php echo $extra_class;?>">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title-area ltn__section-title-2 text-center">
                        <h6 class="section-subtitle ltn__secondary-color"><?php echo $sub_heading;?></h6>
                        <h1 class="section-title white-color"><?php echo $heading;?><span>.</span></h1>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">
          <?php
          foreach($settings["items1"] as $item){ 
            $title = $item["title"]; 
            $content = $item["content"];
            $link = $item["link"]['url'];
            $icon = $item["icon"]['value'];
            $item_image = wp_get_attachment_image( $item["item_image"]["id"],'full');
            ?>
                <div class="col-lg-4 col-sm-6">
                    <div class="ltn__service-item-1">
                        <div class="service-item-img">
                            <?php echo $item_image;?>
                            <div class="service-item-icon">
                                <i class="<?php echo $icon;?>"></i>
                            </div>
                        </div>
                        <div class="service-item-brief">
                            <h3><a href="<?php echo $link;?>"><?php echo $title;?></a></h3>
                            <p><?php echo $content;?></p>
                        </div>
                    </div>
                </div>
                <?php } ?> 
            </div>
        </div>
    </div>
 <?php 
    }
}

Plugin::instance()->widgets_manager->register_widget_type( new \Autixir_Service_Item() );