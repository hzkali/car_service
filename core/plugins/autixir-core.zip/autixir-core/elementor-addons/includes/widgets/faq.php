<?php
use Elementor\Utils;
use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use Elementor\Plugin;
use Elementor\Repeater;

class Autixir_Faq extends Widget_Base {

  public function get_name() {
    return 'autixir_faq';
  }

  public function get_title() {
    return esc_html__( 'Autixir FAQ', 'autixir-core' );
  }

  public function get_icon() {
    return '';
  }

   public function get_categories() {
    return [ 'autixir' ];
  }
  
    protected function register_controls() {

      $this->start_controls_section(
         'faq_section',
         [
           'label' => __( 'Faq Section', 'autixir-core' ),
         ]
      );
          $repeater = new Repeater();
          $repeater->add_control(
            'question',
            [
              'label' => __( 'Question', 'autixir-core' ),
              'type' => Controls_Manager::TEXT,
              'default' => __( 'How to buy a product?', 'autixir-core' ),
            ]
          );
          $repeater->add_control(
            'answer',
            [
              'label' => __( 'Answer', 'autixir-core' ),
              'type' => Controls_Manager::TEXTAREA,
              'default' => __( 'Lorem ipsum dolor sit amet, consect etur adipisicing elit, sed do eiusmod tempor incididunt ut labore.', 'autixir-core' ),
            ]
          );
    
      $this->add_control(
        'items1',
        [
          'label' => __( 'Repeater List', 'autixir-core' ),
          'type' => Controls_Manager::REPEATER,
          'fields' => $repeater->get_controls(),
          'default' => [
            [
              'list_title' => __( 'Title #1', 'autixir-core' ),
              'list_content' => __( 'Item content. Click the edit button to change this text.', 'autixir-core' ),
            ],
          ],
        ]
      );
      $this->end_controls_section();
      $this->start_controls_section(
        'contact_section',
        [
          'label' => __( 'Contact Section', 'autixir-core' ),
        ]
       );
       $this->add_control(
        'title',
        [
          'label' => __( 'Title', 'autixir-core' ),
          'type' => Controls_Manager::TEXT,
          'default' => __( 'Still need help? Reach out to support 24/7:', 'autixir-core' ),
        ]
      );
      $this->add_control(
        'phone',
        [
          'label' => __( 'Phone Number', 'autixir-core' ),
          'type' => Controls_Manager::TEXT,
          'default' => __( '+0123-456-789', 'autixir-core' ),
        ]
      );
      $this->add_control(
        'btn_test',
        [
          'label' => __( 'Button Text', 'autixir-core' ),
          'type' => Controls_Manager::TEXT,
          'default' => __( 'Contact Us', 'autixir-core' ),
        ]
      );
      $this->add_control(
        'btn_url',
        [
          'label' => __( 'Button URL', 'autixir-core' ),
          'type' => Controls_Manager::URL,
        ]
      );
     $this->end_controls_section();
    }    
    protected function render() {
      $settings =  $this->get_settings_for_display(); 
      $title = $settings["title"];
      $phone = $settings["phone"];
      $btn_test = $settings["btn_test"];
      $btn_url = $settings["btn_url"]['url'];
?>
<div class="ltn__faq-inner ltn__faq-inner-2">
    <div id="accordion_2">
        <?php
        $i = 0;
        foreach($settings["items1"] as $item){ 
          $question = $item["question"]; 
          $answer = $item["answer"];
          $i++;
          if($i == 2){
            $active = 'show';
          }else{
            $active = '';
          }
          ?>
        <div class="card">
            <h6 class="collapsed ltn__card-title" data-bs-toggle ="collapse" data-bs-target="#faq-item-<?php echo $i; ?>" aria-expanded="false">
            <?php echo $question;?>
            </h6>
            <div id="faq-item-<?php echo $i; ?>" class="collapse <?php echo $active;?>" data-parent="#accordion_2">
                <div class="card-body">
                    <p><?php echo $answer;?></p>
                </div>
            </div>
        </div>
        <?php } ?>                 
    </div>
    <div class="need-support text-center mt-100">
        <h2><?php echo $title;?></h2>
        <div class="btn-wrapper mb-30">
            <a href="<?php echo $btn_url;?>" class="theme-btn-1 btn"><?php echo $btn_test;?></a>
        </div>
        <h3><i class="fas fa-phone"></i><?php echo $phone;?></h3>
    </div>
</div>
 <?php 
    }
}

Plugin::instance()->widgets_manager->register_widget_type( new \Autixir_Faq() );