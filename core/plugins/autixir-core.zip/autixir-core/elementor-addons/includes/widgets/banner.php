<?php
use Elementor\Utils;
use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use Elementor\Plugin;

class Autixir_Banner extends Widget_Base {

  public function get_name() {
    return 'Autixir_Banner';
  }

  public function get_title() {
    return esc_html__( 'Autixir Banner', 'autixir-core' );
  }

  public function get_icon() {
    return '';
  }

   public function get_categories() {
    return [ 'autixir' ];
  }
  
    protected function register_controls() {

      $this->start_controls_section(
         'content',
         [
           'label' => __( 'Content', 'autixir-core' ),
         ]
      );
        $this->add_control(
          'banner_bg',
          [
            'label' => __( 'Banner BG Image', 'autixir-core' ),
            'type' => Controls_Manager::MEDIA,
            'default' => [
                      'url' => Utils::get_placeholder_image_src(),
                  ],
          ]
        );
          $this->add_control(
            'image',
            [
              'label' => __( 'Banner Image', 'autixir-core' ),
              'type' => Controls_Manager::MEDIA,
              'default' => [
                        'url' => Utils::get_placeholder_image_src(),
                    ],
            ]
          );
          $this->add_control(
            'banner_url',
            [
                'label' => __( 'Banner URL', 'autixir-core' ),
                'type' => Controls_Manager::URL,
                'placeholder' => __( 'https://your-link.com', 'autixir-core' ),
                'show_external' => true,
                'default' => [
                  'url' => '',
                  'is_external' => true,
                  'nofollow' => true,
                ],
                
              ]
            );
          $this->add_control(
            'sub_title',
            [
              'label' => __( 'Sub Title', 'autixir-core' ),
              'type' => Controls_Manager::TEXT,
              'default' => __('Mobile & Computer', 'autixir-core' ),
            ]
          );
          $this->add_control(
            'title',
            [
              'label' => __( 'Title', 'autixir-core' ),
              'type' => Controls_Manager::TEXT,
              'default' => __('Repair Service', 'autixir-core' ),
            ]
          );
          $this->add_control(
            'button_text',
            [
              'label' => __( 'Button Text', 'autixir-core' ),
              'type' => Controls_Manager::TEXT,
              'default' => __( 'Appointment', 'autixir-core' ),
            ]
          );
          $this->add_control(
            'button_url',
            [
                'label' => __( 'Button Url', 'autixir-core' ),
                'type' => Controls_Manager::URL,
                'placeholder' => __( 'https://your-link.com', 'autixir-core' ),
                'show_external' => true,
                'default' => [
                  'url' => '',
                  'is_external' => true,
                  'nofollow' => true,
                ],
                
              ]
            );
            $this->add_control(
              'button_text_2',
              [
                'label' => __( 'Button Text 02', 'autixir-core' ),
                'type' => Controls_Manager::TEXT,
                'default' => __( 'get a quote', 'autixir-core' ),
              ]
            );
            $this->add_control(
              'button_url_2',
              [
                  'label' => __( 'Button Url', 'autixir-core' ),
                  'type' => Controls_Manager::URL,
                  'placeholder' => __( 'https://your-link.com', 'autixir-core' ),
                  'show_external' => true,
                  'default' => [
                    'url' => '',
                    'is_external' => true,
                    'nofollow' => true,
                  ],
                  
                ]
              );
            $this->add_control(
              'extra_class',
              [
                'label' => __( 'Extra Class', 'autixir-core' ),
                'type' => Controls_Manager::TEXT,
              ]
            );
  
      $this->end_controls_section();

  
    }    
    protected function render() {
      $settings =  $this->get_settings_for_display(); 
      $extra_class = $settings["extra_class"]; 
      $sub_title = $settings["sub_title"];
      $title = $settings["title"];
      
      $banner_bg = wp_get_attachment_image_url( $settings["banner_bg"] ["id"],'full');
      $image = wp_get_attachment_image( $settings["image"] ["id"],'full');
     
      $button_text = $settings["button_text"];  
      $button_url = $settings["button_url"]["url"];  
      $button_text_2 = $settings["button_text_2"];  
      $button_url_2 = $settings["button_url_2"]["url"];  
      $banner_url = $settings["banner_url"]["url"];  
?>


  <div class="ltn__slider-area ltn__slider-4 ">
        <div class="ltn__slide-one-active----- slick-slide-arrow-1----- slick-slide-dots-1----- arrow-white----- ltn__slide-animation-active">
            <!-- ltn__slide-item -->
            <div class="ltn__slide-item ltn__slide-item-2 ltn__slide-item-4 text-color-white bg-image" data-bs-bg="<?php echo $banner_bg;?>">
                <div class="ltn__slide-item-inner text-center">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-12 align-self-center">
                                <div class="slide-item-info">
                                    <div class="slide-item-info-inner ltn__slide-animation">
                                        <h6 class="slide-sub-title ltn__secondary-color animated text-uppercase"><?php echo esc_html($sub_title);?></h6>
                                        <h1 class="slide-title animated "><?php echo $title;?></h1>
                                        <div class="btn-wrapper animated">
                                            <a href="<?php echo esc_url($button_url);?>" class="theme-btn-1 btn btn-effect-1"><?php echo $button_text;?></a>
                                            <a href="<?php echo esc_url($button_url_2);?>" class="btn btn-transparent btn-effect-2 white-color"><?php echo $button_text_2;?></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="ltn__slide-animation">
                                    <div class="slide-item-img">
                                        <a href="<?php echo $banner_url;?>"><?php echo $image;?></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

 <?php 
    }
  
    protected function content_template() {
      
    }
  }

Plugin::instance()->widgets_manager->register_widget_type( new \Autixir_Banner() );