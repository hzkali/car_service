<?php
use Elementor\Utils;
use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use Elementor\Plugin;
use Elementor\Repeater;

class Autixir_Service_Price_List extends Widget_Base {

  public function get_name() {
    return 'autixir_service_price_list';
  }

  public function get_title() {
    return esc_html__( 'Autixir Service Price List', 'autixir-core' );
  }

  public function get_icon() {
    return '';
  }

   public function get_categories() {
    return [ 'autixir' ];
  }
  
    protected function register_controls() {

      $this->start_controls_section(
         'content',
         [
           'label' => __( 'Content', 'autixir-core' ),
         ]
      ); 
          $repeater = new Repeater();
          $repeater->add_control(
            'title',
            [
              'label' => __( 'Title', 'autixir-core' ),
              'type' => Controls_Manager::TEXT,
              'default' => __( 'Front Brakes Repair', 'autixir-core' ),
            ]
          );
          $repeater->add_control(
            'price',
            [
              'label' => __( 'Price', 'autixir-core' ),
              'type' => Controls_Manager::TEXT,
              'default' => __( '$225.95 <span>Plus Parts</span>', 'autixir-core' ),
            ]
          );
          $repeater->add_control(
            'icon',
            [
              'label' => __( 'Icon', 'autixir-core' ),
              'type' => Controls_Manager::ICONS,
            ]
          );
      $this->add_control(
        'items1',
        [
          'label' => __( 'Repeater List', 'autixir-core' ),
          'type' => Controls_Manager::REPEATER,
          'fields' => $repeater->get_controls(),
          'default' => [
            [
              'list_title' => __( 'Title #1', 'autixir-core' ),
              'list_content' => __( 'Item content. Click the edit button to change this text.', 'autixir-core' ),
            ],
          ],
        ]
      );
      $this->end_controls_section();
  
    }    
    protected function render() {
      $settings =  $this->get_settings_for_display(); 
?>
    <div class="ltn__service-list-menu text-uppercase mt-10">
        <ul>
        <?php 
                foreach($settings["items1"] as $item){ 
                  $title = $item["title"]; 
                  $price = $item["price"];
                  $icon = $item["icon"]['value'];
                  ?>
            <li><i class="<?php echo $icon;?>"></i> <?php echo $title;?> <span class="service-price"><?php echo $price;?></span> </li>
            <?php } ?> 
        </ul>
    </div>
 <?php 
    }
}

Plugin::instance()->widgets_manager->register_widget_type( new \Autixir_Service_Price_List() );