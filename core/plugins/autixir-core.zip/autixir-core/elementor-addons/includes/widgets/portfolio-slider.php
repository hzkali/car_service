<?php
use Elementor\Utils;
use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use Elementor\Plugin;
use Elementor\Repeater;

class Autixir_Portfolio_Slider extends Widget_Base {

  public function get_name() {
    return 'autixir_portfolio_slider';
  }

  public function get_title() {
    return esc_html__( 'Autixir Portfolio Slider', 'autixir-core' );
  }

  public function get_icon() {
    return '';
  }

   public function get_categories() {
    return [ 'autixir' ];
  }
  
    protected function register_controls() {

      $this->start_controls_section(
         'content',
         [
           'label' => __( 'Content', 'autixir-core' ),
         ]
      );
      $this->add_control(
        'style',
        array(
          'label'   => esc_html__( 'Style', 'autixir-core' ),
          'type'    => Controls_Manager::SELECT,
          'options' => array(
          '1' => esc_html__( 'One', 'autixir-core' ),
          '2' => esc_html__( 'Two', 'autixir-core' ),
          '3' => esc_html__( 'Three', 'autixir-core' ),
          ),
          'default' => '1',
        )
        );
        $this->add_control(
          'sub_heading',
          [
            'label' => __( 'Sub Heading', 'autixir-core' ),
            'type' => Controls_Manager::TEXT,
            'default' => __('// PORTFOLIO', 'autixir-core' ),
          ]
        );
          $this->add_control(
            'heading',
            [
              'label' => __( 'Heading', 'autixir-core' ),
              'type' => Controls_Manager::TEXT,
              'default' => __('We Have Done', 'autixir-core' ),
            ]
          );
            $this->add_control(
              'extra_class',
              [
                'label' => __( 'Extra Class', 'autixir-core' ),
                'type' => Controls_Manager::TEXT,
                'default' => __( '', 'autixir-core' ),
              ]
            );
          $repeater = new Repeater();
          $repeater->add_control(
            'image',
            [
              'label' => __( 'Image', 'autixir-core' ),
              'type' => Controls_Manager::MEDIA,
              'default' => [
                        'url' => Utils::get_placeholder_image_src(),
                    ],
            ]
          );
          $repeater->add_control(
            'portfolio_type',
            [
              'label' => __( 'Portfolio Type', 'autixir-core' ),
              'type' => Controls_Manager::TEXT,
              'default' => __( '//  trouble shooting', 'autixir-core' ),
            ]
          );
          $repeater->add_control(
            'title',
            [
              'label' => __( 'Title', 'autixir-core' ),
              'type' => Controls_Manager::TEXT,
              'default' => __( 'Hilix Nova Car Solutions.', 'autixir-core' ),
            ]
          );
          $repeater->add_control(
            'link',
            [
                'label' => __( 'Link', 'autixir-core' ),
                'type' => Controls_Manager::URL,
                'placeholder' => __( 'https://your-link.com', 'autixir-core' ),
                'show_external' => true,
                'default' => [
                  'url' => '',
                  'is_external' => true,
                  'nofollow' => true,
                ],
              ]
            );
      $this->add_control(
        'items1',
        [
          'label' => __( 'Repeater List', 'autixir-core' ),
          'type' => Controls_Manager::REPEATER,
          'fields' => $repeater->get_controls(),
          'default' => [
            [
              'list_title' => __( 'Title #1', 'autixir-core' ),
              'list_content' => __( 'Item content. Click the edit button to change this text.', 'autixir-core' ),
            ],
            [
              'list_title' => __( 'Title #2', 'autixir-core' ),
              'list_content' => __( 'Item content. Click the edit button to change this text.', 'autixir-core' ),
            ],
          ],
        ]
      );
  
      $this->end_controls_section();
  
    }    
    protected function render() {
      $settings =  $this->get_settings_for_display();
      $style = $settings["style"];
      $extra_class = $settings["extra_class"];
      $sub_heading = $settings["sub_heading"];
      $heading = $settings["heading"];
?>
<?php if($style == '1'){?>
    <div class="ltn__img-slider-area pb-100">
        <div class="container-fluid">
            <div class="row ltn__image-slider-3-active slick-arrow-1 slick-arrow-1-inner">
            <?php
          foreach($settings["items1"] as $item){ 
            $portfolio_type = $item["portfolio_type"]; 
            $title = $item["title"]; 
            $link = $item["link"]['url'];
            $image_src = wp_get_attachment_image_url( $item["image"] ["id"],'full');
            $image = wp_get_attachment_image( $item["image"] ["id"],'full');
            ?>
                <div class="col-lg-12">
                    <div class="ltn__img-slide-item-3">
                        <a href="<?php echo $image_src;?>" data-rel="lightcase:myCollection">
                            <?php echo $image;?>
                        </a>
                        <div class="ltn__img-slide-info">
                            <div class="ltn__img-slide-info-brief">
                                <h6><?php echo $portfolio_type;?></h6>
                                <h1><a href="<?php echo $link;?>"><?php echo $title;?></a></h1>
                            </div>
                            <div class="btn-wrapper">
                                <a href="<?php echo  $link;?>" class="btn theme-btn-1 btn-effect-1"><i class="fas fa-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <?php } ?> 
            </div>
        </div>
    </div>
      <?php }elseif($style == '2'){ ?>
    <div class="ltn__img-slider-area">
        <div class="container-fluid">
            <div class="row ltn__image-slider-4-active slick-arrow-1 slick-arrow-1-inner ltn__no-gutter-all">
            <?php
          foreach($settings["items1"] as $item){ 
            $portfolio_type = $item["portfolio_type"]; 
            $title = $item["title"]; 
            $link = $item["link"]['url'];
            $image_src = wp_get_attachment_image_url( $item["image"] ["id"],'full');
            $image = wp_get_attachment_image( $item["image"] ["id"],'full');
            ?>
                <div class="col-lg-12">
                    <div class="ltn__img-slide-item-4">
                        <a href="<?php echo $image_src;?>" data-rel="lightcase:myCollection">
                        <?php echo $image;?>
                        </a>
                        <div class="ltn__img-slide-info">
                            <div class="ltn__img-slide-info-brief">
                                <h6><?php echo $portfolio_type;?></h6>
                                <h1><a href="<?php echo $link;?>"><?php echo $title;?></a></h1>
                            </div>
                            <div class="btn-wrapper">
                                <a href="<?php echo $link;?>" class="btn theme-btn-1 btn-effect-1 text-uppercase">Details</a>
                            </div>
                        </div>
                    </div>
                </div>
                <?php } ?> 
            </div>
        </div>
    </div>
    <?php }elseif($style == '3'){ ?>
      <div class="ltn__img-slider-area ltn__img-slider-2 section-bg-1 pt-115 pb-85">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title-area ltn__section-title-2 text-center">
                        <h6 class="section-subtitle ltn__secondary-color"><?php echo $sub_heading;?></h6>
                        <h1 class="section-title"><?php echo $heading;?><span>.</span></h1>
                    </div>
                </div>
            </div>
        </div>
        <div class="container-fluid">
            <div class="row ltn__image-slider-2-active slick-arrow-1 slick-arrow-1-inner">
            <?php
          foreach($settings["items1"] as $item){ 
            $portfolio_type = $item["portfolio_type"]; 
            $title = $item["title"]; 
            $link = $item["link"]['url'];
            $image_src = wp_get_attachment_image_url( $item["image"] ["id"],'full');
            $image = wp_get_attachment_image( $item["image"] ["id"],'full');
            ?>
                <div class="col-lg-12">
                    <div class="ltn__img-slide-item-2">
                        <a href="<?php echo $image_src;?>" data-rel="lightcase:myCollection">
                        <?php echo $image;?>
                        </a>
                    </div>
                </div>
            <?php } ?> 
            </div>
        </div>
    </div>
        <?php 
       }
    }
}

Plugin::instance()->widgets_manager->register_widget_type( new \Autixir_Portfolio_Slider() );