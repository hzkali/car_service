<?php
use Elementor\Utils;
use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use Elementor\Plugin;

class Autixir_About_Section extends Widget_Base {

  public function get_name() {
    return 'autixir_about_section';
  }

  public function get_title() {
    return esc_html__( 'Autixir About Section', 'autixir-core' );
  }

  public function get_icon() {
    return '';
  }

   public function get_categories() {
    return [ 'autixir' ];
  }
  
    protected function register_controls() {

      $this->start_controls_section(
         'content',
         [
           'label' => __( 'Content', 'autixir-core' ),
         ]
      );
      $this->add_control(
        'style',
        array(
          'label'   => esc_html__( 'Style', 'autixir-core' ),
          'type'    => Controls_Manager::SELECT,
          'options' => array(
            '1' => esc_html__( 'Style One', 'autixir-core' ),
            '2' => esc_html__( 'Style Two', 'autixir-core' ),
          ),
          'default' => '1',
        )
      );
        $this->add_control(
          'sub_heading',
          [
            'label' => __( 'Sub Heading', 'autixir-core' ),
            'type' => Controls_Manager::TEXT,
            'default' => __('// About Us', 'autixir-core' ),
          ]
        );
          $this->add_control(
            'heading',
            [
              'label' => __( 'Heading', 'autixir-core' ),
              'type' => Controls_Manager::TEXT,
              'default' => __('Safety Is Our First Priority', 'autixir-core' ),
            ]
          );
          $this->add_control(
            'quote_text',
            [
              'label' => __( 'Quote Text', 'autixir-core' ),
              'type' => Controls_Manager::TEXTAREA,
              'default' => __('Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore', 'autixir-core' ),
            ]
          );
          $this->add_control(
            'desc',
            [
              'label' => __( 'Description', 'autixir-core' ),
              'type' => Controls_Manager::TEXTAREA,
              'default' => __('Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.', 'autixir-core' ),
            ]
          );
          $this->add_control(
            'content_list',
            [
              'label' => __( 'Content List', 'autixir-core' ),
              'type' => Controls_Manager::TEXTAREA,
            ]
          );
          $this->add_control(
            'form_title',
            [
              'label' => __( 'Form Title', 'autixir-core' ),
              'type' => Controls_Manager::TEXT,
              'default' => __( 'Get A Quote', 'autixir-core' ),
              'condition' => array('style' => '1'),
            ]
          );
          $this->add_control(
            'form_shortcode',
            [
              'label' => __( 'Form Shortcode', 'autixir-core' ),
              'type' => Controls_Manager::TEXT,
              'condition' => array('style' => '1'),
            ]
          );  
          $this->add_control(
            'image',
            [
              'label' => __( 'Image', 'autixir-core' ),
              'type' => Controls_Manager::MEDIA,
              'default' => [
                        'url' => Utils::get_placeholder_image_src(),
                    ],
              'condition' => array('style' => '2'),
            ]
          );
      $this->end_controls_section();
    }    
    protected function render() {
      $settings =  $this->get_settings_for_display();
      $style = $settings["style"];
      $sub_heading = $settings["sub_heading"];
      $heading = $settings["heading"];
      $quote_text = $settings["quote_text"];
      $desc = $settings["desc"];
      $content_list = $settings["content_list"];
    ?>
    <?php 
    if($style == '1'){
      $form_title = $settings["form_title"];
      $form_shortcode = $settings["form_shortcode"];
      ?>
    <div class="ltn__about-us-area pt-115 pb-95">
        <div class="container">
            <div class="row">
                <div class="col-lg-7 align-self-center">
                    <div class="about-us-info-wrap">
                        <div class="section-title-area ltn__section-title-2">
                            <h6 class="section-subtitle ltn__secondary-color"><?php echo $sub_heading;?></h6>
                            <h1 class="section-title"><?php echo $heading;?><span>.</span></h1>
                            <p><?php echo $quote_text;?></p>
                        </div>
                        <div class="about-us-info-wrap-inner about-us-info-devide">
                            <p><?php echo $desc;?></p>
                            <div class="list-item-with-icon">
                            <ul>
                              <?php echo $content_list;?>
                            </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-5 align-self-center">
                    <div class="get-a-quote-wrap">
                        <h2><?php echo $form_title;?></h2>
                        <?php echo do_shortcode($form_shortcode);?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php }elseif( $style == '2'){
       $image = wp_get_attachment_image( $settings["image"] ["id"],'full');
      ?>
      <div class="ltn__about-us-area pb-115">
        <div class="container">
            <div class="row">
                <div class="col-lg-5 align-self-center">
                    <div class="about-us-img-wrap ltn__img-shape-left  about-img-left">
                      <?php echo $image;?>
                    </div>
                </div>
                <div class="col-lg-7 align-self-center">
                    <div class="about-us-info-wrap">
                        <div class="section-title-area ltn__section-title-2">
                            <h6 class="section-subtitle ltn__secondary-color"><?php echo $sub_heading;?></h6>
                            <h1 class="section-title"><?php echo $heading;?><span>.</span></h1>
                            <p><?php echo $quote_text;?></p>
                        </div>
                        <div class="about-us-info-wrap-inner about-us-info-devide">
                            <p><?php echo $desc;?></p>
                            <div class="list-item-with-icon">
                                <ul>
                                <?php echo $content_list;?>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
      <?php
      }
    } 
}
Plugin::instance()->widgets_manager->register_widget_type( new \Autixir_About_Section() );