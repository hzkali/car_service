<?php
use Elementor\Utils;
use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use Elementor\Plugin;
use Elementor\Repeater;

class Autixir_Why_Choose_Us extends Widget_Base {

  public function get_name() {
    return 'autixir_why_choose_us';
  }

  public function get_title() {
    return esc_html__( 'Autixir Why Choose Us', 'autixir-core' );
  }

  public function get_icon() {
    return '';
  }

   public function get_categories() {
    return [ 'autixir' ];
  }
  
    protected function register_controls() {

            $this->start_controls_section(
              'content_section',
              [
                'label' => __( 'Content Section', 'autixir-core' ),
              ]
            );
            $this->add_control(
              'style',
              array(
                'label'   => esc_html__( 'Style', 'autixir-core' ),
                'type'    => Controls_Manager::SELECT,
                'options' => array(
                  '1' => esc_html__( 'Style One', 'autixir-core' ),
                  '2' => esc_html__( 'Style Two', 'autixir-core' ),
                  '3' => esc_html__( 'Style Three', 'autixir-core' ),
                ),
                'default' => '1',
              )
            );
            $this->add_control(
              'sub_heading',
              [
                'label' => __( 'Sub Heading', 'autixir-core' ),
                'type' => Controls_Manager::TEXT,
                'default' =>  __('//  features  //', 'autixir-core' ),
              ]
            );
            $this->add_control(
              'heading',
              [
                'label' => __( 'Heading', 'autixir-core' ),
                'type' => Controls_Manager::TEXT,
                'default' => __( 'Why Choose Us', 'autixir-core' ),
              ]
            );
            $this->add_control(
              'short_desc',
              [
                'label' => __( 'Short desc', 'autixir-core' ),
                'type' => Controls_Manager::TEXTAREA,
              ]
            );
            $this->add_control(
              'middle_image',
              [
                'label' => __( 'Image', 'autixir-core' ),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                          'url' => Utils::get_placeholder_image_src(),
                      ],
              ]
            );
            $this->add_control(
              'image_two',
              [
                'label' => __( 'Image 02', 'autixir-core' ),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                          'url' => Utils::get_placeholder_image_src(),
                      ],
              ]
            );
            $this->add_control(
              'extra_class',
              [
                'label' => __( 'Extra Class', 'autixir-core' ),
                'type' => Controls_Manager::TEXT,
                'default' => __( '', 'autixir-core' ),
              ]
            );
      $this->end_controls_section();

      $this->start_controls_section(
        'item_list',
        [
          'label' => __( 'Item List', 'autixir-core' ),
        ]
      );
      $repeater = new Repeater();
      $repeater->add_control(
        'title',
        [
          'label' => __( 'Title', 'autixir-core' ),
          'type' => Controls_Manager::TEXT,
          'default' => __( 'All Kind Brand', 'autixir-core' ),
        ]
      );
      $repeater->add_control(
        'content',
        [
          'label' => __( 'Content', 'autixir-core' ),
          'type' => Controls_Manager::TEXTAREA,
          'default' => __( 'Lorem ipsum dolor sit ame it, consectetur adipisicing elit, sed do eiusmod te mp or incididunt ut labore.', 'autixir-core' ),
        ]
      );
      $repeater->add_control(
        'icon',
        [
          'label' => __( 'Icon', 'autixir-core' ),
          'type' => Controls_Manager::ICONS,
        ]
      );
      $repeater->add_control(
        'link',
        [
          'label' => __( 'Link', 'autixir-core' ),
          'type' => Controls_Manager::URL,
        ]
      );
      $this->add_control(
        'items',
        [
          'label' => __( 'Repeater List', 'autixir-core' ),
          'type' => Controls_Manager::REPEATER,
          'fields' => $repeater->get_controls(),
          'default' => [
            [
              'list_title' => __( 'Title #1', 'autixir-core' ),
              'list_content' => __( 'Item content. Click the edit button to change this text.', 'autixir-core' ),
            ],
            [
              'list_title' => __( 'Title #2', 'autixir-core' ),
              'list_content' => __( 'Item content. Click the edit button to change this text.', 'autixir-core' ),
            ],
          ],
        ]
      );
  
      $this->end_controls_section();
  
    }    
    protected function render() {
      $settings =  $this->get_settings_for_display(); 
      $style = $settings["style"];
      $heading = $settings["heading"];
      $sub_heading = $settings["sub_heading"];
      $short_desc = $settings["short_desc"];
      $extra_class = $settings["extra_class"]; 
      $middle_image = wp_get_attachment_image( $settings["middle_image"]["id"],'full');
      $image_two = wp_get_attachment_image( $settings["image_two"]["id"],'full');
?>
  <?php if($style == '1'){?>
    <div class="ltn__feature-area section-bg-1 pt-115 pb-90 <?php echo $extra_class;?>">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title-area ltn__section-title-2 text-center">
                        <h6 class="section-subtitle ltn__secondary-color"><?php echo $sub_heading;?></h6>
                        <h1 class="section-title"><?php echo $heading;?><span>.</span></h1>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">
            <?php 
              foreach($settings["items"] as $item){ 
                $title = $item["title"]; 
                $content = $item["content"];  
                $icon =  $item["icon"]["value"];
                $link =  $item["link"]["url"];
                ?>
                <div class="col-lg-4 col-sm-6 col-12">
                    <div class="ltn__feature-item ltn__feature-item-7">
                        <div class="ltn__feature-icon-title">
                            <div class="ltn__feature-icon">
                                <span><i class="<?php echo $icon;?>"></i></span>
                            </div>
                            <h3><a href="<?php echo $link;?>"><?php echo $title;?></a></h3>
                        </div>
                        <div class="ltn__feature-info">
                            <p><?php echo $content;?></p>
                        </div>
                    </div>
                </div>
                <?php } ?> 
            </div>
        </div>
    </div>
    <?php }elseif($style == '2'){?>
      <div class="ltn__feature-area pt-115 pb-80">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title-area ltn__section-title-2 section-title-style-3">
                        <div class="section-brief-in">
                            <p><?php echo $short_desc;?></p>
                        </div>
                        <div class="section-title-in">
                            <h6 class="section-subtitle ltn__secondary-color"><?php echo $sub_heading;?></h6>
                            <h1 class="section-title"><?php echo $heading;?><span>.</span></h1>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-4">
                    <div class="row  justify-content-center">
                    <?php
                    $i = 0; 
                    foreach($settings["items"] as $item){ 
                      $title = $item["title"]; 
                      $content = $item["content"];  
                      $icon =  $item["icon"]["value"];
                      $link =  $item["link"]["url"];
                      $i++;
                      if($i < 4){
                      ?>
                        <div class="col-lg-12 col-md-6 col-12">
                            <div class="ltn__feature-item ltn__feature-item-3 text-right text-end">
                                <div class="ltn__feature-icon">
                                    <span><i class="<?php echo $icon;?>"></i></span>
                                </div>
                                <div class="ltn__feature-info">
                                    <h2><a href="<?php echo $link;?>"><?php echo $title;?></a></h2>
                                    <p><?php echo $content;?></p>
                                </div>
                            </div>
                        </div>
                        <?php } } ?> 
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="feature-banner-img text-center mb-30">
                        <?php echo $middle_image;?>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="row  justify-content-center">
                    <?php
                    $i = 0;
                    foreach($settings["items"] as $item){ 
                      $title = $item["title"]; 
                      $content = $item["content"];  
                      $icon =  $item["icon"]["value"];
                      $link =  $item["link"]["url"];
                      $i++;
                      if($i > 3){
                      ?>
                        <div class="col-lg-12 col-md-6 col-12">
                            <div class="ltn__feature-item ltn__feature-item-3">
                                <div class="ltn__feature-icon">
                                    <span><i class="<?php echo $icon;?>"></i></span>
                                </div>
                                <div class="ltn__feature-info">
                                    <h2><a href="<?php echo $link;?>"><?php echo $title;?></a></h2>
                                    <p><?php echo $content;?></p>
                                </div>
                            </div>
                        </div>
                        <?php } } ?> 
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php }elseif($style == '3'){?>
      <div class="ltn__why-choose-us-area section-bg-1 pt-120 pb-120">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="why-choose-us-info-wrap">
                        <div class="section-title-area ltn__section-title-2">
                            <h6 class="section-subtitle ltn__secondary-color"><?php echo $sub_heading;?></h6>
                            <h1 class="section-title"><?php echo $heading;?><span>.</span></h1>
                            <p><?php echo $short_desc;?></p>
                        </div>
                        <div class="row">
                        <?php
                      $i = 0;
                      foreach($settings["items"] as $item){ 
                        $title = $item["title"]; 
                        $content = $item["content"];  
                        $icon =  $item["icon"]["value"];
                        $link =  $item["link"]["url"];
                        $i++;
                        ?>
                            <div class="col-lg-12 col-md-6">
                                <div class="why-choose-us-feature-item">
                                    <div class="why-choose-us-feature-icon">
                                        <i class="<?php echo $icon;?>"></i>
                                    </div>
                                    <div class="why-choose-us-feature-brief">
                                        <h3><a href="<?php echo $link;?>"><?php echo $title;?></a></h3>
                                        <p><?php echo $content;?></p>
                                    </div>
                                </div>
                            </div>
                            <?php } ?> 
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="why-choose-us-img-wrap">
                        <div class="why-choose-us-img-1 text-start">
                        <?php echo $middle_image;?>
                        </div>
                        <div class="why-choose-us-img-2 text-end">
                        <?php echo $image_two;?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php 
    }
    }
}
Plugin::instance()->widgets_manager->register_widget_type( new \Autixir_Why_Choose_Us() );