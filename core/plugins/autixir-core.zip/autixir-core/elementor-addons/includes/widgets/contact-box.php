<?php
use Elementor\Utils;
use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use Elementor\Plugin;
use Elementor\Repeater;

class Autixir_Contact_Box extends Widget_Base {

  public function get_name() {
    return 'autixir_contact_box';
  }

  public function get_title() {
    return esc_html__( 'Contact Box', 'autixir-core' );
  }

  public function get_icon() {
    return '';
  }

   public function get_categories() {
    return [ 'autixir' ];
  }
  
    protected function register_controls() {

      $this->start_controls_section(
         'contact',
         [
           'label' => __( 'Contact', 'autixir-core' ),
         ]
      );

        $this->add_control(
          'extra_class',
          [
            'label' => __( 'Extra Class', 'autixir-core' ),
            'type' => Controls_Manager::TEXT,
          ]
        );

      $repeater = new Repeater();
          $repeater->add_control(
            'image',
            [
              'label' => __( 'Image', 'autixir-core' ),
              'type' => Controls_Manager::MEDIA,
              'default' => [
                        'url' => Utils::get_placeholder_image_src(),
                    ],
            ]
          );
          $repeater->add_control(
            'title',
            [
              'label' => __( 'Title', 'autixir-core' ),
              'type' => Controls_Manager::TEXT,
              'default' => __( 'Email Address', 'autixir-core' ),
            ]
          );
          $repeater->add_control(
            'content',
            [
              'label' => __( 'Content', 'autixir-core' ),
              'type' => Controls_Manager::TEXTAREA,
            ]
          );


           $this->add_control(
             'items1',
             [
               'label' => __( 'Repeater List', 'autixir-core' ),
               'type' => Controls_Manager::REPEATER,
               'fields' => $repeater->get_controls(),
               'default' => [
                 [
                   'list_title' => __( 'Title #1', 'autixir-core' ),
                   'list_content' => __( 'Item content. Click the edit button to change this text.', 'autixir-core' ),
                 ],
                 [
                   'list_title' => __( 'Title #2', 'autixir-core' ),
                   'list_content' => __( 'Item content. Click the edit button to change this text.', 'autixir-core' ),
                 ],
               ],
             ]
           );
         $this->end_controls_section();
  
    }    
    protected function render() {
      $settings =  $this->get_settings_for_display(); 
      $extra_class = $settings["extra_class"];
?>
<div class="ltn__contact-address-area mb-90 <?php echo $extra_class; ?>">
    <div class="container">
        <div class="row">
        <?php 
        foreach($settings["items1"] as $key=> $item){ 
          $image = wp_get_attachment_image( $item["image"] ["id"],'full');
          $title = $item["title"]; 
          $content = $item["content"]; 
          ?>
            <div class="col-lg-4">
                <div class="ltn__contact-address-item ltn__contact-address-item-3 box-shadow">
                    <div class="ltn__contact-address-icon">
                    <?php echo $image;?>
                    </div>
                    <h3><?php echo $title;?></h3>
                    <p><?php echo wp_kses_post($content);?></p>
                </div>
            </div>
            <?php } ?>
        </div>
    </div>
</div>
 <?php 
    }
}

Plugin::instance()->widgets_manager->register_widget_type( new \Autixir_Contact_Box() );