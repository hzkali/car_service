<?php
use Elementor\Utils;
use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use Elementor\Plugin;
use Elementor\Repeater;

class Autixir_Team extends Widget_Base {

  public function get_name() {
    return 'Autixir_Team';
  }

  public function get_title() {
    return esc_html__( 'Autixir Team', 'autixir-core' );
  }

  public function get_icon() {
    return '';
  }

   public function get_categories() {
    return [ 'autixir' ];
  }
  
    protected function register_controls() {

        $this->start_controls_section(
          'content',
          [
            'label' => __( 'Content', 'autixir-core' ),
          ]
        );
            $this->add_control(
              'sub_heading',
              [
                'label' => __( 'Sub Heading', 'autixir-core' ),
                'type' => Controls_Manager::TEXT,
                'default' => __( '// Team', 'autixir-core' ),
              ]
            );
            $this->add_control(
              'heading',
              [
                'label' => __( 'Heading', 'autixir-core' ),
                'type' => Controls_Manager::TEXT,
                'default' => __( 'Our Mechanics', 'autixir-core' ),
              ]
            );
            $this->add_control(
              'extra_class',
              [
                'label' => __( 'Extra Class', 'autixir-core' ),
                'type' => Controls_Manager::TEXT,
                'default' => __( '', 'autixir-core' ),
              ]
            );
          $repeater = new Repeater();
          $repeater->add_control(
            'image',
            [
              'label' => __( 'Image', 'autixir-core' ),
              'type' => Controls_Manager::MEDIA,
              'default' => [
                        'url' => Utils::get_placeholder_image_src(),
                    ],
            ]
          );
          $repeater->add_control(
            'name',
            [
              'label' => __( 'Name', 'autixir-core' ),
              'type' => Controls_Manager::TEXT,
              'default' => __( 'Rosalina D. William', 'autixir-core' ),
            ]
          );
          $repeater->add_control(
            'designation',
            [
              'label' => __( 'Designation', 'autixir-core' ),
              'type' => Controls_Manager::TEXT,
              'default' => __( 'founder', 'autixir-core' ),
            ]
          );
          $repeater->add_control(
            'link',
            [
                'label' => __( 'Link', 'autixir-core' ),
                'type' => Controls_Manager::URL,
                'placeholder' => __( 'https://your-link.com', 'autixir-core' ),
                'show_external' => true,
                'default' => [
                  'url' => '',
                  'is_external' => true,
                  'nofollow' => true,
                ],
              ]
            );
            $repeater->add_control(
              'facebook_url',
              [
                  'label' => __( 'Facebook URL', 'autixir-core' ),
                  'type' => Controls_Manager::URL,
                  'placeholder' => __( 'https://your-link.com', 'autixir-core' ),
                  'show_external' => true,
                  'default' => [
                    'url' => '',
                    'is_external' => true,
                    'nofollow' => true,
                  ],
                ]
              );
              $repeater->add_control(
                'twitter_url',
                [
                    'label' => __( 'Twitter URL', 'autixir-core' ),
                    'type' => Controls_Manager::URL,
                    'placeholder' => __( 'https://your-link.com', 'autixir-core' ),
                    'show_external' => true,
                    'default' => [
                      'url' => '',
                      'is_external' => true,
                      'nofollow' => true,
                    ],
                  ]
                );
            $repeater->add_control(
              'linkedin_url',
              [
                  'label' => __( 'Linkedin URL', 'autixir-core' ),
                  'type' => Controls_Manager::URL,
                  'placeholder' => __( 'https://your-link.com', 'autixir-core' ),
                  'show_external' => true,
                  'default' => [
                    'url' => '',
                    'is_external' => true,
                    'nofollow' => true,
                  ],
                ]
              );
      $this->add_control(
        'items1',
        [
          'label' => __( 'Repeater List', 'autixir-core' ),
          'type' => Controls_Manager::REPEATER,
          'fields' => $repeater->get_controls(),
          'default' => [
            [
              'list_title' => __( 'Title #1', 'autixir-core' ),
              'list_content' => __( 'Item content. Click the edit button to change this text.', 'autixir-core' ),
            ],
            [
              'list_title' => __( 'Title #2', 'autixir-core' ),
              'list_content' => __( 'Item content. Click the edit button to change this text.', 'autixir-core' ),
            ],
          ],
        ]
      );

      $this->end_controls_section();
  
    }    
    protected function render() {
      $settings =  $this->get_settings_for_display();
      $sub_heading = $settings["sub_heading"];
      $heading = $settings["heading"];
      $extra_class = $settings["extra_class"];   
?>
    <div class="ltn__team-area pt-115 pb-90 <?php echo $extra_class; ?>">
        <div class="container">
            <?php if(!empty($sub_heading) || !empty($heading)){?>
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title-area ltn__section-title-2 text-center">
                        <h6 class="section-subtitle ltn__secondary-color"><?php echo $sub_heading;?></h6>
                        <h1 class="section-title"><?php echo $heading;?><span>.</span></h1>
                    </div>
                </div>
            </div>
            <?php } ?>
            <div class="row justify-content-center">
            <?php
            foreach($settings["items1"] as $item){ 
                  $name = $item["name"]; 
                  $designation = $item["designation"]; 
                  $link = $item["link"]['url']; 
                  $facebook_url = $item["facebook_url"]['url'];
                  $twitter_url = $item["twitter_url"]['url'];
                  $linkedin_url = $item["linkedin_url"]['url'];
                  $image = wp_get_attachment_image( $item["image"] ["id"],'full');
                  ?>
                <div class="col-xl-3 col-lg-4 col-sm-6">
                    <div class="ltn__team-item ltn__team-item-3">
                        <div class="team-img">
                            <?php echo $image;?>
                        </div>
                        <div class="team-info">
                            <h6 class="ltn__secondary-color">//  <?php echo $designation;?>  //</h6>
                            <h4><a href="<?php echo $link;?>"><?php echo $name;?></a></h4>
                            <div class="ltn__social-media">
                                <ul>
                                    <li><a href="<?php echo $facebook_url;?>"><i class="fab fa-facebook-f"></i></a></li>
                                    <li><a href="<?php echo $twitter_url;?>"><i class="fab fa-twitter"></i></a></li>
                                    <li><a href="<?php echo $linkedin_url;?>"><i class="fab fa-linkedin"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <?php } ?>
            </div>
        </div>
    </div>
 <?php 
    }
}
Plugin::instance()->widgets_manager->register_widget_type( new \Autixir_Team() );