<?php
use Elementor\Utils;
use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use Elementor\Repeater;
use Elementor\Plugin;

class Autixir_Footer_Links extends Widget_Base {

  public function get_name() {
    return 'autixir_footer_links';
  }

  public function get_title() {
    return esc_html__( 'Autixir Footer Links', 'autixir-core' );
  }

  public function get_icon() {
    return '';
  }

   public function get_categories() {
    return [ 'autixir' ];
  }
  
    protected function register_controls() {

      $this->start_controls_section(
         'content',
         [
           'label' => __( 'Content', 'autixir-core' ),
         ]
      );
        $this->add_control(
            'title',
            [
            'label' => __( 'Title', 'autixir-core' ),
            'type' => Controls_Manager::TEXT,
            'default' => __( 'Services.', 'autixir-core' ),
            ]
        );
        $repeater = new Repeater();

        $repeater->add_control(
          'name',
          [
            'label' => __( 'Name', 'autixir-core' ),
            'type' => Controls_Manager::TEXT,
            'default' => __( 'Engine Diagnostics', 'autixir-core' ),
          ]
        );
        $repeater->add_control(
          'link',
          [
            'label' => __( 'Link', 'autixir-core' ),
            'type' => Controls_Manager::URL,
          ]
        );
      $this->add_control(
        'items1',
        [
          'label' => __( 'Repeater List', 'autixir-core' ),
          'type' => Controls_Manager::REPEATER,
          'fields' => $repeater->get_controls(),
          'default' => [
            [
              'list_title' => __( 'Title #1', 'autixir-core' ),
              'list_content' => __( 'Item content. Click the edit button to change this text.', 'autixir-core' ),
            ],
            [
              'list_title' => __( 'Title #2', 'autixir-core' ),
              'list_content' => __( 'Item content. Click the edit button to change this text.', 'autixir-core' ),
            ],
          ],
        ]
      );
  
      $this->end_controls_section();
    }    
    protected function render() {
      $settings =  $this->get_settings_for_display();
      $title = $settings["title"];
    ?>
        <div class="footer-widget footer-menu-widget footer-menu-widget-2-column clearfix">
            <h4 class="footer-title"><?php echo $title;?></h4>
            <div class="footer-menu">
                <ul>
                    <?php
                    $i = 0;
                    foreach($settings["items1"] as $item){ 
                      $i++;
                        $name = $item["name"]; 
                        $link = $item["link"]['url'];
                      
                    ?>
                    <li><a href="<?php echo $link;?>"><?php echo $name;?></a></li>
                    <?php 
                    if($i == 6){
                      break;
                    }
                  } ?>
                </ul>
            </div>
            <div class="footer-menu">
                <ul>
                  <?php
                  $i = 0;
                  foreach($settings["items1"] as $item){ 
                      $i++;
                        $name = $item["name"]; 
                        $link = $item["link"]['url'];
                        if($i > 6){
                    ?>
                    <li><a href="<?php echo $link;?>"><?php echo $name;?></a></li>
                  <?php
                    }
                  } 
                  ?>
                </ul>
            </div>
        </div>
      <?php
    } 
}
Plugin::instance()->widgets_manager->register_widget_type( new \Autixir_Footer_Links() );