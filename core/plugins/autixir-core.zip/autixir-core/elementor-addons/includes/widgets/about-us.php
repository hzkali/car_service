<?php
use Elementor\Utils;
use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use Elementor\Plugin;

class Autixir_About_Us extends Widget_Base {

  public function get_name() {
    return 'autixir_about_us';
  }

  public function get_title() {
    return esc_html__( 'Autixir About Us', 'autixir-core' );
  }

  public function get_icon() {
    return '';
  }

   public function get_categories() {
    return [ 'autixir' ];
  }
  
    protected function register_controls() {

      $this->start_controls_section(
         'content',
         [
           'label' => __( 'Content', 'autixir-core' ),
         ]
      );
      $this->add_control(
        'style',
        array(
          'label'   => esc_html__( 'Style', 'autixir-core' ),
          'type'    => Controls_Manager::SELECT,
          'options' => array(
            '1' => esc_html__( 'Style One', 'autixir-core' ),
            '2' => esc_html__( 'Style Two', 'autixir-core' ),
          ),
          'default' => '1',
        )
      );
        $this->add_control(
          'sub_heading',
          [
            'label' => __( 'Sub Heading', 'autixir-core' ),
            'type' => Controls_Manager::TEXT,
            'default' => __('// About Us', 'autixir-core' ),
          ]
        );
          $this->add_control(
            'heading',
            [
              'label' => __( 'Heading', 'autixir-core' ),
              'type' => Controls_Manager::TEXT,
              'default' => __('Safety Is Our First Priority', 'autixir-core' ),
            ]
          );
          $this->add_control(
            'quote_text',
            [
              'label' => __( 'Quote Text', 'autixir-core' ),
              'type' => Controls_Manager::TEXTAREA,
              'default' => __('Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore', 'autixir-core' ),
            ]
          );
          $this->add_control(
            'desc',
            [
              'label' => __( 'Description', 'autixir-core' ),
              'type' => Controls_Manager::TEXTAREA,
              'default' => __('Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.', 'autixir-core' ),
            ]
          );
          $this->add_control(
            'btn_text',
            [
              'label' => __( 'Button Text', 'autixir-core' ),
              'type' => Controls_Manager::TEXT,
              'default' => __( 'OUR SERVICES', 'autixir-core' ),
            ]
          );
          $this->add_control(
            'btn_url',
            [
              'label' => __( 'Button URL', 'autixir-core' ),
              'type' => Controls_Manager::URL,
            ]
          );
          $this->add_control(
            'image',
            [
              'label' => __( 'Image', 'autixir-core' ),
              'type' => Controls_Manager::MEDIA,
              'default' => [
                        'url' => Utils::get_placeholder_image_src(),
                    ],
            ]
          );
          $this->add_control(
            'year',
            [
              'label' => __( 'Year', 'autixir-core' ),
              'type' => Controls_Manager::TEXT,
              'default' => __( '25', 'autixir-core' ),
            ]
          );
          $this->add_control(
            'year_text',
            [
              'label' => __( 'Year Text', 'autixir-core' ),
              'type' => Controls_Manager::TEXT,
              'default' => __( 'Years Experience', 'autixir-core' ),
            ]
          );
          $this->add_control(
            'gallery',
            [
              'label' => __( 'Add Images', 'plugin-domain' ),
              'type' => Controls_Manager::GALLERY,
            ]
          );
          $this->add_control(
            'contact_text',
            [
              'label' => __( 'Contact Text', 'autixir-core' ),
              'type' => Controls_Manager::TEXTAREA,
            ]
          );
      $this->end_controls_section();
    }    
    protected function render() {
      $settings =  $this->get_settings_for_display();
      $style = $settings["style"];
      $sub_heading = $settings["sub_heading"];
      $heading = $settings["heading"];
      $quote_text = $settings["quote_text"];
      $desc = $settings["desc"];
      $btn_text = $settings["btn_text"];
      $btn_url = $settings["btn_url"]['url'];
      $image = wp_get_attachment_image( $settings["image"]["id"],'full');
      $year_text = $settings["year_text"];
      $year = $settings["year"];
      $gallery = $settings["gallery"];
      $contact_text = $settings["contact_text"];
    ?>
    <?php if($style == '1'){?>
    <div class="ltn__about-us-area pt-120-- pb-120">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 align-self-center">
                    <div class="about-us-img-wrap about-img-left">
                        <?php echo $image;?>
                        <div class="about-us-img-info about-us-img-info-2">
                            <div class="about-us-img-info-inner">
                                <h1><?php echo $year;?><span>+</span></h1>
                                <h6><?php echo $year_text;?></h6>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 align-self-center">
                    <div class="about-us-info-wrap">
                        <div class="section-title-area ltn__section-title-2">
                            <h6 class="section-subtitle ltn__secondary-color"><?php echo $sub_heading;?></h6>
                            <h1 class="section-title"><?php echo $heading;?><span>.</span></h1>
                            <p><?php echo $quote_text;?></p>
                        </div>
                        <p><?php echo $desc;?></p>
                        <div class="btn-wrapper">
                            <a href="<?php echo $btn_url;?>" class="theme-btn-3 btn btn-effect-4"><?php echo $btn_text;?></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php }elseif($style == '2'){ ?>
      <div class="ltn__about-us-area pt-80 pb-85">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 align-self-center">
                    <div class="about-us-img-wrap about-img-left">
                        <ul class="ltn__parallax-effect-wrap ltn__parallax-effect-active"
                            data-friction-x="0.1"
                            data-friction-y="0.1"
                            data-scalar-x="15"
                            data-scalar-y="25">
                            <li class="layer" data-depth="0.00"></li>
                            <?php 
                            $i = 0;
                            foreach($gallery as $gallery_img){
                              $i++;
                              if($i == 1){
                                  $class = 'ltn__effect-img-top-left';
                              }elseif($i == 2){
                                $class = 'ltn__effect-img-top-right';
                              }elseif($i == 3){
                                $class = 'ltn__effect-img-center-left';
                              }elseif($i == 4){
                                $class = 'ltn__effect-img-center-right';
                              }elseif($i == 5){
                                $class = 'ltn__effect-img-bottom-left';
                              }elseif($i == 6){
                                $class = 'ltn__effect-img-bottom-right';
                              }
                              ?>
                            <li class="layer" data-depth="0.10">
                                <div class="ltn__effect-img <?php echo $class;?>">
                                    <img src="<?php echo $gallery_img['url'];?>" alt="#">
                                </div>
                            </li>
                            <?php } ?>
                            <li class="layer" data-depth="0.50">
                                <div class="ltn__effect-img-top-center ">
                                    <div class="about-us-img-info">
                                        <div class="about-us-img-info-inner">
                                            <h1><span class="counter"><?php echo $year;?></span><span>+</span></h1>
                                            <h6><?php echo $year_text;?></h6>
                                            <span class="dots-bottom"></span>
                                        </div>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-6 align-self-center">
                    <div class="about-us-info-wrap">
                        <div class="section-title-area ltn__section-title-2">
                            <h6 class="section-subtitle ltn__secondary-color"><?php echo $sub_heading;?></h6>
                            <h1 class="section-title"><?php echo $heading;?><span>.</span></h1>
                            <p><?php echo $quote_text;?></p>
                        </div>
                        <p><?php echo $desc;?></p>
                        <hr>
                        <div class="about-call-us">
                            <div class="call-us-icon">
                                <?php echo $image;?>
                            </div>
                            <div class="call-us-info">
                                <?php echo $contact_text;?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
      <?php
      }
    } 
}
Plugin::instance()->widgets_manager->register_widget_type( new \Autixir_About_Us() );