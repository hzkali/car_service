<?php
use Elementor\Utils;
use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use Elementor\Plugin;
use Elementor\Repeater;

class Autixir_Portfolio extends Widget_Base {

  public function get_name() {
    return 'autixir_portfolio';
  }

  public function get_title() {
    return esc_html__( 'Autixir Portfolio', 'autixir-core' );
  }

  public function get_icon() {
    return '';
  }

   public function get_categories() {
    return [ 'autixir' ];
  }
  
    protected function register_controls() {

      $this->start_controls_section(
         'content',
         [
           'label' => __( 'Content', 'autixir-core' ),
         ]
      );
            $this->add_control(
              'background',
              [
                'label' => __( 'Background', 'autixir-core' ),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                          'url' => Utils::get_placeholder_image_src(),
                      ],
              ]
            );
            $this->add_control(
              'extra_class',
              [
                'label' => __( 'Extra Class', 'autixir-core' ),
                'type' => Controls_Manager::TEXT,
                'default' => __( '', 'autixir-core' ),
              ]
            );
          $repeater = new Repeater();

          $repeater->add_control(
            'image',
            [
              'label' => __( 'Image', 'autixir-core' ),
              'type' => Controls_Manager::MEDIA,
              'default' => [
                        'url' => Utils::get_placeholder_image_src(),
                    ],
            ]
          );
          $repeater->add_control(
            'title',
            [
              'label' => __( 'Title', 'autixir-core' ),
              'type' => Controls_Manager::TEXT,
              'default' => __( 'Portfolio Link', 'autixir-core' ),
            ]
          );
          $repeater->add_control(
            'category',
            [
              'label' => __( 'Category', 'autixir-core' ),
              'type' => Controls_Manager::TEXT,
              'default' => __( 'Web Design & Development, Branding', 'autixir-core' ),
            ]
          );
          $repeater->add_control(
            'url',
            [
              'label' => __( 'URL', 'autixir-core' ),
              'type' => Controls_Manager::URL,
            ]
          );
      $this->add_control(
        'items1',
        [
          'label' => __( 'Repeater List', 'autixir-core' ),
          'type' => Controls_Manager::REPEATER,
          'fields' => $repeater->get_controls(),
          'default' => [
            [
              'list_title' => __( 'Title #1', 'autixir-core' ),
              'list_content' => __( 'Item content. Click the edit button to change this text.', 'autixir-core' ),
            ],
            [
              'list_title' => __( 'Title #2', 'autixir-core' ),
              'list_content' => __( 'Item content. Click the edit button to change this text.', 'autixir-core' ),
            ],
          ],
        ]
      );
  
      $this->end_controls_section();
  
    }    
    protected function render() {
      $settings =  $this->get_settings_for_display();
      $extra_class = $settings["extra_class"]; 
      $background = wp_get_attachment_image_url( $settings["background"]["id"],'full');
?>
    <div class="ltn__gallery-area mb-120">
        <div class="container">
            <!-- Portfolio Wrapper Start -->
            <div class="ltn__gallery-active row ltn__gallery-style-2 ltn__gallery-info-hide---">
                <div class="ltn__gallery-sizer col-1"></div>
                <?php 
                    foreach($settings["items1"] as $item){ 
                      $title = $item["title"]; 
                      $category = $item["category"]; 
                      $url = $item["url"]['url']; 
                      $image = wp_get_attachment_image( $item["image"]["id"],'full', "", array( "class" => "img-fluid"));
                      $image_url = wp_get_attachment_image_url( $item["image"]["id"],'full', "", array( "class" => "img-fluid"));
                      ?>
                      <div class="ltn__gallery-item filter_category_3 col-lg-4 col-sm-6 col-12">
                          <div class="ltn__gallery-item-inner">
                              <div class="ltn__gallery-item-img">
                                  <a href="<?php echo $image_url;?>" data-rel="lightcase:myCollection">
                                      <?php echo  $image;?>
                                      <span class="ltn__gallery-action-icon">
                                          <i class="fas fa-search"></i>
                                      </span>
                                  </a>
                              </div>
                              <div class="ltn__gallery-item-info">
                                  <h4><a href="<?php echo $url;?>"><?php echo $title;?></a></h4>
                                  <p><?php echo $category;?></p>
                              </div>
                          </div>
                      </div>
                <?php } ?> 
            </div>
        </div>
    </div>

 <?php 
    }
}
Plugin::instance()->widgets_manager->register_widget_type( new \Autixir_Portfolio() );