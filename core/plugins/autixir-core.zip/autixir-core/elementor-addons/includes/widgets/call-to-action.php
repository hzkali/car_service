<?php
use Elementor\Utils;
use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use Elementor\Plugin;

class Autixir_CTA extends Widget_Base {

  public function get_name() {
    return 'Autixir_CTA';
  }

  public function get_title() {
    return esc_html__( 'Autixir CTA', 'autixir-core' );
  }

  public function get_icon() {
    return '';
  }

   public function get_categories() {
    return [ 'autixir' ];
  }
  
    protected function register_controls() {

      $this->start_controls_section(
         'content',
         [
           'label' => __( 'Content', 'autixir-core' ),
         ]
      );
          $this->add_control(
            'style',
                array(
                  'label'   => esc_html__( 'Style', 'autixir-core' ),
                  'type'    => Controls_Manager::SELECT,
                  'options' => array(
                    '1' => esc_html__( 'One', 'autixir-core' ),
                    '2' => esc_html__( 'Two', 'autixir-core' ),
                  ),
                  'default' => '1',
                )
          );
          $this->add_control(
            'image',
            [
              'label' => __( 'Image', 'autixir-core' ),
              'type' => Controls_Manager::MEDIA,
              'default' => [
                        'url' => Utils::get_placeholder_image_src(),
                    ],
            ]
          );
          $this->add_control(
            'sub_title',
            [
              'label' => __( 'Sub Title', 'autixir-core' ),
              'type' => Controls_Manager::TEXT,
              'default' => __('//  call to action  //', 'autixir-core' ),
            ]
          );
          $this->add_control(
            'title',
            [
              'label' => __( 'Title', 'autixir-core' ),
              'type' => Controls_Manager::TEXT,
              'default' => __('Get A Free Car Service', 'autixir-core' ),
            ]
          );
          $this->add_control(
            'button_text',
            [
              'label' => __( 'Button Text', 'autixir-core' ),
              'type' => Controls_Manager::TEXT,
              'default' => __( 'get an appointment', 'autixir-core' ),
            ]
          );
          $this->add_control(
            'button_url',
            [
                'label' => __( 'Button Url', 'autixir-core' ),
                'type' => Controls_Manager::URL,
                'placeholder' => __( 'https://your-link.com', 'autixir-core' ),
                'show_external' => true,
                'default' => [
                  'url' => '',
                  'is_external' => true,
                  'nofollow' => true,
                ],
                
              ]
            );
            $this->add_control(
              'button_text2',
              [
                'label' => __( 'Button 02 Text', 'autixir-core' ),
                'type' => Controls_Manager::TEXT,
                'default' => __( 'CONTACT US', 'autixir-core' ),
                'condition' => array('style' => '2'),
              ]
            );
            $this->add_control(
              'button_url2',
              [
                  'label' => __( 'Button 02 Url', 'autixir-core' ),
                  'type' => Controls_Manager::URL,
                  'placeholder' => __( 'https://your-link.com', 'autixir-core' ),
                  'show_external' => true,
                  'default' => [
                    'url' => '',
                    'is_external' => true,
                    'nofollow' => true,
                  ],
                  'condition' => array('style' => '2'),
                  
                ]
              );
              $this->add_control(
                'leftimage',
                [
                  'label' => __( 'Left Image', 'autixir-core' ),
                  'type' => Controls_Manager::MEDIA,
                  'default' => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                  'condition' => array('style' => '2'),
                ]
              );
              $this->add_control(
                'rightimage',
                [
                  'label' => __( 'Right Image', 'autixir-core' ),
                  'type' => Controls_Manager::MEDIA,
                  'default' => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                  'condition' => array('style' => '2'),
                ]
              );
      $this->end_controls_section();
    }    
    protected function render() {
      $settings =  $this->get_settings_for_display(); 
      $style = $settings["style"];
      $sub_title = $settings["sub_title"];
      $title = $settings["title"];
      $image = wp_get_attachment_image( $settings["image"] ["id"],'full');
      $image_url = wp_get_attachment_image_url( $settings["image"] ["id"],'full');
      $button_text = $settings["button_text"];  
      $button_url = $settings["button_url"]["url"];
?>
<?php if($style == '1'){?>
    <div class="ltn__get-a-free-service-area get-a-free-service-margin">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="get-a-free-service-inner bg-white text-center pt-115 pb-100">
                        <div class="call-to-img">
                            <?php echo $image;?>
                        </div>
                        <div class="call-to-action-inner-content">
                            <div class="section-title-area ltn__section-title-2 text-center">
                                <h6 class="section-subtitle ltn__secondary-color"><?php echo esc_html($sub_title);?></h6>
                                <h1 class="section-title"><?php echo esc_html($title);?><span>.</span></h1>
                            </div>
                            <div class="btn-wrapper">
                                <a href="<?php echo esc_url($button_url);?>" class="btn theme-btn-1 btn-effect-1 text-uppercase"><?php echo $button_text;?></a>
                            </div>
                        </div>
                        <span class="call-to-circle-1"></span>
                        <span class="call-to-circle-2 fa-spin"></span>
                        <span class="call-to-bg-icon"><i class="icon-automobile"></i></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php }elseif($style == '2'){
      $button_text2 = $settings["button_text2"];   
      $button_url2 = $settings["button_url2"]["url"];  
      $leftimage = wp_get_attachment_image( $settings["leftimage"] ["id"],'full');
      $rightimage = wp_get_attachment_image( $settings["rightimage"] ["id"],'full');
      ?>
      <div class="ltn__call-to-action-area ltn__call-to-action-4 bg-image pt-115 pb-120" data-bs-bg="<?php echo $image_url;?>">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="call-to-action-inner call-to-action-inner-4 text-center">
                        <div class="section-title-area ltn__section-title-2">
                            <h6 class="section-subtitle ltn__secondary-color"><?php echo esc_html($sub_title);?></h6>
                            <h1 class="section-title white-color"><?php echo esc_html($title);?></h1>
                        </div>
                        <div class="btn-wrapper">
                            <a href="<?php echo $button_url;?>" class="theme-btn-1 btn btn-effect-1"><?php echo $button_text;?></a>
                            <a href="<?php echo $button_url2;?>" class="btn btn-transparent btn-effect-3 white-color"><?php echo $button_text2;?></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="ltn__call-to-4-img-1">
           <?php echo $leftimage;?>
        </div>
        <div class="ltn__call-to-4-img-2">
          <?php echo $rightimage;?>
        </div>
    </div>
    <?php 
    }
    }
}
Plugin::instance()->widgets_manager->register_widget_type( new \Autixir_CTA() );