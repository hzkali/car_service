<?php
use Elementor\Utils;
use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use Elementor\Plugin;
use Elementor\Repeater;

class Autixir_Testimonial extends Widget_Base {

  public function get_name() {
    return 'autixir_testimonial';
  }

  public function get_title() {
    return esc_html__( 'Autixir Testimonial', 'autixir-core' );
  }

  public function get_icon() {
    return '';
  }

   public function get_categories() {
    return [ 'autixir' ];
  }
  
    protected function register_controls() {

            $this->start_controls_section(
              'heading_content',
              [
                'label' => __( 'Heading Content', 'autixir-core' ),
              ]
            );
            $this->add_control(
              'style',
              array(
                'label'   => esc_html__( 'Style', 'autixir-core' ),
                'type'    => Controls_Manager::SELECT,
                'options' => array(
                '1' => esc_html__( 'One', 'autixir-core' ),
                '2' => esc_html__( 'Two', 'autixir-core' ),
                '3' => esc_html__( 'Three', 'autixir-core' ),
                ),
                'default' => '1',
              )
              );
            $this->add_control(
              'sub_heading',
              [
                'label' => __( 'Sub Heading', 'autixir-core' ),
                'type' => Controls_Manager::TEXT,
                'default' => __( '//  Testimonials', 'autixir-core' ),
              ]
            );
            $this->add_control(
              'heading',
              [
                'label' => __( 'Heading', 'autixir-core' ),
                'type' => Controls_Manager::TEXT,
                'default' => __( 'Clients Feedbacks', 'autixir-core' ),
              ]
            );
            $this->add_control(
              'bg_image',
              [
                'label' => __( 'BG Image', 'autixir-core' ),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                          'url' => Utils::get_placeholder_image_src(),
                      ],
              ]
            );
            $this->add_control(
              'extra_class',
              [
                'label' => __( 'Extra Class', 'autixir-core' ),
                'type' => Controls_Manager::TEXT,
              ]
            );
            $this->end_controls_section();

          $this->start_controls_section(
            'testimonial_list',
            [
              'label' => __( 'Testimonial List', 'autixir-core' ),
            ]
          );
           
          $repeater = new Repeater();
          $repeater->add_control(
            'name',
            [
              'label' => __( 'Name', 'autixir-core' ),
              'type' => Controls_Manager::TEXT,
              'default' => __( 'Rosalina D. William', 'autixir-core' ),
            ]
          );
          $repeater->add_control(
            'designation',
            [
              'label' => __( 'Designation', 'autixir-core' ),
              'type' => Controls_Manager::TEXT,
              'default' => __( 'Founder', 'autixir-core' ),
            ]
          );
          $repeater->add_control(
            'image',
            [
              'label' => __( 'Author', 'autixir-core' ),
              'type' => Controls_Manager::MEDIA,
              'default' => [
                        'url' => Utils::get_placeholder_image_src(),
                    ],
            ]
          );
          $repeater->add_control(
            'review_text',
            [
              'label' => __( 'Review Text', 'autixir-core' ),
              'type' => Controls_Manager::TEXTAREA,
              'default' => __('Lorem ipsum dolor sit amet, consectetur adipi sicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.','autixir-core'),
            ]
          );
          $repeater->add_control(
            'review_image',
            [
              'label' => __( 'Review Image', 'autixir-core' ),
              'type' => Controls_Manager::MEDIA,
              'default' => [
                        'url' => Utils::get_placeholder_image_src(),
                    ],
            ]
          );
      $this->add_control(
        'items1',
        [
          'label' => __( 'Repeater List', 'autixir-core' ),
          'type' => Controls_Manager::REPEATER,
          'fields' => $repeater->get_controls(),
          'default' => [
            [
              'list_title' => __( 'Title #1', 'autixir-core' ),
              'list_content' => __( 'Item content. Click the edit button to change this text.', 'autixir-core' ),
            ],
            [
              'list_title' => __( 'Title #2', 'autixir-core' ),
              'list_content' => __( 'Item content. Click the edit button to change this text.', 'autixir-core' ),
            ],
          ],
        ]
      );
      $this->end_controls_section();
  
    }    
    protected function render() {
      $settings =  $this->get_settings_for_display();  
      $style   = $settings['style'];
      $heading = $settings["heading"]; 
      $sub_heading = $settings["sub_heading"]; 
      $bg_image = wp_get_attachment_image_url( $settings["bg_image"] ["id"],'full');
      $extra_class = $settings["extra_class"];   
?>
<?php if($style == '1'){?>
    <div class="ltn__testimonial-area bg-image pt-115 pb-70 <?php echo $extra_class;?>" data-bs-bg="<?php echo $bg_image;?>">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title-area ltn__section-title-2 text-center">
                        <h6 class="section-subtitle ltn__secondary-color"><?php echo $sub_heading;?></h6>
                        <h1 class="section-title"><?php echo $heading;?><span>.</span></h1>
                    </div>
                </div>
            </div>
            <div class="row ltn__testimonial-slider-3-active slick-arrow-1 slick-arrow-1-inner">
                <?php 
                  foreach($settings["items1"] as $item){ 
                    $name = $item["name"]; 
                    $designation = $item["designation"]; 
                    $review_text = $item["review_text"]; 
                    $image = wp_get_attachment_image( $item["image"] ["id"],'full');
                    ?>
                    <div class="col-lg-12">
                        <div class="ltn__testimonial-item ltn__testimonial-item-4">
                            <div class="ltn__testimoni-img">
                            <?php echo $image;?>
                            </div>
                            <div class="ltn__testimoni-info">
                                <p><?php echo $review_text;?></p>
                                <h4><?php echo $name;?></h4>
                                <h6><?php echo $designation;?></h6>
                            </div>
                            <div class="ltn__testimoni-bg-icon">
                                <i class="far fa-comments"></i>
                            </div>
                        </div>
                    </div>
                <?php } ?>
            </div>
        </div>
    </div>
    <?php }elseif($style == '2'){ ?>
      <div class="ltn__testimonial-area bg-image pt-115 pb-70 <?php echo $extra_class;?>" data-bs-bg="<?php echo $bg_image;?>">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title-area ltn__section-title-2">
                        <h6 class="section-subtitle ltn__secondary-color"><?php echo $sub_heading;?></h6>
                        <h1 class="section-title"><?php echo $heading;?><span>.</span></h1>
                    </div>
                </div>
            </div>
            <div class="row ltn__testimonial-slider-2-active slick-arrow-3">
            <?php 
              foreach($settings["items1"] as $item){ 
                $name = $item["name"]; 
                $designation = $item["designation"]; 
                $review_text = $item["review_text"]; 
                $image = wp_get_attachment_image( $item["image"] ["id"],'full');
                $review_image = wp_get_attachment_image( $item["review_image"] ["id"],'full');
                ?>
                <div class="col-lg-12">
                    <div class="ltn__testimonial-item ltn__testimonial-item-3">
                        <div class="ltn__testimonial-img">
                        <?php echo $review_image;?>
                        </div>
                        <div class="ltn__testimoni-info">
                            <p><?php echo $review_text;?></p>
                            <div class="ltn__testimoni-info-inner">
                                <div class="ltn__testimoni-img">
                                <?php echo $image;?>
                                </div>
                                <div class="ltn__testimoni-name-designation">
                                    <h4><?php echo $name;?></h4>
                                    <h6><?php echo $designation;?></h6>
                                </div>
                            </div>
                            <div class="ltn__testimoni-bg-icon">
                                <i class="far fa-comments"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <?php } ?>
            </div>
        </div>
    </div>
    <?php }elseif($style == '3'){ ?>
      <div class="ltn__testimonial-area ltn__testimonial-4 pt-115 pb-100 plr--9">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title-area ltn__section-title-2 text-center">
                        <h6 class="section-subtitle ltn__secondary-color"><?php echo $sub_heading;?></h6>
                        <h1 class="section-title"><?php echo $heading;?><span>.</span></h1>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="ltn__testimonial-slider-4 ltn__testimonial-slider-4-active slick-arrow-1">
                    <?php 
                    foreach($settings["items1"] as $item){ 
                      $name = $item["name"]; 
                      $designation = $item["designation"]; 
                      $review_text = $item["review_text"]; 
                      $image = wp_get_attachment_image( $item["image"] ["id"],'full');
                      ?>
                        <div class="ltn__testimonial-item-5">
                            <div class="ltn__quote-icon">
                                <i class="far fa-comments"></i>
                            </div>
                            <div class="ltn__testimonial-image">
                            <?php echo $image;?>
                            </div>
                            <div class="ltn__testimonial-info">
                                <p><?php echo $review_text;?></p>
                                <h4><?php echo $name;?></h4>
                                <h6><?php echo $designation;?></h6>
                            </div>
                        </div>
                        <?php } ?>
                    </div>
                    <ul class="ltn__testimonial-quote-menu d-none d-lg-block">
                    <?php 
                    foreach($settings["items1"] as $item){
                      $image = wp_get_attachment_image( $item["image"] ["id"],'full');
                      ?>
                        <li> <?php echo $image;?></li>
                      <?php } ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
 <?php 
      }
    }
}
Plugin::instance()->widgets_manager->register_widget_type( new \Autixir_Testimonial() );