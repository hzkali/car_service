<?php
use Elementor\Utils;
use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use Elementor\Plugin;
use Elementor\Repeater;

class Autixir_Banner_Slider extends Widget_Base {

  public function get_name() {
    return 'Autixir_Banner_Slider';
  }

  public function get_title() {
    return esc_html__( 'Autixir Banner Slider', 'autixir-core' );
  }

  public function get_icon() {
    return '';
  }

   public function get_categories() {
    return [ 'autixir' ];
  }
  
    protected function register_controls() {

      $this->start_controls_section(
         'content',
         [
           'label' => __( 'Content', 'autixir-core' ),
         ]
      );
            $this->add_control(
              'extra_class',
              [
                'label' => __( 'Extra Class', 'autixir-core' ),
                'type' => Controls_Manager::TEXT,
                'default' => __( '', 'autixir-core' ),
              ]
            );

      $this->end_controls_section();

      $this->start_controls_section(
        'slide_list',
        [
          'label' => __( 'Slide List', 'autixir-core' ),
        ]
      );
      $repeater = new Repeater();
      $repeater->add_control(
        'slide_image',
        [
          'label' => __( 'Slide Image', 'autixir-core' ),
          'type' => Controls_Manager::MEDIA,
          'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
        ]
      );
      $repeater->add_control(
        'title',
        [
          'label' => __( 'Title', 'autixir-core' ),
          'type' => Controls_Manager::TEXT,
          'default' => __( 'Providing A <br> Professional &amp; <br> Relaible Service', 'autixir-core' ),
        ]
      );
      $repeater->add_control(
        'subtitle',
        [
          'label' => __( 'Sub Title', 'autixir-core' ),
          'type' => Controls_Manager::TEXT,
          'default' => __( 'TALENTED ENGINEER & MECHANICS', 'autixir-core' ),
        ]
      );
      $repeater->add_control(
        'desc',
        [
          'label' => __( 'Desc', 'autixir-core' ),
          'type' => Controls_Manager::TEXTAREA,
          'default' => __( 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore.', 'autixir-core' ),
        ]
      );
      $repeater->add_control(
        'video_url',
        [
          'label' => __( 'Video URL', 'autixir-core' ),
          'type' => Controls_Manager::URL,
        ]
      );
      $repeater->add_control(
        'btn_1_text',
        [
          'label' => __( 'Button 01 Text', 'autixir-core' ),
          'type' => Controls_Manager::TEXT,
          'default' =>'OUR SERVICES',
        ]
      );
      $repeater->add_control(
        'btn_1_url',
        [
          'label' => __( 'Button 01 URL', 'autixir-core' ),
          'type' => Controls_Manager::URL,
        ]
      );
      $repeater->add_control(
        'btn_2_text',
        [
          'label' => __( 'Button 02 Text', 'autixir-core' ),
          'type' => Controls_Manager::TEXT,
          'default' =>'LEARN MORE',
        ]
      );
      $repeater->add_control(
        'btn_2_url',
        [
          'label' => __( 'Button 02 URL', 'autixir-core' ),
          'type' => Controls_Manager::URL,
        ]
      );
      $this->add_control(
        'items1',
        [
          'label' => __( 'Repeater List', 'autixir-core' ),
          'type' => Controls_Manager::REPEATER,
          'fields' => $repeater->get_controls(),
          'default' => [
            [
              'list_title' => __( 'Title #1', 'autixir-core' ),
              'list_content' => __( 'Item content. Click the edit button to change this text.', 'autixir-core' ),
            ],
            [
              'list_title' => __( 'Title #2', 'autixir-core' ),
              'list_content' => __( 'Item content. Click the edit button to change this text.', 'autixir-core' ),
            ],
          ],
        ]
      );
  
      $this->end_controls_section();

      $this->start_controls_section(
        'slide_list2',
        [
          'label' => __( 'Hotspot List', 'autixir-core' ),
        ]
      );
      $repeater2 = new Repeater();
      $repeater2->add_control(
        'hotspot_title',
        [
          'label' => __( 'Hotspot Title', 'autixir-core' ),
          'type' => Controls_Manager::TEXT,
          'default' => __( 'Goodyear Assurance Finesse 235/55R18 100H BSW', 'autixir-core' ),
        ]
      );
      $repeater2->add_control(
        'hotspot_url',
        [
          'label' => __('Hotspot URL', 'autixir-core' ),
          'type' => Controls_Manager::URL,
        ]
      );
      $repeater2->add_control(
        'hotspot_subtitle',
        [
          'label' => __( 'Hotspot Subtitle', 'autixir-core' ),
          'type' => Controls_Manager::TEXTAREA,
          'default' => __( 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Fugit, dolorum?', 'autixir-core' ),
        ]
      );
      $this->add_control(
        'items2',
        [
          'label' => __( 'Repeater List', 'autixir-core' ),
          'type' => Controls_Manager::REPEATER,
          'fields' => $repeater2->get_controls(),
          'default' => [
            [
              'list_title' => __( 'Title #1', 'autixir-core' ),
              'list_content' => __( 'Item content. Click the edit button to change this text.', 'autixir-core' ),
            ],
            [
              'list_title' => __( 'Title #2', 'autixir-core' ),
              'list_content' => __( 'Item content. Click the edit button to change this text.', 'autixir-core' ),
            ],
          ],
        ]
      );
  
      $this->end_controls_section();
  
    }    
    protected function render() {
      $settings =  $this->get_settings_for_display(); 
      $extra_class = $settings["extra_class"];    
?>
    <div class="ltn__slider-area ltn__slider-3  section-bg-1">
        <div class="ltn__slide-one-active slick-slide-arrow-1 slick-slide-dots-1">
        <?php
          $i = 0;
          foreach($settings["items1"] as $item){ 
            $subtitle = $item["subtitle"]; 
            $title = $item["title"]; 
            $desc = $item["desc"];   
            $btn_1_text = $item["btn_1_text"];   
            $btn_1_url = $item["btn_1_url"]['url'];   
            $btn_2_text = $item["btn_2_text"];   
            $btn_2_url = $item["btn_2_url"]['url'];   
            $video_url = $item["video_url"]['url'];  
            $slide_image = wp_get_attachment_image( $item["slide_image"]["id"],'full');
            $i++;
            ?>
            <!-- ltn__slide-item -->
            <?php if($i == 2){?>
                <div class="ltn__slide-item ltn__slide-item-2 ltn__slide-item-3">
                  <div class="ltn__slide-item-inner  text-right text-end">
                      <div class="container">
                          <div class="row">
                              <div class="col-lg-12 align-self-center">
                                  <div class="slide-item-info">
                                      <div class="slide-item-info-inner ltn__slide-animation">
                                          <h6 class="slide-sub-title ltn__secondary-color animated">// <?php echo $subtitle;?></h6>
                                          <h1 class="slide-title animated "><?php echo $title;?></h1>
                                          <div class="slide-brief animated">
                                              <p><?php echo $desc;?></p>
                                          </div>
                                          <div class="btn-wrapper animated">
                                              <a href="<?php echo $btn_1_url;?>" class="theme-btn-1 btn btn-effect-1"><?php echo $btn_1_text;?></a>
                                              <a href="<?php echo $btn_2_url;?>" class="btn btn-transparent btn-effect-3"><?php echo $btn_2_text;?></a>
                                          </div>
                                      </div>
                                  </div>
                                  <div class="slide-item-img slide-img-left">
                                      <?php echo $slide_image;?>
                                      <!-- product-pointer -->
                                      <?php
                                      $count = 0;
                                        foreach($settings["items2"] as $item){ 
                                          $hotspot_title = $item["hotspot_title"]; 
                                          $hotspot_subtitle = $item["hotspot_subtitle"];   
                                          $hotspot_url = $item["hotspot_url"]['url'];
                                          $count++;
                                          ?>
                                      <div class="ltn__product-pointer ltn__product-pointer-<?php echo $count;?>">
                                          <ul>
                                              <li>
                                                  <span class="ltn__pointer-icon"><i class="icon-plus"></i></span>
                                                  <ul>
                                                      <li>
                                                          <div class="ltn__product-pointer-inner">
                                                              <h5><a href="<?php echo $hotspot_url;?>"><?php echo $hotspot_title;?></a></h5>
                                                              <p><?php echo $hotspot_subtitle;?></p>
                                                          </div>
                                                      </li>
                                                  </ul>
                                              </li>
                                          </ul>
                                      </div>
                                      <?php } ?>
                                  </div>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
            <?php }else{ ?>
            <div class="ltn__slide-item ltn__slide-item-2 ltn__slide-item-3">
                <div class="ltn__slide-item-inner">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-12 align-self-center">
                                <div class="slide-item-info">
                                    <div class="slide-item-info-inner ltn__slide-animation">
                                        <div class="slide-video mb-50">
                                            <a class="ltn__video-icon-2 ltn__video-icon-2-border" href="<?php echo $video_url;?>" data-rel="lightcase:myCollection">
                                                <i class="fa fa-play"></i>
                                            </a>
                                        </div>
                                        <h1 class="slide-title animated "><?php echo $title;?></h1>
                                        <h6 class="slide-sub-title animated"><span>//</span> <?php echo $subtitle;?></h6>
                                    </div>
                                </div>
                                <div class="slide-item-img">
                                   <?php echo $slide_image;?>
                                    <!-- product-pointer -->
                                    <?php
                                      $count = 0;
                                        foreach($settings["items2"] as $item){ 
                                          $hotspot_title = $item["hotspot_title"]; 
                                          $hotspot_subtitle = $item["hotspot_subtitle"];   
                                          $hotspot_url = $item["hotspot_url"]['url'];
                                          $count++;
                                          ?>
                                      <div class="ltn__product-pointer ltn__product-pointer-<?php echo $count;?>">
                                          <ul>
                                              <li>
                                                  <span class="ltn__pointer-icon"><i class="icon-plus"></i></span>
                                                  <ul>
                                                      <li>
                                                          <div class="ltn__product-pointer-inner">
                                                              <h5><a href="<?php echo $hotspot_url;?>"><?php echo $hotspot_title;?></a></h5>
                                                              <p><?php echo $hotspot_subtitle;?></p>
                                                          </div>
                                                      </li>
                                                  </ul>
                                              </li>
                                          </ul>
                                      </div>
                                      <?php } ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php } ?>
            <?php } ?>
            <!--  -->
        </div>
    </div>
 <?php 
    }
}
Plugin::instance()->widgets_manager->register_widget_type( new \Autixir_Banner_Slider() );