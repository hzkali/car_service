<?php
use Elementor\Utils;
use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use Elementor\Plugin;
use Elementor\Repeater;
class Autixir_Brands extends Widget_Base {

	public function get_name() {
		return 'Autixir_Brands';
	}
	public function get_title() {
		return esc_html__( 'Autixir Brands', 'autixir-core' );
	}
	public function get_icon() {
		return '';
	}
	public function get_categories() {
		return array( 'autixir' );
	}

	protected function register_controls() {
		$this->start_controls_section(
			'general',
			array(
				'label' => esc_html__( 'general', 'autixir-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);
		$this->add_control(
			'style',
			array(
			  'label'   => esc_html__( 'Style', 'autixir-core' ),
			  'type'    => Controls_Manager::SELECT,
			  'options' => array(
				'1' => esc_html__( 'One', 'autixir-core' ),
				'2' => esc_html__( 'Two', 'autixir-core' ),
			  ),
			  'default' => '1',
			)
		  );
		$repeater = new Repeater();
		$repeater->add_control(
			'image',
			array(
				'label'   => __( 'Image', 'autixir-core' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => array(
					'url' => Utils::get_placeholder_image_src(),
				),
			)
		);
		$repeater->add_control(
			'link',
			array(
				'label'         => esc_html__( 'Link', 'autixir-core' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => esc_html__( 'https://your-link.com', 'autixir-core' ),
				'show_external' => true,
				'default'       => array(
					'url'         => '',
					'is_external' => true,
					'nofollow'    => true,
				),

			)
		);
		$this->add_control(
			'brand_list',
			array(
				'label'  => __( 'img List', 'autixir-core' ),
				'type'   => Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
			)
		);
		$this->add_control(
			'extra_class',
			[
			  'label' => __( 'Extra Class', 'autixir-core' ),
			  'type' => Controls_Manager::TEXT,
			]
		  );
		$this->end_controls_section();

	}
	protected function render() {
		$settings     = $this->get_settings_for_display();
		$extra_class   = $settings['extra_class'];
		$style   = $settings['style'];
		$brand_list   = $settings['brand_list'];
		?>
		<?php if($style == '1'){?>
		<div class="ltn__brand-logo-area ltn__brand-logo-1 pt-290 pb-110 plr--9 <?php echo $extra_class;?>">
			<div class="container-fluid">
				<div class="row ltn__brand-logo-active">
				<?php
				foreach ( $brand_list as $item ) {
					$link       = $item['link']['url'];
					$image = wp_get_attachment_image( $item["image"] ["id"],'full');
					?>
					<div class="col-lg-12">
						<div class="ltn__brand-logo-item">
						<?php if($link){ ?>
							<a href="<?php echo $link;?>">
								<?php echo $image;?>
							</a>
						<?php }else{ 
							echo $image;
							} 
							?>
						</div>
					</div>
					<?php } ?>
				</div>
			</div>
		</div>
		<?php }elseif($style == '2'){?>
			<div class="ltn__brand-logo-area ltn__brand-logo-1 pt-80 pb-110 plr--9 <?php echo $extra_class;?>">
				<div class="container-fluid">
					<div class="row ltn__brand-logo-active">
					<?php
						foreach ( $brand_list as $item ) {
							$link       = $item['link']['url'];
							$image = wp_get_attachment_image( $item["image"] ["id"],'full');
							?>
							<div class="col-lg-12">
								<div class="ltn__brand-logo-item">
								<?php if($link){ ?>
									<a href="<?php echo $link;?>">
										<?php echo $image;?>
									</a>
								<?php }else{ 
									echo $image;
									} 
									?>
								</div>
							</div>
						<?php } ?>
					</div>
				</div>
			</div>
		<?php
		}
	}
}
Plugin::instance()->widgets_manager->register_widget_type(new Autixir_Brands());