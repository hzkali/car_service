<?php
use Elementor\Utils;
use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use Elementor\Repeater;
use Elementor\Plugin;

class Autixir_Footer_Shedule extends Widget_Base {

  public function get_name() {
    return 'autixir_footer_shedule';
  }

  public function get_title() {
    return esc_html__( 'Autixir Footer Shedule', 'autixir-core' );
  }

  public function get_icon() {
    return '';
  }

   public function get_categories() {
    return [ 'autixir' ];
  }
  
    protected function register_controls() {

      $this->start_controls_section(
         'content',
         [
           'label' => __( 'Content', 'autixir-core' ),
         ]
      );
        $this->add_control(
            'subtitle',
            [
            'label' => __( 'Subtitle', 'autixir-core' ),
            'type' => Controls_Manager::TEXT,
            'default' => __( '// time shedule', 'autixir-core' ),
            ]
        );
        $this->add_control(
            'title',
            [
            'label' => __( 'Title', 'autixir-core' ),
            'type' => Controls_Manager::TEXT,
            'default' => __( 'Meet In Timeline.', 'autixir-core' ),
            ]
        );
        $this->add_control(
            'bg_image',
            [
              'label' => __( 'Background Image', 'autixir-core' ),
              'type' => Controls_Manager::MEDIA,
              'default' => [
                        'url' => Utils::get_placeholder_image_src(),
                    ],
            ]
          );
          $repeater = new Repeater();
          $repeater->add_control(
            'day',
            [
              'label' => __( 'Day', 'autixir-core' ),
              'type' => Controls_Manager::TEXT,
              'default' => __( 'Monday', 'autixir-core' ),
            ]
          );
          $repeater->add_control(
            'time',
            [
              'label' => __( 'Time', 'autixir-core' ),
              'type' => Controls_Manager::TEXT,
              'default' => __( '07:00AM - 20:00PM', 'autixir-core' ),
            ]
          );
      $this->add_control(
        'items1',
        [
          'label' => __( 'Repeater List', 'autixir-core' ),
          'type' => Controls_Manager::REPEATER,
          'fields' => $repeater->get_controls(),
          'default' => [
            [
              'list_title' => __( 'Title #1', 'autixir-core' ),
              'list_content' => __( 'Item content. Click the edit button to change this text.', 'autixir-core' ),
            ],
            [
              'list_title' => __( 'Title #2', 'autixir-core' ),
              'list_content' => __( 'Item content. Click the edit button to change this text.', 'autixir-core' ),
            ],
          ],
        ]
      );
  
      $this->end_controls_section();
    }    
    protected function render() {
      $settings =  $this->get_settings_for_display();
      $subtitle = $settings["subtitle"]; 
      $title = $settings["title"];
      $bg_image = wp_get_attachment_image_url( $settings["bg_image"]["id"],'full');
    ?>
        <div class="footer-widget ltn__footer-timeline-widget ltn__footer-timeline-widget-1 bg-image bg-overlay-theme-black-90" data-bs-bg="<?php echo $bg_image;?>">
            <h6 class="ltn__secondary-color text-uppercase"><?php echo $subtitle;?></h6>
            <h4 class="footer-title"><?php echo $title;?></h4>
            <ul>
                <?php
                foreach($settings["items1"] as $item){ 
                    $day = $item["day"]; 
                    $time = $item["time"];
                ?>
                <li><?php echo $day;?> <span><?php echo $time;?></span></li>
                <?php } ?>
            </ul>
        </div>
      <?php
    } 
}
Plugin::instance()->widgets_manager->register_widget_type( new \Autixir_Footer_Shedule() );