<?php
if (!defined('ABSPATH')) {
    exit;
}

use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Utils;
use Elementor\Widget_Base;

class Autixir_Blog extends Widget_Base {

    public function get_name() {
        return 'autixir_blog';
    }

    public function get_title() {
        return esc_html__('Autixir Blog', 'autixir-core');
    }

    public function get_icon() {
        return 'eicon-post';
    }

    public function get_categories() {
        return ['autixir'];
    }

    private function get_blog_categories() {
        $options = array();
        $taxonomy = 'category';
        if (!empty($taxonomy)) {
            $terms = get_terms(
                    array(
                        'parent' => 0,
                        'taxonomy' => $taxonomy,
                        'hide_empty' => false,
                    )
            );
            if (!empty($terms)) {
                foreach ($terms as $term) {
                    if (isset($term)) {
                        $options[''] = 'Select';
                        if (isset($term->slug) && isset($term->name)) {
                            $options[$term->slug] = $term->name;
                        }
                    }
                }
            }
        }
        return $options;
    }

    protected function register_controls() {

        $this->start_controls_section(
            'section_blogs', [
                'label' => esc_html__('Blogs', 'autixir-core'),
            ]
        );
		$this->add_control(
			'style',
			array(
			  'label'   => esc_html__( 'Style', 'autixir-core' ),
			  'type'    => Controls_Manager::SELECT,
			  'options' => array(
				'1' => esc_html__( 'One', 'autixir-core' ),
				'2' => esc_html__( 'Two', 'autixir-core' ),
			  ),
			  'default' => '1',
			)
		  );
        $this->add_control(
            'sub_heading', [
                'label' => esc_html__('Sub Hading', 'autixir-core'),
                'type' => Controls_Manager::TEXT,
                'default' => __('// blog & insights','autixir-core'),
            ]
        );
        $this->add_control(
            'heading', [
                'label' => esc_html__('Hading', 'autixir-core'),
                'type' => Controls_Manager::TEXT,
                'default' => __('News Feeds','autixir-core'),
            ]
        );
        $this->add_control(
            'category_id', [
                'type' => Controls_Manager::SELECT,
                'label' => esc_html__('Category', 'autixir-core'),
                'options' => $this->get_blog_categories()
            ]
        );

        $this->add_control(
            'number', [
                'label' => esc_html__('Number of Post', 'autixir-core'),
                'type' => Controls_Manager::NUMBER,
                'default' => 3
            ]
        );

        $this->add_control(
            'order_by', [
                'label' => esc_html__('Order By', 'autixir-core'),
                'type' => Controls_Manager::SELECT,
                'default' => 'date',
                'options' => [
                    'date' => esc_html__('Date', 'autixir-core'),
                    'ID' => esc_html__('ID', 'autixir-core'),
                    'author' => esc_html__('Author', 'autixir-core'),
                    'title' => esc_html__('Title', 'autixir-core'),
                    'modified' => esc_html__('Modified', 'autixir-core'),
                    'rand' => esc_html__('Random', 'autixir-core'),
                    'comment_count' => esc_html__('Comment count', 'autixir-core'),
                    'menu_order' => esc_html__('Menu order', 'autixir-core')
                ]
            ]
        );

        $this->add_control(
            'order', [
                'label' => esc_html__('Order', 'autixir-core'),
                'type' => Controls_Manager::SELECT,
                'default' => 'desc',
                'options' => [
                    'desc' => esc_html__('DESC', 'autixir-core'),
                    'asc' => esc_html__('ASC', 'autixir-core')
                ]
            ]
        );

        $this->add_control(
            'extra_class', [
                'label' => esc_html__('Extra Class', 'autixir-core'),
                'type' => Controls_Manager::TEXT
            ]
        );
        $this->add_control(
            'btn_text', [
                'label' => esc_html__('Button Text', 'autixir-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Read More', 'autixir-core'),
            ]
        );
        $this->add_control(
            'bg_image',
            [
              'label' => __( 'BG Image', 'autixir-core' ),
              'type' => Controls_Manager::MEDIA,
              'default' => [
                        'url' => Utils::get_placeholder_image_src(),
                    ],
              'condition' => array('style' => '2'),
            ]
          );
        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings();
        $style = $settings['style'];
        $sub_heading = $settings['sub_heading'];
        $heading = $settings['heading'];
        $extra_class = $settings['extra_class'];
        $btn_text = $settings['btn_text'];
        $posts_per_page = $settings['number'];
 
        $order_by = $settings['order_by'];
        $order = $settings['order'];
        $pg_num = get_query_var('paged') ? get_query_var('paged') : 1;
        $args = array(
            'post_type' => array('post'),
            'post_status' => array('publish'),
            'nopaging' => false,
            'paged' => $pg_num,
            'posts_per_page' => $posts_per_page,
            'category_name' => $settings['category_id'],
            'orderby' => $order_by,
            'order' => $order,
        );
        $query = new WP_Query($args);
        ?>
    <?php if($style == '1'){?>
    <div class="ltn__blog-area pt-115 pb-90 <?php echo $extra_class;?>">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title-area ltn__section-title-2 text-center">
                        <h6 class="section-subtitle ltn__secondary-color"><?php echo $sub_heading;?></h6>
                        <h1 class="section-title"><?php echo $heading;?><span>.</span></h1>
                    </div>
                </div>
            </div>
            <div class="row  ltn__blog-slider-one-active slick-arrow-1">
            <?php
                if ($query->have_posts()) {
                    while ($query->have_posts()) {
                    $query->the_post();
                    $thumbnail_src = get_the_post_thumbnail_url();
                ?>  
                <div class="col-lg-12">
                    <div class="ltn__blog-item ltn__blog-item-4 bg-image" data-bs-bg="<?php echo $thumbnail_src;?>">
                        <div class="ltn__blog-brief">
                            <div class="ltn__blog-meta">
                                <ul>
                                    <li class="ltn__blog-author">
                                    <?php autixir_posted_by(); ?>
                                    </li>
                                    <li class="ltn__blog-tags">
                                    <?php autixir_post_categories(); ?>
                                    </li>
                                </ul>
                            </div>
                            <h3 class="ltn__blog-title"><a href="<?php the_permalink(); ?>"><?php the_title();?></a></h3>
                            <p>
                            <?php
                            $content = substr( get_the_excerpt(), 0, 110 );
                            echo $content . '...';
                            ?>
                            </p>
                            <div class="ltn__blog-meta-btn">
                                <div class="ltn__blog-meta">
                                    <ul>
                                        <li class="ltn__blog-date"><i class="far fa-calendar-alt"></i> <?php echo get_the_date();?></li>
                                    </ul>
                                </div>
                                <?php if($btn_text){?>
                                <div class="ltn__blog-btn">
                                    <a href="<?php the_permalink(); ?>"><?php echo $btn_text;?></a>
                                </div>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                </div>
                <?php
                    }
                    wp_reset_postdata();
                }
                ?> 
            </div>
        </div>
    </div>
    <?php }elseif($style == '2'){
        $bg_image = wp_get_attachment_image_url( $settings["bg_image"] ["id"],'full');
        ?>
    <div class="ltn__blog-area bg-image-top pt-115 <?php echo $extra_class;?>"  data-bs-bg="<?php echo $bg_image;?>">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title-area ltn__section-title-2">
                        <h6 class="section-subtitle white-color"><?php echo $sub_heading;?></h6>
                        <h1 class="section-title white-color"><?php echo $heading;?></h1>
                    </div>
                </div>
            </div>
            <div class="row  ltn__blog-slider-one-active slick-arrow-3 ltn__blog-3-arrow">
            <?php
                if ($query->have_posts()) {
                    while ($query->have_posts()) {
                    $query->the_post();
                ?>  
                <div class="col-lg-12">
                    <div class="ltn__blog-item ltn__blog-item-3">
                        <div class="ltn__blog-img">
                            <a href="<?php esc_url(the_permalink()); ?>"><?php the_post_thumbnail('autixir-blog-grid');?></a>
                        </div>
                        <div class="ltn__blog-brief">
                            <div class="ltn__blog-meta">
                                <ul>
                                    <li class="ltn__blog-author">
                                        <?php autixir_posted_by(); ?>
                                    </li>
                                    <li class="ltn__blog-tags">
                                        <?php autixir_post_categories(); ?>
                                    </li>
                                </ul>
                            </div>
                            <h3 class="ltn__blog-title"><a href="<?php esc_url(the_permalink()); ?>"><?php the_title();?></a></h3>
                            <div class="ltn__blog-meta-btn">
                                <div class="ltn__blog-meta">
                                    <ul>
                                        <li class="ltn__blog-date"><i class="far fa-calendar-alt"></i><?php echo get_the_date();?></li>
                                    </ul>
                                </div>
                                <div class="ltn__blog-btn">
                                    <a href="<?php esc_url(the_permalink()); ?>"><?php echo $btn_text;?></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php
                    }
                    wp_reset_postdata();
                }
                ?> 
            </div>
        </div>
    </div>
    <?php
        }
    }
}

Plugin::instance()->widgets_manager->register_widget_type(new Autixir_Blog());
