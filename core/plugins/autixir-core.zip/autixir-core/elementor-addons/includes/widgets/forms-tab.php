<?php
use Elementor\Utils;
use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use Elementor\Plugin;
use Elementor\Repeater;

class Autixir_Forms_Tab extends Widget_Base {

  public function get_name() {
    return 'autixir_forms_tab';
  }

  public function get_title() {
    return esc_html__( 'Autixir Forms Tab', 'autixir-core' );
  }

  public function get_icon() {
    return '';
  }

   public function get_categories() {
    return [ 'autixir' ];
  }
  
    protected function register_controls() {

      $this->start_controls_section(
         'content',
         [
           'label' => __( 'Content', 'autixir-core' ),
         ]
      );
            $this->add_control(
              'extra_class',
              [
                'label' => __( 'Extra Class', 'autixir-core' ),
                'type' => Controls_Manager::TEXT,
              ]
            );
          $repeater = new Repeater();
          $repeater->add_control(
            'tab_title',
            [
              'label' => __( 'Tab Title', 'autixir-core' ),
              'type' => Controls_Manager::TEXT,
              'default' => __( 'Find A Car', 'autixir-core' ),
            ]
          );
          $repeater->add_control(
            'tab_icon',
            [
              'label' => __( 'Tab Icon', 'autixir-core' ),
              'type' => Controls_Manager::ICONS,
            ]
          );
          $repeater->add_control(
            'form_shortcode',
            [
              'label' => __( 'Form Shortcode', 'autixir-core' ),
              'type' => Controls_Manager::TEXT,
            ]
          );

      $this->add_control(
        'items1',
        [
          'label' => __( 'Repeater List', 'autixir-core' ),
          'type' => Controls_Manager::REPEATER,
          'fields' => $repeater->get_controls(),
          'default' => [
            [
              'list_title' => __( 'Title #1', 'autixir-core' ),
              'list_content' => __( 'Item content. Click the edit button to change this text.', 'autixir-core' ),
            ],
            [
              'list_title' => __( 'Title #2', 'autixir-core' ),
              'list_content' => __( 'Item content. Click the edit button to change this text.', 'autixir-core' ),
            ],
          ],
        ]
      );
  
      $this->end_controls_section();
  
    }    
    protected function render() {
      $settings =  $this->get_settings_for_display();
      $extra_class = $settings["extra_class"];
?>
    <div class="ltn__car-dealer-form-area pt-115 pb-115">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="ltn__car-dealer-form-tab">
                        <div class="ltn__tab-menu  text-uppercase">
                            <div class="nav">
                              <?php
                              $i = 0;
                              foreach($settings["items1"] as $item){
                                $tab_title = $item["tab_title"]; 
                                $tab_icon = $item["tab_icon"]['value']; 
                                $i++;
                                if($i == 1){
                                  $class = 'class="active show"';
                                }else{
                                  $class = '';
                                }
                                ?>
                                <a <?php echo $class; ?> data-bs-toggle ="tab" href="#ltn__form_tab_1_<?php echo $i;?>"><i class="<?php echo $tab_icon;?>"></i><?php echo $tab_title;?></a>
                                <?php } ?> 
                            </div>
                        </div>
                        <div class="tab-content">
                             <?php
                              $i = 0;
                              foreach($settings["items1"] as $item){ 
                                $form_shortcode = $item["form_shortcode"]; 
                                $i++;
                                if($i == 1){
                                  $class = 'active show';
                                }else{
                                  $class = '';
                                }
                                ?>
                              <div class="tab-pane fade <?php echo $class;?>" id="ltn__form_tab_1_<?php echo $i;?>">
                                  <div class="car-dealer-form-inner">
                                    <?php echo do_shortcode($form_shortcode);?>
                                  </div>
                              </div>
                            <?php } ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php 
    }
}

Plugin::instance()->widgets_manager->register_widget_type( new \Autixir_Forms_Tab() );