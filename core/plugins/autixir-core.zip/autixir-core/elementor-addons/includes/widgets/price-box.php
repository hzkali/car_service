<?php
use Elementor\Utils;
use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use Elementor\Plugin;
use Elementor\Repeater;

class Autixir_PriceBox extends Widget_Base {

  public function get_name() {
    return 'Autixir_PriceBox';
  }

  public function get_title() {
    return esc_html__( 'Autixir Price Box', 'autixir-core' );
  }

  public function get_icon() {
    return '';
  }

   public function get_categories() {
    return [ 'autixir' ];
  }
  
    protected function register_controls() {

      $this->start_controls_section(
        'content',
        [
          'label' => __( 'Content', 'autixir-core' ),
        ]
     );
        $this->add_control(
          'heading',
          [
            'label' => __( 'Heading', 'autixir-core' ),
            'type' => Controls_Manager::TEXT,
            'default' => __( 'Servicess Priceing', 'autixir-core' ),
          ]
        );
        $this->add_control(
          'add_class',
          [
            'label' => __( 'Add Class', 'autixir-core' ),
            'type' => Controls_Manager::TEXT,
            'default' => __( '', 'autixir-core' ),
          ]
        );

      $this->end_controls_section();    

      $this->start_controls_section(
         'price_box',
         [
           'label' => __( 'Price Box', 'autixir-core' ),
         ]
      );
      $repeater = new Repeater();
      $repeater->add_control(
        'price_title',
        [
          'label' => __( 'Price Title', 'autixir-core' ),
          'type' => Controls_Manager::TEXT,
          'default' => __( 'One Time Charge', 'autixir-core' ),
        ]
      );
      $repeater->add_control(
        'price',
        [
                'label' => __( 'Price', 'autixir-core' ),
                'type' => Controls_Manager::TEXT,
                'default' => __( '$59.95', 'autixir-core' ),
            ]
        );

        $repeater->add_control(
          'price_list',
          [
            'label' => __( 'Price List', 'autixir-core' ),
            'type' => Controls_Manager::WYSIWYG,
            'default' => __( 'Default description', 'autixir-core' ),
            'placeholder' => __( 'Type your description here', 'autixir-core' ),
             
          ]
        );
        $repeater->add_control(
          'button_text',
          [
                'label' => __( 'Button Text', 'autixir-core' ),
                'type' => Controls_Manager::TEXT,
                'default' => __( 'Appointment', 'autixir-core' ),
            ]
          );
       $repeater->add_control(
            'button_link',
            [
                'label' => __( 'Button Link', 'autixir-core' ),
                'type' => Controls_Manager::URL,
                'placeholder' => __( 'https://your-link.com', 'autixir-core' ),
                'show_external' => true,
                'default' => [
                  'url' => '',
                  'is_external' => true,
                  'nofollow' => true,
                ],
                
              ]
            );
      $this->add_control(
      'items1',
      [
        'label' => __( 'Repeater List', 'autixir-core' ),
        'type' => Controls_Manager::REPEATER,
        'fields' => $repeater->get_controls(),
        'default' => [
          [
            'list_title' => __( 'Title #1', 'autixir-core' ),
            'list_content' => __( 'Item content. Click the edit button to change this text.', 'autixir-core' ),
          ],
          [
            'list_title' => __( 'Title #2', 'autixir-core' ),
            'list_content' => __( 'Item content. Click the edit button to change this text.', 'autixir-core' ),
          ],
        ],
      ]
    );
      $this->end_controls_section();

    }    
    
    protected function render() {
      $settings =  $this->get_settings_for_display();
	      $heading = $settings["heading"]; 
	      $add_class = $settings["add_class"]; 
    ?>


    <!-- pricing-section -->
    <div class="row">
        <div class="col-12 mt-70">
            <h3 class="text-dark"><?php echo $heading;?></h3>
        </div>
        <?php 
        $i = 1;
        foreach($settings["items1"] as $item){
          $i++;
          $price_title = $item["price_title"]; 
          $price = $item["price"]; 
          $price_list = $item["price_list"]; 
          $button_text = $item["button_text"]; 
          $button_link = $item["button_link"]['url']; 
              ?>
              <div class="col-md-6">
                  <div class="pricing-item shadow text-center mt-30">
                      <h4 class="text-dark bg-light-gray"><?php echo esc_html($price_title);?></h4>
                      <h3 class="text-primary pt-15 pb-15 font-secondery"><?php echo esc_html($price);?></h3>
                      <ul class="list-unstyled">
                        <?php echo wp_kses_post( $price_list );?>
                      </ul>
                      <div class="pricing-footer">
                          <a href="<?php echo esc_url($button_link);?>" class="btn btn-primary"><?php echo esc_html($button_text);?></a>
                      </div>
                  </div>
                  <!-- pricing-item -->
              </div>
          <?php } ?>
      </div>
    <?php
    }
    protected function _content_template() {
      
    }
  }

  Plugin::instance()->widgets_manager->register_widget_type( new \Autixir_PriceBox() );
