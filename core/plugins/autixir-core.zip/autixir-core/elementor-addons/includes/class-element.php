<?php
namespace Autixir;

class Element {

    public function __construct() {
       
        add_action('elementor/widgets/widgets_registered', array($this, 'widgets_registered'));
    }

    public function widgets_registered() {
      
        if (defined('AUTIXIR_ELEMENTOR_PATH') && class_exists('Elementor\Widget_Base')) {
            require_once AUTIXIR_ELEMENTOR_INCLUDES . '/widgets/banner-slider.php';
            require_once AUTIXIR_ELEMENTOR_INCLUDES . '/widgets/features-box.php';
            require_once AUTIXIR_ELEMENTOR_INCLUDES . '/widgets/banner.php';
            require_once AUTIXIR_ELEMENTOR_INCLUDES . '/widgets/about-section.php';
            require_once AUTIXIR_ELEMENTOR_INCLUDES . '/widgets/service-box.php';
            require_once AUTIXIR_ELEMENTOR_INCLUDES . '/widgets/counter-section.php';
            require_once AUTIXIR_ELEMENTOR_INCLUDES . '/widgets/team.php';
            require_once AUTIXIR_ELEMENTOR_INCLUDES . '/widgets/portfolio-slider.php';
            require_once AUTIXIR_ELEMENTOR_INCLUDES . '/widgets/call-to-action.php';
            require_once AUTIXIR_ELEMENTOR_INCLUDES . '/widgets/brands.php';
            require_once AUTIXIR_ELEMENTOR_INCLUDES . '/widgets/blog.php';
            require_once AUTIXIR_ELEMENTOR_INCLUDES . '/widgets/testimonial.php';
            require_once AUTIXIR_ELEMENTOR_INCLUDES . '/widgets/why-choose-us.php';
            require_once AUTIXIR_ELEMENTOR_INCLUDES . '/widgets/contact-box.php';
            require_once AUTIXIR_ELEMENTOR_INCLUDES . '/widgets/about-us.php';
            require_once AUTIXIR_ELEMENTOR_INCLUDES . '/widgets/skill-section.php';
            require_once AUTIXIR_ELEMENTOR_INCLUDES . '/widgets/history-section.php';
            require_once AUTIXIR_ELEMENTOR_INCLUDES . '/widgets/video-section.php';
            require_once AUTIXIR_ELEMENTOR_INCLUDES . '/widgets/portfolio.php';
            require_once AUTIXIR_ELEMENTOR_INCLUDES . '/widgets/service-price-list.php';
            require_once AUTIXIR_ELEMENTOR_INCLUDES . '/widgets/footer-shedule.php';
            require_once AUTIXIR_ELEMENTOR_INCLUDES . '/widgets/footer-links.php';
            require_once AUTIXIR_ELEMENTOR_INCLUDES . '/widgets/footer-posts.php';
            require_once AUTIXIR_ELEMENTOR_INCLUDES . '/widgets/features-box-two.php';
            require_once AUTIXIR_ELEMENTOR_INCLUDES . '/widgets/forms-tab.php';
            require_once AUTIXIR_ELEMENTOR_INCLUDES . '/widgets/faq.php';
            require_once AUTIXIR_ELEMENTOR_INCLUDES . '/widgets/banner-slider-two.php';
            require_once AUTIXIR_ELEMENTOR_INCLUDES . '/widgets/service-item.php';
            require_once AUTIXIR_ELEMENTOR_INCLUDES . '/widgets/footer-about.php';
            require_once AUTIXIR_ELEMENTOR_INCLUDES . '/widgets/footer-newsletter.php';

            // require_once AUTIXIR_ELEMENTOR_INCLUDES . '/widgets/service-tab.php';
            // require_once AUTIXIR_ELEMENTOR_INCLUDES . '/widgets/service-tab-item.php';
            
            
            // require_once AUTIXIR_ELEMENTOR_INCLUDES . '/widgets/price-box.php';
            // 
            // require_once AUTIXIR_ELEMENTOR_INCLUDES . '/widgets/product-tab.php';
            

        }
    }

}
