<?php
class Portfolios
{

    /**
     * Initialize the class
     */
    function __construct()
    {
        // Register the post type
        add_action('init', [$this, 'autixir_portfolios_post_type'], 0);
    }

    // Register Custom Post Type
    function autixir_portfolios_post_type()
    {

        $labels = array(
            'name' => _x('Portfolio', 'Post Type General Name', 'autixir'),
            'singular_name' => _x('Portfolio', 'Post Type Singular Name', 'autixir'),
            'menu_name' => __('Portfolio', 'autixir'),
            'name_admin_bar' => __('Portfolio', 'autixir'),
            'archives' => __('Item Archives', 'autixir'),
            'parent_item_colon' => __('Parent Item:', 'autixir'),
            'all_items' => __('All Portfolios', 'autixir'),
            'add_new_item' => __('Add New Portfolio', 'autixir'),
            'add_new' => __('Add New Portfolio', 'autixir'),
            'new_item' => __('New Portfolio Item', 'autixir'),
            'edit_item' => __('Edit Portfolio Item', 'autixir'),
            'update_item' => __('Update Portfolio Item', 'autixir'),
            'view_item' => __('View Portfolio Item', 'autixir'),
            'search_items' => __('Search Item', 'autixir'),
            'not_found' => __('Not found', 'autixir'),
            'not_found_in_trash' => __('Not found in Trash', 'autixir'),
            'featured_image' => __('Featured Image', 'autixir'),
            'set_featured_image' => __('Set featured image', 'autixir'),
            'remove_featured_image' => __('Remove featured image', 'autixir'),
            'use_featured_image' => __('Use as featured image', 'autixir'),
            'insert_into_item' => __('Insert into item', 'autixir'),
            'uploaded_to_this_item' => __('Uploaded to this item', 'autixir'),
            'items_list' => __('Items list', 'autixir'),
            'items_list_navigation' => __('Items list navigation', 'autixir'),
            'filter_items_list' => __('Filter items list', 'autixir'),
        );

		$args = array(
			'labels'             => $labels,
			'description'        => __( 'Description.', 'autixir' ),
			'public'             => true,
			'publicly_queryable' => true,
			'taxonomies'         => array( 'taxonomy_portfolio' ),
			'show_ui'            => true,
			'show_in_menu'       => true,
			'query_var'          => true,
			'rewrite'            => array( 'slug' => 'portfolios' ),
			'capability_type'    => 'post',
			'has_archive'        => true,
			'hierarchical'       => false,
			'menu_position'      => null,
			'supports'           => array( 'title', 'editor', 'thumbnail' ),
		);

        register_post_type('portfolios', $args);
    }
}

$portfolios = new Portfolios();