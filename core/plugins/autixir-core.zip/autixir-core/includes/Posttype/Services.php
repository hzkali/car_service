<?php
class Services
{

    /**
     * Initialize the class
     */
    function __construct()
    {
        // Register the post type
        add_action('init', [$this, 'autixir_services_post_type'], 0);
    }

    // Register Custom Post Type
    function autixir_services_post_type()
    {

        $labels = array(
            'name' => _x('Service', 'Post Type General Name', 'autixir'),
            'singular_name' => _x('Service', 'Post Type Singular Name', 'autixir'),
            'menu_name' => __('Service', 'autixir'),
            'name_admin_bar' => __('Service', 'autixir'),
            'archives' => __('Item Archives', 'autixir'),
            'parent_item_colon' => __('Parent Item:', 'autixir'),
            'all_items' => __('All Services', 'autixir'),
            'add_new_item' => __('Add New Service', 'autixir'),
            'add_new' => __('Add New Service', 'autixir'),
            'new_item' => __('New Service Item', 'autixir'),
            'edit_item' => __('Edit Service Item', 'autixir'),
            'update_item' => __('Update Service Item', 'autixir'),
            'view_item' => __('View Service Item', 'autixir'),
            'search_items' => __('Search Item', 'autixir'),
            'not_found' => __('Not found', 'autixir'),
            'not_found_in_trash' => __('Not found in Trash', 'autixir'),
            'featured_image' => __('Featured Image', 'autixir'),
            'set_featured_image' => __('Set featured image', 'autixir'),
            'remove_featured_image' => __('Remove featured image', 'autixir'),
            'use_featured_image' => __('Use as featured image', 'autixir'),
            'insert_into_item' => __('Insert into item', 'autixir'),
            'uploaded_to_this_item' => __('Uploaded to this item', 'autixir'),
            'items_list' => __('Items list', 'autixir'),
            'items_list_navigation' => __('Items list navigation', 'autixir'),
            'filter_items_list' => __('Filter items list', 'autixir'),
        );

		$args = array(
			'labels'             => $labels,
			'description'        => __( 'Description.', 'autixir' ),
			'public'             => true,
			'publicly_queryable' => true,
			'taxonomies'         => array( 'taxonomy_service' ),
			'show_ui'            => true,
			'show_in_menu'       => true,
			'query_var'          => true,
			'rewrite'            => array( 'slug' => 'services' ),
			'capability_type'    => 'post',
			'has_archive'        => true,
			'hierarchical'       => false,
			'menu_position'      => null,
			'supports'           => array( 'title', 'editor', 'thumbnail' ),
		);

        register_post_type('services', $args);
    }
}

$services = new Services();